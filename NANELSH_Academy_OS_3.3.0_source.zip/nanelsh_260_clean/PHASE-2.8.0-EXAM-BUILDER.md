# NANELSH Academy OS — Phase 2.8.0

## Delivered
- Exam creation for a selected group or one student.
- Question selection from the existing bank by grade, subject, and lesson.
- Exam metadata: title, duration, optional date, and calculated total marks.
- Each exam stores an immutable JSON snapshot of its questions and answer metadata, plus the student roster at creation for group exams. Later bank edits or group enrollment changes do not mutate the existing exam roster or paper.
- Export/share of an RTL HTML exam paper and a separate answer key. The HTML can be opened in a browser and printed from a compatible Android app.
- Teacher-side score entry with range validation and one saved score per student per exam. Group grading candidates are limited to active members of the selected group.
- Native JSON backup schema upgraded to version 5 and now includes exams and exam results; restores from versions 1–4 remain supported.

## Limitations
- No student login, student-side exam-taking, timer enforcement, autosave of student responses, automatic grading, or online synchronization.
- All question types are included in the paper. Objective answer keys are provided for teacher reference; score entry remains teacher-controlled.
- HTML sharing depends on Android apps that can open or print HTML.
- As in 2.7.0, library file binaries remain outside JSON backups; this change does not alter that behavior.

## Version
- App/package version: 2.8.0
- Android versionCode: 11
- Backup schema: 5
