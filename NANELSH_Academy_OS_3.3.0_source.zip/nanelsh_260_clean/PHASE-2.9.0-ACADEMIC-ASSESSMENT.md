# Phase 2.9.0 — Academic Assessment

## Delivered
- New Arabic-first assessment tab.
- Individual student gradebook across their recorded exams, with subject filtering.
- Weighted overall percentage calculated as total points earned divided by total possible points across recorded results.
- Lesson-level performance aggregation, sorted from lowest to highest recorded percentage.
- Group reports for group-targeted exams, including average score, average percentage, count of students with recorded scores, and per-student result rows.
- Shareable plain-text academic report through the Android share sheet.

## Calculation rules
- Only results that have been entered and saved are included. Missing/ungraded results are not treated as zero.
- Student overall percentage is weighted by each exam's total marks.
- Group exam averages are the arithmetic mean of recorded student scores for that exam.
- Lesson aggregates combine points earned and possible marks across recorded exams for that subject/lesson.
- Percentages are descriptive; no official grade labels or pass/fail decisions are assigned.

## Scope and limitations
- No student portal or online exam delivery.
- No automated grading of essays or short answers.
- Group report includes exams assigned to the selected group; individual-targeted exams remain in the relevant student's personal gradebook.
- No schema change was required; existing exam_results data is reused. Backup schema remains version 5.
- Unified student-level finance is unchanged.
