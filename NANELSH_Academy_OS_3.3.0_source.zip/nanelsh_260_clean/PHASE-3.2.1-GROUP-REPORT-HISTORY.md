# Phase 3.2.1 — Group report history and sharing access

## Delivered in source
- Group details now include a saved report history sourced from completed group sessions.
- Each completed session shows its date, time, homework, and notes.
- Each active group member has an individual, selectable report message rendered from the same saved session data.
- Long-pressing the selectable report text on Android allows the teacher to copy it using the native text-selection menu.
- A visible action opens the existing per-student WhatsApp report flow for the selected group session. The teacher reviews and taps Send in WhatsApp.
- No separate report database was introduced; the existing completed session remains the source of truth.
- Restoring native backups now accepts schema version 8, matching the format already exported by 3.2.0.

## Preserved behavior
- Weekly timetable generation and its existing one-day exception behavior are unchanged.
- Student-level unified finance accounts are unchanged.
- No existing student, attendance, exam, content, or finance records are migrated or deleted.

## Version
- App version: 3.2.1
- Android versionCode: 16
- Native backup schema: 8 (unchanged)
