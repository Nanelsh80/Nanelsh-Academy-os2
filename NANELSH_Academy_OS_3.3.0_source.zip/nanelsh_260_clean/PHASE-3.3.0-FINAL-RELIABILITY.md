# NANELSH Academy OS 3.3.0 — Final Reliability Pass

## Included in this release

- Historical lesson tracking: count-only entries without invented dates and dated entries with attendance, homework, and notes.
- Complete native backups now include academy document metadata and the actual file bytes as Base64. Export fails clearly if a catalogued file is missing rather than creating an incomplete backup.
- Native restore validates that every document record has exactly one corresponding file payload, stages the files in the app's private academy-library directory, and restores the database records to the new device-local paths.
- Before a destructive native restore, the app writes an automatic full recovery snapshot (database records plus academy library files) to `academy-recovery/` in the app's private document directory.
- Native backup schema version 10. Restore remains compatible with native schemas 1–9; old backups without document payloads preserve the current library rather than silently deleting it. Legacy website student imports remain additive.
- Student archival uses the existing inactive state instead of hard deletion. Archiving pauses that student's recurring individual timetable slots and ends active group enrollments while preserving the student's academic and financial history. Reactivation does not silently re-enroll the student or reactivate old timetable slots.
- Group archival is a new additive `groups.active` column. Archiving pauses recurring group timetable slots while preserving sessions, enrollments, and reports. Reactivation requires explicit re-enabling of the weekly timetable.
- Group session completion now records attendance per active student and increments each student's completed/remaining lesson counters exactly once. Deleting a completed group session reverses the group and affected student counters; editing an already-completed session does not count it again.
- The home screen now surfaces ready-to-send completed-session reports, active student count, outstanding subscription balances, and overdue student accounts.

## Important behavior

- Historical sessions do not create finance transactions or subscription charges.
- Each student retains one unified financial account across all subjects.
- Archived students and groups remain visible in their respective lists with an archive status and can be reactivated.
- A restore from a schema 1–9 backup does not have embedded academy file bytes. The current library is retained for those legacy backups.

## Verification still required on the release runner/device

- `npm ci` and `npm run typecheck` with the exact lockfile dependencies.
- Android release APK build and install/launch smoke test.
- On-device backup/restore test with at least one PDF and one image, including automatic recovery snapshot creation.
- On-device archive/reactivation test for a student and group, checking timetable generation and historical records.
- On-device group attendance test with present/absent/late statuses, repeated completion protection, and delete/reversal behavior.
