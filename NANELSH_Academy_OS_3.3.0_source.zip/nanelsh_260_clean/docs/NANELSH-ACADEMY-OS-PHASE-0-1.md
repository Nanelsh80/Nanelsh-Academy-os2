# NANELSH Academy OS — Phase 0 / Foundation

## Product constraints
- Single-user Android application operated by Dr. Naneice Elshimy.
- Offline-first; operational data remains in local Expo SQLite.
- Direct APK distribution; no Google Play publication requirement.
- Subjects: Science, Biology, Chemistry, Physics.
- A student may study multiple subjects and join one active group per subject.
- Each group belongs to one subject; group sessions are shared by its members.
- Individual appointments and recurring weekly group/student timetable slots remain supported.

## Existing data kept intact
The original tables remain in place: `students`, `groups`, `sessions`, `financeTransactions`, and `timetable`. The existing text fields `students.subject` and `groups.memberNames` are retained for backward compatibility. Existing IDs are not rewritten.

## Additive schema introduced
- `subjects`: seeded bilingual catalog for the four current subjects.
- `student_subjects`: normalized many-to-many student/subject relation.
- `group_enrollments`: normalized student/group membership with history.
- `attendance_records`: per-student attendance rows for group sessions.

The partial unique index `one_active_group_per_student_subject` enforces at the database layer that a student cannot have two active groups for the same subject, while allowing groups in different subjects.

## Migration policy
Recognized legacy values in `students.subject` are copied into `student_subjects` without deleting or changing the original value. Unknown subject labels remain untouched for later review. Legacy `groups.memberNames` remains unchanged; names are not automatically converted into enrollments because ambiguous name matching could attach the wrong student.

## Backup policy
Native backup schema version 2 exports all rows from all existing and newly added tables. Dashboard list limits do not apply to backups. Restore remains compatible with version 1 backups, validates required legacy arrays before clearing data, and runs all replacement inserts in one SQLite transaction.

## Not yet implemented in this foundation pass
- UI for multi-select student subjects and structured group member selection.
- Converting legacy free-text group members into reviewed enrollments.
- Per-student attendance screen and reporting.
- Resource library, question bank, online/offline exam authoring, gradebook, detailed subscriptions.
- Daily/weekly/monthly calendar redesign.
