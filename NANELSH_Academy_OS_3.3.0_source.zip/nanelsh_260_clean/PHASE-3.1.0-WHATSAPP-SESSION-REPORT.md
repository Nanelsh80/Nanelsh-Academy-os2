# Phase 3.1.0 — WhatsApp post-session report

## Delivered
- Standardized post-session report message containing student name, academy name, date, session number, homework, and notes.
- Session numbers are persisted on completed sessions and backfilled for previously completed sessions.
- Individual session reports use the student's saved phone number to open a WhatsApp chat with the message prefilled.
- If a valid phone number is unavailable, the native share sheet opens so the teacher can choose WhatsApp or another app.
- Group sessions open a student picker and prepare a separate message for each active group member; the teacher selects and sends one student report at a time.
- Reports continue to use the existing local session homework and notes fields; no extra report table is required.
- Backup schema increased to version 7; versions 1–6 remain supported.

## WhatsApp behavior
The app opens the selected WhatsApp conversation with a prefilled message. The teacher reviews and taps Send in WhatsApp. The app does not silently send messages and does not use the WhatsApp Business API.

## Phone number handling
Egyptian local mobile numbers beginning with 0 are normalized to country code 20. International numbers already containing a country code are retained. If the number cannot be normalized to a plausible 8–15 digit international number, the native share sheet is used instead.

## Not included
- Automatic unattended sending.
- Delivery/read receipts.
- WhatsApp Business API integration or templates.
- Per-student attendance for group sessions; this report currently carries the session's shared homework and notes.
