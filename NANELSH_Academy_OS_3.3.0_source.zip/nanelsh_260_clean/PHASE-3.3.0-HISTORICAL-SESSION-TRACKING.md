# Phase 3.3.0 — Historical session tracking and report actions

## Historical sessions
- Student profiles support a quick count-only entry for prior lessons. These entries remain explicitly undated and never create invented dates or attendance rows.
- Student profiles also support detailed prior lessons with an exact date, subject, group (or individual lesson), attendance state (present, absent, excused, or late), optional homework, and optional notes.
- Both entry modes are stored separately from scheduled/completed sessions and are scoped to the student, subject, and selected group.
- Dated entries reject duplicate student/group/subject/date combinations.
- Adding a historical entry updates the student's completed-session and remaining-session counters without creating financial transactions. Deleting a historical entry reverses those counter changes.
- Detailed historical attendance is included in the student's attendance summary; undated count-only entries are excluded from attendance percentages.

## Group report actions
- Each completed group session remains visible in the group's report history.
- Every active group member has an individual report message with a visible native share/copy action and a direct WhatsApp action.
- WhatsApp is opened with a prefilled message; the teacher reviews and sends it manually.

## Backup and compatibility
- Native backup schema advances to version 9 and includes historical session entries.
- Restore remains compatible with backup schemas 1 through 9; backups from older versions simply contain no historical-session collection.
- Existing records are preserved by additive database table creation; no destructive migration is performed.
- Unified student-level finance accounts remain unchanged. Historical lesson entries do not create charges or split the student's financial account by subject.

## Build
- App version: 3.3.0
- Android versionCode: 17
