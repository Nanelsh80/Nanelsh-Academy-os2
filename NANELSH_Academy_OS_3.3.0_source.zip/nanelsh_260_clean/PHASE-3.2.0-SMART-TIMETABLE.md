# Phase 3.2.0 — Smart Weekly Timetable

## Goal
Make the weekly timetable the source of truth and automatically create each day's session records from active recurring timetable slots.

## Behavior
- On app startup and every local data refresh, generate today's scheduled sessions from active weekly slots for the current Arabic weekday.
- A unique `(timetableSlotId, sessionDate)` index makes generation idempotent; reopening or refreshing cannot duplicate a session.
- Sessions are snapshotted with the student/group name, academy, subject, time, and duration at generation time.
- Rescheduling a generated session detaches it from the recurring slot and records an exception for the original date, so the original appointment is not recreated that day.
- Deleting a generated session records a one-day exception, without disabling future weekly occurrences.
- Exceptions and source slot links are included in native JSON backups (schema version 8); older backup versions remain supported.
- Weekly timetable is presented as seven day sections (Saturday–Friday), sorted by time, with today's section highlighted, active counts, paused slots, and empty-day labels.
- Today's sessions are sorted chronologically on the dashboard and in the sessions tab.

## Boundaries
- Generation occurs when the app opens or refreshes while in the foreground. It does not rely on network access or background execution.
- Weekly recurring rules remain separate from one-off sessions.
- No existing finance, student, group, attendance, exam, or learning-content behavior is intentionally changed.

## Version
- App version: 3.2.0
- Android versionCode: 15
- Native backup schema: 8
