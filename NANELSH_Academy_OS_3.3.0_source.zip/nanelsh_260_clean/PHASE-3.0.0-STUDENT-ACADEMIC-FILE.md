# Phase 3.0.0 — Student Academic File

## Delivered
- Expanded each student profile into a consolidated academic file.
- Attendance history combines normalized group attendance records and legacy individual-session attendance fields.
- Exam results are shown with subject, lesson, score, maximum marks, and feedback where available.
- Teacher-managed homework records can be created, assigned a subject/lesson and optional due date, marked pending/done/late, and deleted.
- Teacher academic notes can be added with an optional subject and deleted.
- Homework and academic notes are included in native JSON backup and restore (schema version 6).
- Existing finance profile remains a single unified account per student and is unchanged.

## Data rules
- Attendance history shows only sessions with a recorded attendance status.
- Exam history shows only saved exam results; missing grades are not treated as zero.
- Homework and notes are teacher-side records only; no student or parent portal is included.
- Existing legacy backups (versions 1–5) remain supported; the new backup format is version 6.

## Limitations
- No automated WhatsApp delivery or parent portal.
- Homework is recorded and tracked by the teacher; student submission/upload is not supported yet.
- Attendance data that was never recorded cannot be reconstructed.
