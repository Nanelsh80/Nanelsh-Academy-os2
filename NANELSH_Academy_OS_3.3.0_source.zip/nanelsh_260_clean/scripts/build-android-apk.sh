#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/.android-sdk}}"

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

if [[ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]]; then
  echo "Android SDK command-line tools were not found at $ANDROID_HOME." >&2
  exit 1
fi

cd "$PROJECT_ROOT"
npx expo prebuild --platform android --no-install --clean
(
  cd android
  ./gradlew --no-daemon assembleRelease
)

APK_PATH="$PROJECT_ROOT/android/app/build/outputs/apk/release/app-release.apk"
printf '\nNative APK created: %s\n' "$APK_PATH"
