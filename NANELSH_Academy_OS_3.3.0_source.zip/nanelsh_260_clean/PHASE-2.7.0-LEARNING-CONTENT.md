# NANELSH Academy OS — Phase 2.7.0

## Learning content
- Local document library for PDF, Word, PowerPoint and image files.
- Files are copied from the Android document picker into the app's private document directory.
- Metadata is indexed by grade, subject and lesson.
- A target designation can be stored for all students, one student, or one group.
- Files can be opened through the Android native sharing/open sheet or removed from the library.

## Question bank
- Supports multiple choice, true/false, short answer and essay question records.
- Stores grade, subject, lesson, prompt, options, answer key, explanation and marks.
- Question-bank records are included in native JSON backup version 4.

## Scope and limitations
- Student/group designation is catalog metadata only in this release. The app is still a private, single-user teacher app and has no student/parent portal; therefore this release does not enforce student-side file authorization or publish files to students.
- Document binaries remain in the app's private local storage and are not embedded in JSON backups. Keep the original files separately; document-binary backup/restore is a later phase.
- Question-bank records are backed up and restored. Legacy backup versions 1–3 remain accepted.
- No online sync, question editing, exam assembly, automatic grading or student login is included yet.

## Verification
- TypeScript source syntax transpilation passed for App.tsx, src/types.ts, src/data/store.ts and src/lib/backup.ts.
- SQLite schema creation and CRUD smoke tests passed for document metadata and all four question types.
- Full project typecheck and Android build were not completed because npm dependency installation timed out and Expo/React Native packages were unavailable in the build environment.
