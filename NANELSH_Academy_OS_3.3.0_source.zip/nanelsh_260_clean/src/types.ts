export type Attendance = "حاضر" | "غائب" | "متأخر";
export type HistoricalAttendance = "حاضر" | "غائب" | "معذور" | "متأخر";
export type SessionStatus = "scheduled" | "in_progress" | "completed";
export type TransactionType = "income" | "expense" | "refund" | "discount";

export type Student = {
  id: number;
  name: string;
  academy: string | null;
  subject: string | null;
  subjectNames?: string | null;
  phone: string | null;
  totalSessions: number;
  completedSessions: number;
  remainingSessions: number;
  lastNotes: string | null;
  active: number;
  createdAt: string;
  subscriptionAmount: number;
  subscriptionDueDate: string | null;
};

export type LessonSession = {
  id: number;
  studentId: number | null;
  groupId: number | null;
  studentName: string | null;
  groupName: string | null;
  academy: string | null;
  subject: string | null;
  sessionDate: string;
  startTime: string;
  durationMinutes: number;
  status: SessionStatus;
  attendance: Attendance | null;
  homework: string | null;
  previousHomeworkDone: number | null;
  notes: string | null;
  sessionNumber?: number | null;
  timetableSlotId?: number | null;
  createdAt: string;
};

export type TutoringGroup = {
  id: number;
  name: string;
  academy: string | null;
  subject: string | null;
  capacity: number;
  memberNames: string | null;
  memberCount?: number;
  totalSessions: number;
  completedSessions: number;
  remainingSessions: number;
  notes: string | null;
  active: number;
  createdAt: string;
};

export type FinanceTransaction = {
  id: number;
  type: TransactionType;
  amount: number;
  description: string | null;
  transactionDate: string;
  createdAt: string;
  studentId?: number | null;
  studentName?: string | null;
};

export type TimetableException = {
  timetableSlotId: number;
  sessionDate: string;
  createdAt: string;
};

export type TimetableSlot = {
  id: number;
  studentId: number | null;
  groupId: number | null;
  title: string;
  dayOfWeek: string;
  startTime: string;
  durationMinutes: number;
  subject: string | null;
  active: number;
};

export type DashboardSnapshot = {
  students: Student[];
  sessions: LessonSession[];
  groups: TutoringGroup[];
  transactions: FinanceTransaction[];
  timetable: TimetableSlot[];
};

export type AcademySubject = {
  id: string;
  nameAr: string;
  nameEn: string;
  active: number;
  sortOrder: number;
};

export type StudentSubject = {
  studentId: number;
  subjectId: string;
  createdAt: string;
};

export type GroupEnrollment = {
  id: number;
  studentId: number;
  groupId: number;
  subjectId: string;
  status: "active" | "ended";
  startDate: string;
  endDate: string | null;
  createdAt: string;
};

export type AttendanceRecord = {
  id: number;
  sessionId: number;
  studentId: number;
  status: Attendance;
  recordedAt: string;
  notes: string | null;
  countedInStudentTotals?: number;
};

export type AcademyDocument = {
  id: number;
  title: string;
  fileName: string;
  fileUri: string;
  mimeType: string | null;
  sizeBytes: number | null;
  grade: string;
  subject: string;
  lesson: string;
  accessType: "all" | "student" | "group";
  accessId: number | null;
  createdAt: string;
};

export type QuestionType = "mcq" | "true_false" | "short_answer" | "essay";
export type AcademyQuestion = {
  id: number;
  grade: string;
  subject: string;
  lesson: string;
  questionType: QuestionType;
  prompt: string;
  optionsJson: string | null;
  correctAnswer: string | null;
  explanation: string | null;
  marks: number;
  createdAt: string;
};

export type AcademyExam = {
  id: number;
  title: string;
  grade: string;
  subject: string;
  lesson: string;
  targetType: "group" | "student";
  targetId: number;
  targetStudentIdsJson: string;
  durationMinutes: number;
  examDate: string | null;
  totalMarks: number;
  questionsJson: string;
  createdAt: string;
};

export type StudentHomework = {
  id: number;
  studentId: number;
  subject: string;
  lesson: string;
  description: string;
  dueDate: string | null;
  status: "pending" | "done" | "late";
  teacherNote: string | null;
  createdAt: string;
};

export type StudentAcademicNote = {
  id: number;
  studentId: number;
  subject: string | null;
  title: string;
  body: string;
  createdAt: string;
};

export type StudentAttendanceHistoryRow = AttendanceRecord & {
  sessionDate: string;
  subject: string | null;
  groupName: string | null;
};

export type HistoricalSessionRecord = {
  id: number;
  studentId: number;
  groupId: number | null;
  groupName: string | null;
  subject: string;
  entryType: "count" | "dated";
  sessionCount: number;
  sessionDate: string | null;
  attendance: HistoricalAttendance | null;
  homework: string | null;
  notes: string | null;
  createdAt: string;
};

export type ExamResult = {
  id: number;
  examId: number;
  studentId: number;
  score: number;
  feedback: string | null;
  gradedAt: string;
};

export type ExamPerformanceRow = ExamResult & {
  studentName: string;
  examTitle: string;
  grade: string;
  subject: string;
  lesson: string;
  examTotalMarks: number;
  examDate: string | null;
  targetType: "group" | "student";
  targetId: number;
  targetName: string | null;
};

export type NativeBackup = {
  schema: "naneice-desk-native";
  version: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
  exportedAt: string;
  students: Student[];
  sessions: LessonSession[];
  groups: TutoringGroup[];
  transactions: FinanceTransaction[];
  timetable: TimetableSlot[];
  timetableExceptions?: TimetableException[];
  subjects?: AcademySubject[];
  studentSubjects?: StudentSubject[];
  groupEnrollments?: GroupEnrollment[];
  attendanceRecords?: AttendanceRecord[];
  questionBank?: AcademyQuestion[];
  exams?: AcademyExam[];
  examResults?: ExamResult[];
  studentHomework?: StudentHomework[];
  studentAcademicNotes?: StudentAcademicNote[];
  historicalSessions?: HistoricalSessionRecord[];
  documents?: AcademyDocument[];
  documentFiles?: Array<{ documentId: number; base64: string }>;
};

export type LegacyBackup = {
  academies?: Array<{ name: string }>;
  students?: Array<{
    name: string;
    subject?: string | null;
    phone?: string | null;
    parentPhone?: string | null;
    totalSessions?: number;
    completedSessions?: number;
    remainingSessions?: number;
    lastNotes?: string | null;
  }>;
};
