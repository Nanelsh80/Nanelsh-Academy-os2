import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { Linking, Share } from "react-native";
import { exportBackup, importLegacyBackup, listAcademyDocuments, restoreNativeBackup } from "../data/store";
import type { LegacyBackup, LessonSession, NativeBackup, Student } from "../types";

const BACKUP_FILE = "naneice-desk-native-backup.json";

function safeParse(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("الملف المختار ليس نسخة JSON صالحة");
  }
}

function isNativeBackup(value: unknown): value is NativeBackup {
  return Boolean(
    value &&
      typeof value === "object" &&
      (value as NativeBackup).schema === "naneice-desk-native" &&
      ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10] as number[]).includes((value as NativeBackup).version)
  );
}

function isLegacyBackup(value: unknown): value is LegacyBackup {
  return Boolean(value && typeof value === "object" && Array.isArray((value as LegacyBackup).students));
}

async function buildCompleteBackup() {
  const backup = await exportBackup();
  const documents = await listAcademyDocuments();
  const documentFiles: NonNullable<NativeBackup["documentFiles"]> = [];
  for (const document of documents) {
    const info = await FileSystem.getInfoAsync(document.fileUri);
    if (!info.exists || info.isDirectory) {
      throw new Error(`تعذر إنشاء النسخة الكاملة: الملف «${document.fileName}» غير موجود داخل المكتبة. لم يتم إنشاء نسخة ناقصة.`);
    }
    const base64 = await FileSystem.readAsStringAsync(document.fileUri, { encoding: FileSystem.EncodingType.Base64 });
    if (!base64) throw new Error(`تعذر قراءة الملف «${document.fileName}».`);
    documentFiles.push({ documentId: document.id, base64 });
  }
  backup.documentFiles = documentFiles;
  return backup;
}

async function saveAutomaticRecoveryBackup() {
  const directory = FileSystem.documentDirectory;
  if (!directory) throw new Error("تعذر إنشاء نسخة أمان قبل الاستعادة؛ لم يتم تغيير بيانات التطبيق.");
  const backup = await buildCompleteBackup();
  const recoveryDirectory = `${directory}academy-recovery/`;
  const info = await FileSystem.getInfoAsync(recoveryDirectory);
  if (!info.exists) await FileSystem.makeDirectoryAsync(recoveryDirectory, { intermediates: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const uri = `${recoveryDirectory}before-restore-${stamp}.json`;
  await FileSystem.writeAsStringAsync(uri, JSON.stringify(backup), { encoding: FileSystem.EncodingType.UTF8 });
  return uri;
}

export async function shareLocalBackup() {
  const backup = await buildCompleteBackup();
  const directory = FileSystem.cacheDirectory;
  if (!directory) throw new Error("لا يمكن الوصول إلى مساحة حفظ الملفات على الجهاز");
  const fileUri = `${directory}${BACKUP_FILE}`;
  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(backup), {
    encoding: FileSystem.EncodingType.UTF8,
  });
  if (!(await Sharing.isAvailableAsync())) {
    throw new Error("المشاركة غير متاحة على هذا الجهاز");
  }
  await Sharing.shareAsync(fileUri, {
    mimeType: "application/json",
    dialogTitle: "حفظ نسخة Naneice Desk Native",
    UTI: "public.json",
  });
  return backup;
}

export async function chooseAndRestoreBackup() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ["application/json", "text/json", "text/plain"],
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (result.canceled || !result.assets[0]) return { canceled: true as const, imported: 0 };

  const raw = await FileSystem.readAsStringAsync(result.assets[0].uri, {
    encoding: FileSystem.EncodingType.UTF8,
  });
  const parsed = safeParse(raw);

  if (isNativeBackup(parsed)) {
    const backup = parsed as NativeBackup;
    const fileRows = backup.documentFiles ?? [];
    const documents = backup.documents ?? [];
    if (fileRows.length !== documents.length) {
      throw new Error("النسخة لا تحتوي على مجموعة ملفات تعليمية مطابقة للسجل؛ لم يتم تغيير بيانات التطبيق.");
    }
    const uniqueFileIds = new Set(fileRows.map(row => row.documentId));
    if (uniqueFileIds.size !== fileRows.length || documents.some(document => !uniqueFileIds.has(document.id))) {
      throw new Error("ارتباطات الملفات داخل النسخة غير مكتملة أو مكررة؛ لم يتم تغيير بيانات التطبيق.");
    }
    // Preserve the current database and every current library file before destructive restore.
    await saveAutomaticRecoveryBackup();
    const directory = FileSystem.documentDirectory;
    if (!directory) throw new Error("مساحة الملفات الداخلية غير متاحة لاستعادة المكتبة.");
    const libraryDirectory = `${directory}academy-library/`;
    const folderInfo = await FileSystem.getInfoAsync(libraryDirectory);
    if (!folderInfo.exists) await FileSystem.makeDirectoryAsync(libraryDirectory, { intermediates: true });
    const fileById = new Map(fileRows.map(row => [row.documentId, row.base64]));
    const restoredDocuments = documents.map(document => {
      const base64 = fileById.get(document.id);
      if (!base64 || !/^[A-Za-z0-9+/]*={0,2}$/.test(base64)) throw new Error(`ملف «${document.fileName}» غير صالح في النسخة الاحتياطية.`);
      return { ...document, fileUri: `${libraryDirectory}restored_${document.id}_${document.fileName.replace(/[^\w.\-\u0600-\u06FF]/g, "_")}` };
    });
    const writtenFiles: string[] = [];
    try {
      for (const document of restoredDocuments) {
        const base64 = fileById.get(document.id)!;
        await FileSystem.writeAsStringAsync(document.fileUri, base64, { encoding: FileSystem.EncodingType.Base64 });
        writtenFiles.push(document.fileUri);
      }
      const backupToRestore = backup.documents === undefined
        ? backup
        : { ...backup, documents: restoredDocuments };
      await restoreNativeBackup(backupToRestore);
    } catch (error) {
      await Promise.all(writtenFiles.map(uri => FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => undefined)));
      throw error;
    }
    return {
      canceled: false as const,
      imported: backup.students.length,
      source: "native" as const,
    };
  }

  if (isLegacyBackup(parsed)) {
    const imported = await importLegacyBackup(parsed);
    return { canceled: false as const, imported, source: "legacy" as const };
  }

  throw new Error("الملف لا يحتوي على نسخة مدعومة من Naneice Desk");
}

function reportDate(date: string) {
  return new Intl.DateTimeFormat("ar-EG-u-ca-gregory", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${date}T12:00:00`));
}

export function buildSessionReportMessage(session: LessonSession, student?: Pick<Student, "name" | "academy" | "phone">) {
  const studentName = student?.name || session.studentName || "غير محدد";
  const academyName = session.academy || student?.academy || "Dr. Naneice Elshimy";
  return [
    "🌷 تقرير ما بعد الحصة",
    "",
    `اسم الطالب: ${studentName}`,
    `اسم الأكاديمية: ${academyName}`,
    `التاريخ: ${reportDate(session.sessionDate)}`,
    `رقم الحصة: ${session.sessionNumber ? `الحصة ${session.sessionNumber}` : "غير محدد"}`,
    `الواجب: ${session.homework?.trim() || "لا يوجد واجب محدد"}`,
    `ملاحظات: ${session.notes?.trim() || "لا توجد ملاحظات"}`,
    "",
    "مع أطيب التمنيات بالتوفيق والنجاح 💐",
  ].join("\n");
}

function normalizeEgyptianWhatsAppNumber(raw: string) {
  let digits = raw.replace(/\D/g, "");
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("0")) digits = `20${digits.slice(1)}`;
  else if (digits.startsWith("1") && digits.length === 10) digits = `20${digits}`;
  return digits.length >= 8 && digits.length <= 15 ? digits : null;
}

export async function shareSessionReport(session: LessonSession, student?: Pick<Student, "name" | "academy" | "phone">) {
  const message = buildSessionReportMessage(session, student);
  const phone = student?.phone ? normalizeEgyptianWhatsAppNumber(student.phone) : null;
  if (phone) {
    await Linking.openURL(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`);
    return "whatsapp" as const;
  }
  await Share.share({ message, title: "تقرير ما بعد الحصة" }, { dialogTitle: "إرسال تقرير الحصة" });
  return "share-sheet" as const;
}
