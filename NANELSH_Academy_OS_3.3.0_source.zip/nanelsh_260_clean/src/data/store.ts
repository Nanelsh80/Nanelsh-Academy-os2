import * as SQLite from "expo-sqlite";
import type {
  AcademySubject,
  AcademyDocument,
  AcademyQuestion,
  AcademyExam,
  ExamResult,
  ExamPerformanceRow,
  StudentHomework,
  StudentAcademicNote,
  StudentAttendanceHistoryRow,
  HistoricalSessionRecord,
  HistoricalAttendance,
  Attendance,
  AttendanceRecord,
  DashboardSnapshot,
  GroupEnrollment,
  FinanceTransaction,
  LegacyBackup,
  LessonSession,
  NativeBackup,
  Student,
  StudentSubject,
  TimetableSlot,
  TimetableException,
  TutoringGroup,
} from "../types";

const DATABASE_NAME = "naneice-desk-native.db";
let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

function localIsoDate(date = new Date()) {
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 10);
}

function createdAt() {
  return new Date().toISOString();
}

async function getDb() {
  if (!databasePromise) {
    databasePromise = SQLite.openDatabaseAsync(DATABASE_NAME);
  }
  const db = await databasePromise;
  await db.execAsync("PRAGMA foreign_keys = ON;");
  return db;
}

export async function initializeStore() {
  const db = await getDb();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      academy TEXT,
      subject TEXT,
      phone TEXT,
      totalSessions INTEGER NOT NULL DEFAULT 0,
      completedSessions INTEGER NOT NULL DEFAULT 0,
      remainingSessions INTEGER NOT NULL DEFAULT 0,
      lastNotes TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      subscriptionAmount REAL NOT NULL DEFAULT 0,
      subscriptionDueDate TEXT,
      createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      academy TEXT,
      subject TEXT,
      capacity INTEGER NOT NULL DEFAULT 12,
      memberNames TEXT,
      totalSessions INTEGER NOT NULL DEFAULT 0,
      completedSessions INTEGER NOT NULL DEFAULT 0,
      remainingSessions INTEGER NOT NULL DEFAULT 0,
      notes TEXT,
      createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER,
      groupId INTEGER,
      studentName TEXT,
      groupName TEXT,
      academy TEXT,
      subject TEXT,
      sessionDate TEXT NOT NULL,
      startTime TEXT NOT NULL,
      durationMinutes INTEGER NOT NULL DEFAULT 60,
      status TEXT NOT NULL DEFAULT 'scheduled',
      attendance TEXT,
      homework TEXT,
      previousHomeworkDone INTEGER,
      notes TEXT,
      sessionNumber INTEGER,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE SET NULL,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS financeTransactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      description TEXT,
      transactionDate TEXT NOT NULL,
      studentId INTEGER,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS subjects (
      id TEXT PRIMARY KEY NOT NULL,
      nameAr TEXT NOT NULL,
      nameEn TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      sortOrder INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS student_subjects (
      studentId INTEGER NOT NULL,
      subjectId TEXT NOT NULL,
      createdAt TEXT NOT NULL,
      PRIMARY KEY (studentId, subjectId),
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE,
      FOREIGN KEY(subjectId) REFERENCES subjects(id) ON DELETE RESTRICT
    );
    CREATE TABLE IF NOT EXISTS group_enrollments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER NOT NULL,
      groupId INTEGER NOT NULL,
      subjectId TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'ended')),
      startDate TEXT NOT NULL,
      endDate TEXT,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE CASCADE,
      FOREIGN KEY(subjectId) REFERENCES subjects(id) ON DELETE RESTRICT
    );
    CREATE UNIQUE INDEX IF NOT EXISTS one_active_group_per_student_subject
      ON group_enrollments(studentId, subjectId) WHERE status = 'active';
    CREATE INDEX IF NOT EXISTS group_enrollments_by_group
      ON group_enrollments(groupId, status);
    CREATE TABLE IF NOT EXISTS attendance_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sessionId INTEGER NOT NULL,
      studentId INTEGER NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('حاضر', 'غائب', 'متأخر')),
      recordedAt TEXT NOT NULL,
      notes TEXT,
      countedInStudentTotals INTEGER NOT NULL DEFAULT 0,
      UNIQUE(sessionId, studentId),
      FOREIGN KEY(sessionId) REFERENCES sessions(id) ON DELETE CASCADE,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS academy_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      fileName TEXT NOT NULL,
      fileUri TEXT NOT NULL,
      mimeType TEXT,
      sizeBytes INTEGER,
      grade TEXT NOT NULL,
      subject TEXT NOT NULL,
      lesson TEXT NOT NULL,
      accessType TEXT NOT NULL DEFAULT 'all' CHECK(accessType IN ('all','student','group')),
      accessId INTEGER,
      createdAt TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS academy_documents_catalog ON academy_documents(grade, subject, lesson);
    CREATE TABLE IF NOT EXISTS question_bank (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      grade TEXT NOT NULL,
      subject TEXT NOT NULL,
      lesson TEXT NOT NULL,
      questionType TEXT NOT NULL CHECK(questionType IN ('mcq','true_false','short_answer','essay')),
      prompt TEXT NOT NULL,
      optionsJson TEXT,
      correctAnswer TEXT,
      explanation TEXT,
      marks REAL NOT NULL DEFAULT 1,
      createdAt TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS question_bank_catalog ON question_bank(grade, subject, lesson, questionType);
    CREATE TABLE IF NOT EXISTS academy_exams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      grade TEXT NOT NULL,
      subject TEXT NOT NULL,
      lesson TEXT NOT NULL,
      targetType TEXT NOT NULL CHECK(targetType IN ('group','student')),
      targetId INTEGER NOT NULL,
      targetStudentIdsJson TEXT NOT NULL,
      durationMinutes INTEGER NOT NULL DEFAULT 45,
      examDate TEXT,
      totalMarks REAL NOT NULL DEFAULT 0,
      questionsJson TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS academy_exams_target ON academy_exams(targetType, targetId, createdAt);
    CREATE TABLE IF NOT EXISTS exam_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      examId INTEGER NOT NULL,
      studentId INTEGER NOT NULL,
      score REAL NOT NULL,
      feedback TEXT,
      gradedAt TEXT NOT NULL,
      UNIQUE(examId, studentId),
      FOREIGN KEY(examId) REFERENCES academy_exams(id) ON DELETE CASCADE,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS student_homework (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER NOT NULL,
      subject TEXT NOT NULL,
      lesson TEXT NOT NULL,
      description TEXT NOT NULL,
      dueDate TEXT,
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','done','late')),
      teacherNote TEXT,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS student_homework_student ON student_homework(studentId, status, dueDate);
    CREATE TABLE IF NOT EXISTS student_academic_notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER NOT NULL,
      subject TEXT,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS student_academic_notes_student ON student_academic_notes(studentId, createdAt DESC);
    CREATE TABLE IF NOT EXISTS historical_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER NOT NULL,
      groupId INTEGER,
      groupName TEXT,
      subject TEXT NOT NULL,
      entryType TEXT NOT NULL CHECK(entryType IN ('count','dated')),
      sessionCount INTEGER NOT NULL DEFAULT 1 CHECK(sessionCount > 0),
      sessionDate TEXT,
      attendance TEXT CHECK(attendance IN ('حاضر','غائب','معذور','متأخر') OR attendance IS NULL),
      homework TEXT,
      notes TEXT,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE SET NULL
    );
    CREATE INDEX IF NOT EXISTS historical_sessions_student ON historical_sessions(studentId, sessionDate DESC, id DESC);
    CREATE UNIQUE INDEX IF NOT EXISTS historical_sessions_unique_dated
      ON historical_sessions(studentId, IFNULL(groupId, 0), subject, sessionDate)
      WHERE entryType = 'dated';
    CREATE TABLE IF NOT EXISTS timetable (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER,
      groupId INTEGER,
      title TEXT NOT NULL,
      dayOfWeek TEXT NOT NULL,
      startTime TEXT NOT NULL,
      durationMinutes INTEGER NOT NULL DEFAULT 60,
      subject TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE CASCADE
    );
  `);
  // Safe, additive migrations for databases created by earlier app versions.
  const studentColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info(students)");
  if (!studentColumns.some(column => column.name === "subscriptionAmount")) {
    await db.execAsync("ALTER TABLE students ADD COLUMN subscriptionAmount REAL NOT NULL DEFAULT 0");
  }
  if (!studentColumns.some(column => column.name === "subscriptionDueDate")) {
    await db.execAsync("ALTER TABLE students ADD COLUMN subscriptionDueDate TEXT");
  }
  const groupColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info(groups)");
  if (!groupColumns.some(column => column.name === "active")) {
    await db.execAsync("ALTER TABLE groups ADD COLUMN active INTEGER NOT NULL DEFAULT 1");
  }
  const sessionColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info(sessions)");
  if (!sessionColumns.some(column => column.name === "timetableSlotId")) {
    await db.execAsync("ALTER TABLE sessions ADD COLUMN timetableSlotId INTEGER");
  }
  await db.execAsync(`
    CREATE UNIQUE INDEX IF NOT EXISTS sessions_timetable_occurrence
      ON sessions(timetableSlotId, sessionDate) WHERE timetableSlotId IS NOT NULL;
    CREATE TABLE IF NOT EXISTS timetable_exceptions (
      timetableSlotId INTEGER NOT NULL,
      sessionDate TEXT NOT NULL,
      createdAt TEXT NOT NULL,
      PRIMARY KEY (timetableSlotId, sessionDate)
    );
  `);
  if (!sessionColumns.some(column => column.name === "sessionNumber")) {
    await db.execAsync("ALTER TABLE sessions ADD COLUMN sessionNumber INTEGER");
  }
  // Backfill sequential numbers for completed sessions created before this feature.
  await db.execAsync(`
    UPDATE sessions AS currentSession
    SET sessionNumber = (
      SELECT COUNT(*) FROM sessions AS earlierSession
      WHERE earlierSession.status = 'completed'
        AND ((currentSession.studentId IS NOT NULL AND earlierSession.studentId = currentSession.studentId)
          OR (currentSession.groupId IS NOT NULL AND earlierSession.groupId = currentSession.groupId))
        AND (earlierSession.sessionDate < currentSession.sessionDate
          OR (earlierSession.sessionDate = currentSession.sessionDate AND earlierSession.startTime < currentSession.startTime)
          OR (earlierSession.sessionDate = currentSession.sessionDate AND earlierSession.startTime = currentSession.startTime AND earlierSession.id <= currentSession.id))
    )
    WHERE currentSession.status = 'completed' AND currentSession.sessionNumber IS NULL;
  `);
  const attendanceColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info(attendance_records)");
  if (!attendanceColumns.some(column => column.name === "countedInStudentTotals")) {
    await db.execAsync("ALTER TABLE attendance_records ADD COLUMN countedInStudentTotals INTEGER NOT NULL DEFAULT 0");
  }
  const financeColumns = await db.getAllAsync<{ name: string }>("PRAGMA table_info(financeTransactions)");
  if (!financeColumns.some(column => column.name === "studentId")) {
    await db.execAsync("ALTER TABLE financeTransactions ADD COLUMN studentId INTEGER REFERENCES students(id) ON DELETE SET NULL");
  }
  await db.execAsync("CREATE INDEX IF NOT EXISTS finance_transactions_by_student ON financeTransactions(studentId)");
  await seedAcademySubjects(db);
  await migrateLegacyStudentSubjects(db);
}

const SUBJECTS: AcademySubject[] = [
  { id: "science", nameAr: "العلوم", nameEn: "Science", active: 1, sortOrder: 1 },
  { id: "biology", nameAr: "الأحياء", nameEn: "Biology", active: 1, sortOrder: 2 },
  { id: "chemistry", nameAr: "الكيمياء", nameEn: "Chemistry", active: 1, sortOrder: 3 },
  { id: "physics", nameAr: "الفيزياء", nameEn: "Physics", active: 1, sortOrder: 4 },
];

function normalizeSubject(value: string | null | undefined) {
  const normalized = value?.trim().toLocaleLowerCase("ar-EG");
  if (!normalized) return null;
  const aliases: Record<string, string> = {
    "علوم": "science", "العلوم": "science", "science": "science",
    "احياء": "biology", "الأحياء": "biology", "الاحياء": "biology", "biology": "biology",
    "كيمياء": "chemistry", "الكيمياء": "chemistry", "chemistry": "chemistry",
    "فيزياء": "physics", "الفيزياء": "physics", "physics": "physics",
  };
  return aliases[normalized] ?? null;
}

async function seedAcademySubjects(db: SQLite.SQLiteDatabase) {
  for (const subject of SUBJECTS) {
    await db.runAsync(
      "INSERT OR IGNORE INTO subjects (id, nameAr, nameEn, active, sortOrder) VALUES (?, ?, ?, ?, ?)",
      subject.id, subject.nameAr, subject.nameEn, subject.active, subject.sortOrder
    );
  }
}

async function migrateLegacyStudentSubjects(db: SQLite.SQLiteDatabase) {
  const legacyStudents = await db.getAllAsync<Pick<Student, "id" | "subject">>(
    "SELECT id, subject FROM students WHERE subject IS NOT NULL AND TRIM(subject) <> ''"
  );
  for (const student of legacyStudents) {
    const subjectId = normalizeSubject(student.subject);
    if (!subjectId) continue;
    await db.runAsync(
      "INSERT OR IGNORE INTO student_subjects (studentId, subjectId, createdAt) VALUES (?, ?, ?)",
      student.id, subjectId, createdAt()
    );
  }
}

export async function listAcademyDocuments() {
  const db = await getDb();
  return db.getAllAsync<AcademyDocument>("SELECT * FROM academy_documents ORDER BY createdAt DESC, id DESC");
}

export async function createAcademyDocument(input: Omit<AcademyDocument, "id" | "createdAt">) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO academy_documents (title,fileName,fileUri,mimeType,sizeBytes,grade,subject,lesson,accessType,accessId,createdAt)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    input.title.trim(), input.fileName, input.fileUri, input.mimeType, input.sizeBytes,
    input.grade.trim(), input.subject.trim(), input.lesson.trim(), input.accessType, input.accessId, createdAt()
  );
  return result.lastInsertRowId;
}

export async function deleteAcademyDocument(id: number) {
  const db = await getDb();
  const item = await db.getFirstAsync<Pick<AcademyDocument, "fileUri">>("SELECT fileUri FROM academy_documents WHERE id = ?", id);
  await db.runAsync("DELETE FROM academy_documents WHERE id = ?", id);
  return item?.fileUri ?? null;
}

export async function listAcademyQuestions() {
  const db = await getDb();
  return db.getAllAsync<AcademyQuestion>("SELECT * FROM question_bank ORDER BY createdAt DESC, id DESC");
}

export async function createAcademyQuestion(input: Omit<AcademyQuestion, "id" | "createdAt">) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO question_bank (grade,subject,lesson,questionType,prompt,optionsJson,correctAnswer,explanation,marks,createdAt)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    input.grade.trim(), input.subject.trim(), input.lesson.trim(), input.questionType,
    input.prompt.trim(), input.optionsJson, input.correctAnswer, input.explanation, input.marks, createdAt()
  );
  return result.lastInsertRowId;
}

export async function deleteAcademyQuestion(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM question_bank WHERE id = ?", id);
}

export async function listAcademyExams() {
  const db = await getDb();
  return db.getAllAsync<AcademyExam>("SELECT * FROM academy_exams ORDER BY createdAt DESC, id DESC");
}

export async function createAcademyExam(input: Omit<AcademyExam, "id" | "createdAt">) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO academy_exams (title,grade,subject,lesson,targetType,targetId,targetStudentIdsJson,durationMinutes,examDate,totalMarks,questionsJson,createdAt)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    input.title, input.grade, input.subject, input.lesson, input.targetType, input.targetId,
    input.targetStudentIdsJson, input.durationMinutes, input.examDate, input.totalMarks, input.questionsJson, createdAt()
  );
  return result.lastInsertRowId;
}

export async function deleteAcademyExam(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM academy_exams WHERE id = ?", id);
}

export async function listExamResults(examId: number) {
  const db = await getDb();
  return db.getAllAsync<ExamResult>("SELECT * FROM exam_results WHERE examId = ? ORDER BY studentId", examId);
}

export async function listAllExamResults() {
  const db = await getDb();
  return db.getAllAsync<ExamPerformanceRow>(
    `SELECT r.*, s.name AS studentName, e.title AS examTitle, e.grade, e.subject, e.lesson,
      e.totalMarks AS examTotalMarks, e.examDate, e.targetType, e.targetId,
      CASE WHEN e.targetType = 'group' THEN g.name ELSE targetStudent.name END AS targetName
     FROM exam_results r
     INNER JOIN students s ON s.id = r.studentId
     INNER JOIN academy_exams e ON e.id = r.examId
     LEFT JOIN groups g ON e.targetType = 'group' AND g.id = e.targetId
     LEFT JOIN students targetStudent ON e.targetType = 'student' AND targetStudent.id = e.targetId
     ORDER BY r.gradedAt DESC, r.id DESC`
  );
}

export async function saveExamResult(input: { examId: number; studentId: number; score: number; feedback?: string | null }) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO exam_results (examId,studentId,score,feedback,gradedAt) VALUES (?,?,?,?,?)
     ON CONFLICT(examId,studentId) DO UPDATE SET score=excluded.score, feedback=excluded.feedback, gradedAt=excluded.gradedAt`,
    input.examId, input.studentId, input.score, input.feedback?.trim() || null, createdAt()
  );
}

export async function listSubjects() {
  const db = await getDb();
  return db.getAllAsync<AcademySubject>("SELECT * FROM subjects WHERE active = 1 ORDER BY sortOrder, nameAr");
}

export async function listStudentSubjects(studentId: number) {
  const db = await getDb();
  return db.getAllAsync<AcademySubject>(
    "SELECT subjects.* FROM subjects INNER JOIN student_subjects ON student_subjects.subjectId = subjects.id WHERE student_subjects.studentId = ? ORDER BY subjects.sortOrder",
    studentId
  );
}

export async function setStudentSubjects(studentId: number, subjectIds: string[]) {
  const db = await getDb();
  const uniqueIds = [...new Set(subjectIds)];
  const activeEnrollments = await db.getAllAsync<{ subjectId: string }>(
    "SELECT subjectId FROM group_enrollments WHERE studentId = ? AND status = 'active'",
    studentId
  );
  if (activeEnrollments.some(enrollment => !uniqueIds.includes(enrollment.subjectId))) {
    throw new Error("لا يمكن إزالة مادة للطالب ما دام مسجلًا في مجموعة نشطة بها");
  }
  await db.withTransactionAsync(async () => {
    await db.runAsync("DELETE FROM student_subjects WHERE studentId = ?", studentId);
    for (const subjectId of uniqueIds) {
      await db.runAsync(
        "INSERT INTO student_subjects (studentId, subjectId, createdAt) VALUES (?, ?, ?)",
        studentId, subjectId, createdAt()
      );
    }
  });
}

export async function listGroupEnrollments(groupId?: number) {
  const db = await getDb();
  if (groupId !== undefined) {
    return db.getAllAsync<GroupEnrollment>(
      "SELECT * FROM group_enrollments WHERE groupId = ? ORDER BY status, startDate DESC",
      groupId
    );
  }
  return db.getAllAsync<GroupEnrollment>("SELECT * FROM group_enrollments ORDER BY startDate DESC, id DESC");
}

export type GroupMemberRow = {
  enrollmentId: number;
  studentId: number;
  name: string;
  phone: string | null;
  subjectId: string;
  startDate: string;
};

export async function listGroupMembers(groupId: number) {
  const db = await getDb();
  return db.getAllAsync<GroupMemberRow>(
    `SELECT group_enrollments.id AS enrollmentId, students.id AS studentId,
      students.name, students.phone, group_enrollments.subjectId, group_enrollments.startDate
     FROM group_enrollments
     INNER JOIN students ON students.id = group_enrollments.studentId
     WHERE group_enrollments.groupId = ? AND group_enrollments.status = 'active'
     ORDER BY students.name COLLATE NOCASE`,
    groupId
  );
}

export async function enrollStudentInGroup(studentId: number, groupId: number, startDate = localIsoDate()) {
  const db = await getDb();
  const group = await db.getFirstAsync<Pick<TutoringGroup, "id" | "subject">>(
    "SELECT id, subject FROM groups WHERE id = ?", groupId
  );
  if (!group) throw new Error("المجموعة غير موجودة");
  const subjectId = normalizeSubject(group.subject);
  if (!subjectId) throw new Error("حددي مادة صحيحة للمجموعة قبل تسجيل الطلاب");
  const groupCapacity = await db.getFirstAsync<{ capacity: number; memberCount: number }>(
    `SELECT groups.capacity AS capacity,
      (SELECT COUNT(*) FROM group_enrollments WHERE groupId = groups.id AND status = 'active') AS memberCount
     FROM groups WHERE groups.id = ?`,
    groupId
  );
  if (groupCapacity && groupCapacity.memberCount >= groupCapacity.capacity) {
    throw new Error("اكتملت سعة المجموعة؛ زيدي السعة قبل إضافة طالب جديد");
  }
  const existing = await db.getFirstAsync<{ id: number }>(
    "SELECT id FROM group_enrollments WHERE studentId = ? AND subjectId = ? AND status = 'active'",
    studentId, subjectId
  );
  if (existing) throw new Error("الطالب مسجل بالفعل في مجموعة نشطة لهذه المادة");
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      "INSERT OR IGNORE INTO student_subjects (studentId, subjectId, createdAt) VALUES (?, ?, ?)",
      studentId, subjectId, createdAt()
    );
    await db.runAsync(
      "INSERT INTO group_enrollments (studentId, groupId, subjectId, status, startDate, endDate, createdAt) VALUES (?, ?, ?, 'active', ?, NULL, ?)",
      studentId, groupId, subjectId, startDate, createdAt()
    );
  });
}

export async function endGroupEnrollment(enrollmentId: number, endDate = localIsoDate()) {
  const db = await getDb();
  await db.runAsync(
    "UPDATE group_enrollments SET status = 'ended', endDate = ? WHERE id = ? AND status = 'active'",
    endDate, enrollmentId
  );
}

export async function recordStudentAttendance(input: {
  sessionId: number;
  studentId: number;
  status: Attendance;
  notes?: string | null;
}) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO attendance_records (sessionId, studentId, status, recordedAt, notes)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(sessionId, studentId) DO UPDATE SET status = excluded.status, recordedAt = excluded.recordedAt, notes = excluded.notes`,
    input.sessionId, input.studentId, input.status, createdAt(), input.notes?.trim() || null
  );
}

export async function listSessionAttendance(sessionId: number) {
  const db = await getDb();
  return db.getAllAsync<AttendanceRecord>(
    "SELECT * FROM attendance_records WHERE sessionId = ? ORDER BY studentId",
    sessionId
  );
}

export async function listStudentAttendanceHistory(studentId: number) {
  const db = await getDb();
  return db.getAllAsync<StudentAttendanceHistoryRow>(
    `SELECT COALESCE(a.id, -s.id) AS id, s.id AS sessionId, ? AS studentId,
       COALESCE(a.status, s.attendance) AS status,
       COALESCE(a.recordedAt, s.createdAt) AS recordedAt, a.notes,
       s.sessionDate, s.subject, s.groupName
     FROM sessions s
     LEFT JOIN attendance_records a ON a.sessionId = s.id AND a.studentId = ?
     WHERE (s.studentId = ? OR a.studentId = ?) AND COALESCE(a.status, s.attendance) IS NOT NULL
     ORDER BY s.sessionDate DESC, id DESC`, studentId, studentId, studentId, studentId
  );
}

export async function listStudentHistoricalSessions(studentId: number) {
  const db = await getDb();
  return db.getAllAsync<HistoricalSessionRecord>(
    "SELECT * FROM historical_sessions WHERE studentId = ? ORDER BY sessionDate DESC, id DESC",
    studentId
  );
}

export async function addHistoricalSessionCount(input: {
  studentId: number; groupId?: number | null; groupName?: string | null; subject: string; count: number;
}) {
  const count = Math.floor(Number(input.count));
  if (!Number.isFinite(count) || count < 1 || count > 10000) throw new Error("أدخلي عدد حصص صحيحًا من 1 إلى 10000");
  if (!input.subject.trim()) throw new Error("اختاري المادة أولًا");
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      "INSERT INTO historical_sessions (studentId,groupId,groupName,subject,entryType,sessionCount,sessionDate,attendance,homework,notes,createdAt) VALUES (?,?,?,?, 'count', ?, NULL, NULL, NULL, NULL, ?)",
      input.studentId, input.groupId ?? null, input.groupName?.trim() || (input.groupId ? null : "فردي"), input.subject.trim(), count, createdAt()
    );
    await db.runAsync(
      "UPDATE students SET completedSessions = completedSessions + ?, remainingSessions = MAX(0, remainingSessions - ?) WHERE id = ?",
      count, count, input.studentId
    );
  });
}

export async function addHistoricalSessionDate(input: {
  studentId: number; groupId?: number | null; groupName?: string | null; subject: string; sessionDate: string;
  attendance: HistoricalAttendance; homework?: string | null; notes?: string | null;
}) {
  if (!input.subject.trim()) throw new Error("اختاري المادة أولًا");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.sessionDate)) throw new Error("اكتبي التاريخ بصيغة YYYY-MM-DD");
  const parsedDate = new Date(`${input.sessionDate}T12:00:00`);
  if (Number.isNaN(parsedDate.getTime()) || parsedDate.toISOString().slice(0, 10) !== input.sessionDate) throw new Error("تاريخ الحصة غير صحيح");
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await db.runAsync(
      "INSERT INTO historical_sessions (studentId,groupId,groupName,subject,entryType,sessionCount,sessionDate,attendance,homework,notes,createdAt) VALUES (?,?,?,?, 'dated', 1, ?, ?, ?, ?, ?)",
      input.studentId, input.groupId ?? null, input.groupName?.trim() || (input.groupId ? null : "فردي"), input.subject.trim(), input.sessionDate,
      input.attendance, input.homework?.trim() || null, input.notes?.trim() || null, createdAt()
    );
    await db.runAsync(
      "UPDATE students SET completedSessions = completedSessions + 1, remainingSessions = MAX(0, remainingSessions - 1) WHERE id = ?",
      input.studentId
    );
  });
}

export async function deleteHistoricalSessionRecord(id: number) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    const record = await db.getFirstAsync<HistoricalSessionRecord>("SELECT * FROM historical_sessions WHERE id = ?", id);
    if (!record) return;
    await db.runAsync("DELETE FROM historical_sessions WHERE id = ?", id);
    await db.runAsync(
      "UPDATE students SET completedSessions = MAX(0, completedSessions - ?), remainingSessions = remainingSessions + ? WHERE id = ?",
      record.sessionCount, record.sessionCount, record.studentId
    );
  });
}

export async function listStudentHomework(studentId: number) {
  const db = await getDb();
  return db.getAllAsync<StudentHomework>(
    "SELECT * FROM student_homework WHERE studentId = ? ORDER BY CASE status WHEN 'pending' THEN 0 WHEN 'late' THEN 1 ELSE 2 END, dueDate, id DESC",
    studentId
  );
}

export async function createStudentHomework(input: { studentId: number; subject: string; lesson: string; description: string; dueDate?: string | null }) {
  const db = await getDb();
  if (!input.description.trim()) throw new Error("اكتبي وصف الواجب أولًا");
  const result = await db.runAsync(
    "INSERT INTO student_homework (studentId, subject, lesson, description, dueDate, status, createdAt) VALUES (?, ?, ?, ?, ?, 'pending', ?)",
    input.studentId, input.subject.trim(), input.lesson.trim(), input.description.trim(), input.dueDate?.trim() || null, createdAt()
  );
  return result.lastInsertRowId;
}

export async function updateStudentHomeworkStatus(id: number, status: StudentHomework["status"], teacherNote?: string | null) {
  const db = await getDb();
  await db.runAsync("UPDATE student_homework SET status = ?, teacherNote = ? WHERE id = ?", status, teacherNote?.trim() || null, id);
}

export async function deleteStudentHomework(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM student_homework WHERE id = ?", id);
}

export async function listStudentAcademicNotes(studentId: number) {
  const db = await getDb();
  return db.getAllAsync<StudentAcademicNote>("SELECT * FROM student_academic_notes WHERE studentId = ? ORDER BY createdAt DESC, id DESC", studentId);
}

export async function createStudentAcademicNote(input: { studentId: number; subject?: string | null; title: string; body: string }) {
  const db = await getDb();
  if (!input.title.trim() || !input.body.trim()) throw new Error("العنوان والملاحظة مطلوبان");
  const result = await db.runAsync(
    "INSERT INTO student_academic_notes (studentId, subject, title, body, createdAt) VALUES (?, ?, ?, ?, ?)",
    input.studentId, input.subject?.trim() || null, input.title.trim(), input.body.trim(), createdAt()
  );
  return result.lastInsertRowId;
}

export async function deleteStudentAcademicNote(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM student_academic_notes WHERE id = ?", id);
}

export async function listStudents() {
  const db = await getDb();
  return db.getAllAsync<Student>(
    `SELECT students.*,
      (SELECT GROUP_CONCAT(subjects.nameAr, '، ')
       FROM student_subjects
       INNER JOIN subjects ON subjects.id = student_subjects.subjectId
       WHERE student_subjects.studentId = students.id) AS subjectNames
     FROM students
     ORDER BY students.active DESC, students.name COLLATE NOCASE ASC`
  );
}

export async function createStudent(input: {
  name: string;
  academy?: string | null;
  subject?: string | null;
  subjectIds?: string[];
  phone?: string | null;
  totalSessions?: number;
  completedSessions?: number;
  remainingSessions?: number;
  lastNotes?: string | null;
  subscriptionAmount?: number;
  subscriptionDueDate?: string | null;
}) {
  const db = await getDb();
  const subjectIds = [...new Set(input.subjectIds ?? [normalizeSubject(input.subject)].filter((value): value is string => Boolean(value)))];
  const legacySubject = input.subject?.trim() || SUBJECTS.find(subject => subject.id === subjectIds[0])?.nameAr || null;
  const result = await db.runAsync(
    `INSERT INTO students (name, academy, subject, phone, totalSessions, completedSessions, remainingSessions, lastNotes, active, subscriptionAmount, subscriptionDueDate, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)`,
    input.name.trim(),
    input.academy?.trim() || null,
    legacySubject,
    input.phone?.trim() || null,
    input.totalSessions ?? 0,
    input.completedSessions ?? 0,
    input.remainingSessions ?? input.totalSessions ?? 0,
    input.lastNotes?.trim() || null,
    Math.max(0, input.subscriptionAmount ?? 0),
    input.subscriptionDueDate?.trim() || null,
    createdAt()
  );
  const studentId = Number(result.lastInsertRowId);
  await setStudentSubjects(studentId, subjectIds);
  return studentId;
}

export async function updateStudent(id: number, input: Partial<Omit<Student, "id" | "createdAt">>) {
  const db = await getDb();
  const current = await db.getFirstAsync<Student>("SELECT * FROM students WHERE id = ?", id);
  if (!current) throw new Error("الطالب غير موجود على هذا الجهاز");
  await db.runAsync(
    `UPDATE students SET name = ?, academy = ?, subject = ?, phone = ?, totalSessions = ?, completedSessions = ?, remainingSessions = ?, lastNotes = ?, active = ?, subscriptionAmount = ?, subscriptionDueDate = ? WHERE id = ?`,
    input.name?.trim() ?? current.name,
    input.academy === undefined ? current.academy : input.academy?.trim() || null,
    input.subject === undefined ? current.subject : input.subject?.trim() || null,
    input.phone === undefined ? current.phone : input.phone?.trim() || null,
    input.totalSessions ?? current.totalSessions,
    input.completedSessions ?? current.completedSessions,
    input.remainingSessions ?? current.remainingSessions,
    input.lastNotes === undefined ? current.lastNotes : input.lastNotes?.trim() || null,
    input.active ?? current.active,
    Math.max(0, input.subscriptionAmount ?? current.subscriptionAmount ?? 0),
    input.subscriptionDueDate === undefined ? current.subscriptionDueDate : input.subscriptionDueDate?.trim() || null,
    id
  );
  if (input.active === 0) {
    await db.runAsync("UPDATE timetable SET active = 0 WHERE studentId = ?", id);
    await db.runAsync("UPDATE group_enrollments SET status = 'ended', endDate = ? WHERE studentId = ? AND status = 'active'", localIsoDate(), id);
  }
}

export async function deleteStudent(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM students WHERE id = ?", id);
}

export async function getStudentSessions(studentId: number) {
  const db = await getDb();
  return db.getAllAsync<LessonSession>(
    "SELECT * FROM sessions WHERE studentId = ? ORDER BY sessionDate DESC, startTime DESC, id DESC LIMIT 80",
    studentId
  );
}

export async function listGroups() {
  const db = await getDb();
  return db.getAllAsync<TutoringGroup>(
    `SELECT groups.*,
      (SELECT COUNT(*) FROM group_enrollments
       WHERE group_enrollments.groupId = groups.id AND group_enrollments.status = 'active') AS memberCount
     FROM groups
     ORDER BY groups.active DESC, groups.name COLLATE NOCASE ASC`
  );
}

export async function createGroup(input: {
  name: string;
  academy?: string | null;
  subject?: string | null;
  capacity?: number;
  memberNames?: string | null;
  totalSessions?: number;
  remainingSessions?: number;
  notes?: string | null;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO groups (name, academy, subject, capacity, memberNames, totalSessions, completedSessions, remainingSessions, notes, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?)`,
    input.name.trim(),
    input.academy?.trim() || null,
    input.subject?.trim() || null,
    Math.max(1, input.capacity ?? 12),
    input.memberNames?.trim() || null,
    input.totalSessions ?? 0,
    input.remainingSessions ?? input.totalSessions ?? 0,
    input.notes?.trim() || null,
    createdAt()
  );
  return Number(result.lastInsertRowId);
}

export async function deleteGroup(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM groups WHERE id = ?", id);
}

export async function updateGroup(id: number, input: Partial<Omit<TutoringGroup, "id" | "createdAt">>) {
  const db = await getDb();
  const current = await db.getFirstAsync<TutoringGroup>("SELECT * FROM groups WHERE id = ?", id);
  if (!current) throw new Error("المجموعة غير موجودة على هذا الجهاز");
  const capacity = Math.max(1, input.capacity ?? current.capacity);
  await db.runAsync(
    `UPDATE groups SET name = ?, academy = ?, subject = ?, capacity = ?, memberNames = ?,
     totalSessions = ?, completedSessions = ?, remainingSessions = ?, notes = ?, active = ? WHERE id = ?`,
    input.name?.trim() ?? current.name,
    input.academy === undefined ? current.academy : input.academy?.trim() || null,
    input.subject === undefined ? current.subject : input.subject?.trim() || null,
    capacity,
    input.memberNames === undefined ? current.memberNames : input.memberNames?.trim() || null,
    input.totalSessions ?? current.totalSessions,
    input.completedSessions ?? current.completedSessions,
    input.remainingSessions ?? current.remainingSessions,
    input.notes === undefined ? current.notes : input.notes?.trim() || null,
    input.active ?? current.active ?? 1,
    id
  );
  if (input.active === 0) {
    await db.runAsync("UPDATE timetable SET active = 0 WHERE groupId = ?", id);
  }
}

export async function generateSessionsFromWeeklyTimetable(date = localIsoDate()) {
  const db = await getDb();
  // JS getDay(): Sunday=0 ... Saturday=6. The app stores Arabic weekday names.
  const weekdayNames = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  const weekday = weekdayNames[new Date(`${date}T12:00:00`).getDay()];
  if (!weekday) return 0;

  const slots = await db.getAllAsync<TimetableSlot>(
    "SELECT * FROM timetable WHERE active = 1 AND dayOfWeek = ? ORDER BY startTime ASC, id ASC",
    weekday
  );
  let created = 0;
  await db.withTransactionAsync(async () => {
    for (const slot of slots) {
      const skipped = await db.getFirstAsync<{ found: number }>(
        "SELECT 1 AS found FROM timetable_exceptions WHERE timetableSlotId = ? AND sessionDate = ?",
        slot.id, date
      );
      if (skipped) continue;

      let student: { name: string; academy: string | null; subject: string | null } | null = null;
      let group: { name: string; academy: string | null; subject: string | null } | null = null;
      if (slot.studentId !== null) {
        student = await db.getFirstAsync<{ name: string; academy: string | null; subject: string | null }>("SELECT name, academy, subject FROM students WHERE id = ? AND active = 1", slot.studentId);
        if (!student) continue;
      } else if (slot.groupId !== null) {
        group = await db.getFirstAsync<{ name: string; academy: string | null; subject: string | null }>("SELECT name, academy, subject FROM groups WHERE id = ?", slot.groupId);
        if (!group) continue;
      } else {
        continue;
      }

      const result = await db.runAsync(
        `INSERT OR IGNORE INTO sessions (studentId, groupId, studentName, groupName, academy, subject, sessionDate, startTime, durationMinutes, status, timetableSlotId, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', ?, ?)`,
        slot.studentId,
        slot.groupId,
        student?.name ?? null,
        group?.name ?? null,
        student?.academy ?? group?.academy ?? null,
        slot.subject ?? student?.subject ?? group?.subject ?? null,
        date,
        slot.startTime,
        Math.max(15, slot.durationMinutes),
        slot.id,
        createdAt()
      );
      created += result.changes;
    }
  });
  return created;
}

export async function listSessions(date?: string) {
  const db = await getDb();
  if (date) {
    return db.getAllAsync<LessonSession>(
      "SELECT * FROM sessions WHERE sessionDate = ? ORDER BY startTime ASC, id DESC",
      date
    );
  }
  return db.getAllAsync<LessonSession>(
    "SELECT * FROM sessions ORDER BY sessionDate DESC, startTime DESC, id DESC LIMIT 120"
  );
}

export async function listGroupSessions(groupId: number) {
  const db = await getDb();
  return db.getAllAsync<LessonSession>(
    "SELECT * FROM sessions WHERE groupId = ? ORDER BY sessionDate DESC, startTime DESC, id DESC",
    groupId
  );
}

export async function createSession(input: {
  studentId?: number | null;
  groupId?: number | null;
  studentName?: string | null;
  groupName?: string | null;
  academy?: string | null;
  subject?: string | null;
  sessionDate?: string;
  startTime: string;
  durationMinutes?: number;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO sessions (studentId, groupId, studentName, groupName, academy, subject, sessionDate, startTime, durationMinutes, status, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', ?)`,
    input.studentId ?? null,
    input.groupId ?? null,
    input.studentName?.trim() || null,
    input.groupName?.trim() || null,
    input.academy?.trim() || null,
    input.subject?.trim() || null,
    input.sessionDate ?? localIsoDate(),
    input.startTime,
    input.durationMinutes ?? 60,
    createdAt()
  );
  return Number(result.lastInsertRowId);
}

export async function startSession(id: number) {
  const db = await getDb();
  await db.runAsync("UPDATE sessions SET status = 'in_progress' WHERE id = ? AND status = 'scheduled'", id);
}

export async function updateScheduledSession(input: {
  id: number;
  sessionDate: string;
  startTime: string;
  durationMinutes: number;
}) {
  const db = await getDb();
  const existing = await db.getFirstAsync<LessonSession>("SELECT * FROM sessions WHERE id = ?", input.id);
  if (existing?.timetableSlotId != null) {
    await db.runAsync(
      "INSERT OR REPLACE INTO timetable_exceptions (timetableSlotId, sessionDate, createdAt) VALUES (?, ?, ?)",
      existing.timetableSlotId, existing.sessionDate, createdAt()
    );
  }
  const result = await db.runAsync(
    `UPDATE sessions SET sessionDate = ?, startTime = ?, durationMinutes = ?, timetableSlotId = NULL
     WHERE id = ? AND status != 'completed'`,
    input.sessionDate,
    input.startTime,
    Math.max(15, input.durationMinutes),
    input.id
  );
  if (!result.changes) throw new Error("لا يمكن تعديل موعد حصة مكتملة من هذه الشاشة");
}

export async function completeSession(input: {
  id: number;
  attendance: "حاضر" | "غائب" | "متأخر";
  homework?: string | null;
  previousHomeworkDone?: number | null;
  notes?: string | null;
  groupAttendance?: Array<{ studentId: number; status: Attendance }>;
}) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    const session = await db.getFirstAsync<LessonSession>("SELECT * FROM sessions WHERE id = ?", input.id);
    if (!session) throw new Error("الحصة غير موجودة على هذا الجهاز");
    if (session.status === "completed") {
      await db.runAsync(
        `UPDATE sessions SET attendance = ?, homework = ?, previousHomeworkDone = ?, notes = ? WHERE id = ?`,
        input.attendance, input.homework?.trim() || null, input.previousHomeworkDone ?? null,
        input.notes?.trim() || null, input.id
      );
      return;
    }
    const sequence = session.studentId
      ? await db.getFirstAsync<{ nextNumber: number }>("SELECT COUNT(*) + 1 AS nextNumber FROM sessions WHERE studentId = ? AND status = 'completed'", session.studentId)
      : session.groupId
        ? await db.getFirstAsync<{ nextNumber: number }>("SELECT COUNT(*) + 1 AS nextNumber FROM sessions WHERE groupId = ? AND status = 'completed'", session.groupId)
        : { nextNumber: 1 };
    await db.runAsync(
      `UPDATE sessions SET status = 'completed', attendance = ?, homework = ?, previousHomeworkDone = ?, notes = ?, sessionNumber = ? WHERE id = ?`,
      input.attendance,
      input.homework?.trim() || null,
      input.previousHomeworkDone ?? null,
      input.notes?.trim() || null,
      sequence?.nextNumber ?? 1,
      input.id
    );
    if (session.studentId) {
      await db.runAsync(
        `UPDATE students SET completedSessions = completedSessions + 1,
         remainingSessions = CASE WHEN remainingSessions > 0 THEN remainingSessions - 1 ELSE 0 END,
         lastNotes = COALESCE(?, lastNotes) WHERE id = ?`,
        input.notes?.trim() || null,
        session.studentId
      );
    }
    if (session.groupId) {
      await db.runAsync(
        `UPDATE groups SET completedSessions = completedSessions + 1,
         remainingSessions = CASE WHEN remainingSessions > 0 THEN remainingSessions - 1 ELSE 0 END,
         notes = COALESCE(?, notes) WHERE id = ?`,
        input.notes?.trim() || null,
        session.groupId
      );
      const members = await db.getAllAsync<{ studentId: number }>(
        "SELECT studentId FROM group_enrollments WHERE groupId = ? AND status = 'active'",
        session.groupId
      );
      const attendanceByStudent = new Map((input.groupAttendance ?? []).map(item => [item.studentId, item.status]));
      for (const member of members) {
        const status = attendanceByStudent.get(member.studentId) ?? input.attendance;
        const inserted = await db.runAsync(
          "INSERT OR IGNORE INTO attendance_records (sessionId,studentId,status,recordedAt,notes,countedInStudentTotals) VALUES (?,?,?,?,?,1)",
          session.id, member.studentId, status, createdAt(), null
        );
        if (inserted.changes === 1) {
          await db.runAsync(
            "UPDATE students SET completedSessions = completedSessions + 1, remainingSessions = MAX(0, remainingSessions - 1) WHERE id = ?",
            member.studentId
          );
        } else {
          const existing = await db.getFirstAsync<{ countedInStudentTotals: number }>(
            "SELECT countedInStudentTotals FROM attendance_records WHERE sessionId = ? AND studentId = ?",
            session.id, member.studentId
          );
          await db.runAsync(
            "UPDATE attendance_records SET status = ?, recordedAt = ?, countedInStudentTotals = 1 WHERE sessionId = ? AND studentId = ?",
            status, createdAt(), session.id, member.studentId
          );
          if (!existing?.countedInStudentTotals) {
            await db.runAsync(
              "UPDATE students SET completedSessions = completedSessions + 1, remainingSessions = MAX(0, remainingSessions - 1) WHERE id = ?",
              member.studentId
            );
          }
        }
      }
    }
  });
}

export async function deleteSession(id: number) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    const session = await db.getFirstAsync<LessonSession>("SELECT * FROM sessions WHERE id = ?", id);
    if (!session) return;
    if (session.timetableSlotId != null) {
      await db.runAsync(
        "INSERT OR REPLACE INTO timetable_exceptions (timetableSlotId, sessionDate, createdAt) VALUES (?, ?, ?)",
        session.timetableSlotId, session.sessionDate, createdAt()
      );
    }
    if (session.status === "completed") {
      if (session.studentId) {
        await db.runAsync(
          "UPDATE students SET completedSessions = MAX(0, completedSessions - 1), remainingSessions = remainingSessions + 1 WHERE id = ?",
          session.studentId
        );
      }
      if (session.groupId) {
        await db.runAsync(
          "UPDATE groups SET completedSessions = MAX(0, completedSessions - 1), remainingSessions = remainingSessions + 1 WHERE id = ?",
          session.groupId
        );
        const countedRows = await db.getAllAsync<{ studentId: number }>(
          "SELECT studentId FROM attendance_records WHERE sessionId = ? AND countedInStudentTotals = 1",
          id
        );
        for (const row of countedRows) {
          await db.runAsync(
            "UPDATE students SET completedSessions = MAX(0, completedSessions - 1), remainingSessions = remainingSessions + 1 WHERE id = ?",
            row.studentId
          );
        }
      }
    }
    await db.runAsync("DELETE FROM sessions WHERE id = ?", id);
  });
}

export async function updateCompletedSession(input: {
  id: number;
  attendance: "حاضر" | "غائب" | "متأخر";
  homework?: string | null;
  previousHomeworkDone?: number | null;
  notes?: string | null;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `UPDATE sessions SET attendance = ?, homework = ?, previousHomeworkDone = ?, notes = ?
     WHERE id = ? AND status = 'completed'`,
    input.attendance,
    input.homework?.trim() || null,
    input.previousHomeworkDone ?? null,
    input.notes?.trim() || null,
    input.id
  );
  if (!result.changes) throw new Error("الحصة ليست مكتملة أو لم تعد موجودة");
}

export async function listTransactions() {
  const db = await getDb();
  return db.getAllAsync<FinanceTransaction>(
    `SELECT financeTransactions.*, students.name AS studentName
     FROM financeTransactions LEFT JOIN students ON students.id = financeTransactions.studentId
     ORDER BY transactionDate DESC, financeTransactions.id DESC`
  );
}

export async function createTransaction(input: {
  type: FinanceTransaction["type"];
  amount: number;
  description?: string | null;
  transactionDate?: string;
  studentId?: number | null;
}) {
  const db = await getDb();
  const amount = Number(input.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("يجب إدخال مبلغ أكبر من صفر");
  const studentId = input.studentId ?? null;
  if (input.type === "discount" && studentId === null) {
    throw new Error("يجب ربط الخصم بحساب طالب محدد");
  }
  if (studentId !== null) {
    const student = await db.getFirstAsync<Pick<Student, "id" | "subscriptionAmount">>(
      "SELECT id, subscriptionAmount FROM students WHERE id = ?", studentId
    );
    if (!student) throw new Error("الطالب المحدد غير موجود");
    const totals = await db.getFirstAsync<{ paid: number; refunded: number; discounts: number }>(
      `SELECT
        COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) AS paid,
        COALESCE(SUM(CASE WHEN type = 'refund' THEN amount ELSE 0 END), 0) AS refunded,
        COALESCE(SUM(CASE WHEN type = 'discount' THEN amount ELSE 0 END), 0) AS discounts
       FROM financeTransactions WHERE studentId = ?`, studentId
    );
    if (input.type === "discount") {
      const outstanding = Math.max(0, (student.subscriptionAmount ?? 0) - (totals?.discounts ?? 0) - (totals?.paid ?? 0) + (totals?.refunded ?? 0));
      if (amount > outstanding) throw new Error(`قيمة الخصم أكبر من المبلغ المتبقي (${outstanding.toFixed(2)} جنيه)`);
    }
    if (input.type === "refund") {
      const refundable = Math.max(0, (totals?.paid ?? 0) - (totals?.refunded ?? 0));
      if (amount > refundable) throw new Error(`قيمة الاسترداد أكبر من صافي ما دفعه الطالب (${refundable.toFixed(2)} جنيه)`);
    }
  }
  const result = await db.runAsync(
    "INSERT INTO financeTransactions (type, amount, description, transactionDate, studentId, createdAt) VALUES (?, ?, ?, ?, ?, ?)",
    input.type,
    amount,
    input.description?.trim() || null,
    input.transactionDate ?? localIsoDate(),
    studentId,
    createdAt()
  );
  return Number(result.lastInsertRowId);
}

export async function deleteTransaction(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM financeTransactions WHERE id = ?", id);
}

export async function listTimetable() {
  const db = await getDb();
  return db.getAllAsync<TimetableSlot>(
    "SELECT * FROM timetable WHERE active = 1 ORDER BY dayOfWeek ASC, startTime ASC"
  );
}

export async function listAllTimetable() {
  const db = await getDb();
  return db.getAllAsync<TimetableSlot>(
    "SELECT * FROM timetable ORDER BY active DESC, dayOfWeek ASC, startTime ASC"
  );
}

export async function createTimetableSlot(input: Omit<TimetableSlot, "id" | "active"> & { active?: number }) {
  const db = await getDb();
  const result = await db.runAsync(
    "INSERT INTO timetable (studentId, groupId, title, dayOfWeek, startTime, durationMinutes, subject, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
    input.studentId ?? null,
    input.groupId ?? null,
    input.title.trim(),
    input.dayOfWeek,
    input.startTime,
    input.durationMinutes,
    input.subject?.trim() || null,
    input.active ?? 1
  );
  return Number(result.lastInsertRowId);
}

export type TimetableSlotInput = Omit<TimetableSlot, "id" | "active"> & { active?: number };

export async function createRecurringTimetableSlots(inputs: TimetableSlotInput[]) {
  if (!inputs.length) throw new Error("اختاري يومًا واحدًا على الأقل للجدول المتكرر");
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    for (const input of inputs) {
      if (!input.title.trim() || !input.dayOfWeek.trim() || !/^\d{2}:\d{2}$/.test(input.startTime)) {
        throw new Error("بيانات الموعد المتكرر غير مكتملة");
      }
      await db.runAsync(
        "INSERT INTO timetable (studentId, groupId, title, dayOfWeek, startTime, durationMinutes, subject, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        input.studentId ?? null,
        input.groupId ?? null,
        input.title.trim(),
        input.dayOfWeek,
        input.startTime,
        Math.max(15, input.durationMinutes),
        input.subject?.trim() || null,
        input.active ?? 1
      );
    }
  });
  return inputs.length;
}

export async function updateTimetableSlot(input: {
  id: number;
  dayOfWeek: string;
  startTime: string;
  durationMinutes: number;
}) {
  const db = await getDb();
  await db.runAsync(
    "UPDATE timetable SET dayOfWeek = ?, startTime = ?, durationMinutes = ? WHERE id = ?",
    input.dayOfWeek,
    input.startTime,
    Math.max(15, input.durationMinutes),
    input.id
  );
  // Keep an already-created, not-yet-started session for today in sync with its weekly slot.
  await db.runAsync(
    `UPDATE sessions SET startTime = ?, durationMinutes = ?
     WHERE timetableSlotId = ? AND sessionDate = ? AND status = 'scheduled'`,
    input.startTime, Math.max(15, input.durationMinutes), input.id, localIsoDate()
  );
}

export async function setTimetableSlotActive(id: number, active: boolean) {
  const db = await getDb();
  await db.runAsync("UPDATE timetable SET active = ? WHERE id = ?", active ? 1 : 0, id);
}

export async function deleteTimetableSlot(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM timetable WHERE id = ?", id);
}

export async function getSnapshot(): Promise<DashboardSnapshot> {
  const [students, sessions, groups, transactions, timetable] = await Promise.all([
    listStudents(),
    listSessions(),
    listGroups(),
    listTransactions(),
    listAllTimetable(),
  ]);
  return { students, sessions, groups, transactions, timetable };
}

export async function exportBackup(): Promise<NativeBackup> {
  const db = await getDb();
  // Backups must be complete: dashboard list limits must never truncate an archive.
  const [students, sessions, groups, transactions, timetable, timetableExceptions, subjects, studentSubjects, groupEnrollments, attendanceRecords, questionBank, exams, examResults, studentHomework, studentAcademicNotes, historicalSessions, documents] = await Promise.all([
    db.getAllAsync<Student>("SELECT * FROM students ORDER BY id"),
    db.getAllAsync<LessonSession>("SELECT * FROM sessions ORDER BY id"),
    db.getAllAsync<TutoringGroup>("SELECT * FROM groups ORDER BY id"),
    db.getAllAsync<FinanceTransaction>("SELECT * FROM financeTransactions ORDER BY id"),
    db.getAllAsync<TimetableSlot>("SELECT * FROM timetable ORDER BY id"),
    db.getAllAsync<TimetableException>("SELECT * FROM timetable_exceptions ORDER BY sessionDate, timetableSlotId"),
    db.getAllAsync<AcademySubject>("SELECT * FROM subjects ORDER BY sortOrder, id"),
    db.getAllAsync<StudentSubject>("SELECT * FROM student_subjects ORDER BY studentId, subjectId"),
    db.getAllAsync<GroupEnrollment>("SELECT * FROM group_enrollments ORDER BY id"),
    db.getAllAsync<AttendanceRecord>("SELECT * FROM attendance_records ORDER BY id"),
    db.getAllAsync<AcademyQuestion>("SELECT * FROM question_bank ORDER BY id"),
    db.getAllAsync<AcademyExam>("SELECT * FROM academy_exams ORDER BY id"),
    db.getAllAsync<ExamResult>("SELECT * FROM exam_results ORDER BY id"),
    db.getAllAsync<StudentHomework>("SELECT * FROM student_homework ORDER BY id"),
    db.getAllAsync<StudentAcademicNote>("SELECT * FROM student_academic_notes ORDER BY id"),
    db.getAllAsync<HistoricalSessionRecord>("SELECT * FROM historical_sessions ORDER BY id"),
    db.getAllAsync<AcademyDocument>("SELECT * FROM academy_documents ORDER BY id"),
  ]);
  return {
    schema: "naneice-desk-native",
    version: 10,
    exportedAt: createdAt(),
    students, sessions, groups, transactions, timetable, timetableExceptions,
    subjects, studentSubjects, groupEnrollments, attendanceRecords, questionBank, exams, examResults, studentHomework, studentAcademicNotes, historicalSessions, documents,
  };
}

async function clearAllTables(db: SQLite.SQLiteDatabase) {
  await db.execAsync(`
    DELETE FROM attendance_records;
    DELETE FROM exam_results;
    DELETE FROM student_homework;
    DELETE FROM student_academic_notes;
    DELETE FROM historical_sessions;
    DELETE FROM academy_exams;
    DELETE FROM question_bank;
    DELETE FROM group_enrollments;
    DELETE FROM student_subjects;
    DELETE FROM sessions;
    DELETE FROM timetable_exceptions;
    DELETE FROM timetable;
    DELETE FROM financeTransactions;
    DELETE FROM students;
    DELETE FROM groups;
    DELETE FROM subjects;
  `);
}

export async function restoreNativeBackup(backup: NativeBackup) {
  if (backup.schema !== "naneice-desk-native" || ![1, 2, 3, 4, 5, 6, 7, 8, 9, 10].includes(backup.version)) {
    throw new Error("صيغة النسخة الاحتياطية غير مدعومة");
  }
  if (!Array.isArray(backup.students) || !Array.isArray(backup.sessions) || !Array.isArray(backup.groups) || !Array.isArray(backup.transactions) || !Array.isArray(backup.timetable)) {
    throw new Error("النسخة الاحتياطية غير مكتملة؛ لم يتم تغيير بيانات التطبيق");
  }
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await clearAllTables(db);
    for (const subject of backup.subjects ?? SUBJECTS) {
      await db.runAsync(
        "INSERT OR REPLACE INTO subjects (id, nameAr, nameEn, active, sortOrder) VALUES (?, ?, ?, ?, ?)",
        subject.id, subject.nameAr, subject.nameEn, subject.active, subject.sortOrder
      );
    }
    for (const student of backup.students ?? []) {
      await db.runAsync(
        "INSERT INTO students (id, name, academy, subject, phone, totalSessions, completedSessions, remainingSessions, lastNotes, active, subscriptionAmount, subscriptionDueDate, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        student.id, student.name, student.academy, student.subject, student.phone,
        student.totalSessions, student.completedSessions, student.remainingSessions,
        student.lastNotes, student.active, student.subscriptionAmount ?? 0, student.subscriptionDueDate ?? null, student.createdAt
      );
    }
    for (const group of backup.groups ?? []) {
      await db.runAsync(
        "INSERT INTO groups (id, name, academy, subject, capacity, memberNames, totalSessions, completedSessions, remainingSessions, notes, active, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        group.id, group.name, group.academy, group.subject, group.capacity, group.memberNames,
        group.totalSessions, group.completedSessions, group.remainingSessions, group.notes, group.active ?? 1, group.createdAt
      );
    }
    for (const item of backup.studentSubjects ?? []) {
      await db.runAsync(
        "INSERT INTO student_subjects (studentId, subjectId, createdAt) VALUES (?, ?, ?)",
        item.studentId, item.subjectId, item.createdAt
      );
    }
    for (const enrollment of backup.groupEnrollments ?? []) {
      await db.runAsync(
        "INSERT INTO group_enrollments (id, studentId, groupId, subjectId, status, startDate, endDate, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        enrollment.id, enrollment.studentId, enrollment.groupId, enrollment.subjectId,
        enrollment.status, enrollment.startDate, enrollment.endDate, enrollment.createdAt
      );
    }
    for (const session of backup.sessions ?? []) {
      await db.runAsync(
        "INSERT INTO sessions (id, studentId, groupId, studentName, groupName, academy, subject, sessionDate, startTime, durationMinutes, status, attendance, homework, previousHomeworkDone, notes, sessionNumber, timetableSlotId, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        session.id, session.studentId, session.groupId, session.studentName, session.groupName,
        session.academy, session.subject, session.sessionDate, session.startTime,
        session.durationMinutes, session.status, session.attendance, session.homework,
        session.previousHomeworkDone, session.notes, session.sessionNumber ?? null, session.timetableSlotId ?? null, session.createdAt
      );
    }
    for (const attendance of backup.attendanceRecords ?? []) {
      await db.runAsync(
        "INSERT INTO attendance_records (id, sessionId, studentId, status, recordedAt, notes, countedInStudentTotals) VALUES (?, ?, ?, ?, ?, ?, ?)",
        attendance.id, attendance.sessionId, attendance.studentId, attendance.status,
        attendance.recordedAt, attendance.notes, attendance.countedInStudentTotals ?? 0
      );
    }
    for (const question of backup.questionBank ?? []) {
      await db.runAsync(
        "INSERT INTO question_bank (id,grade,subject,lesson,questionType,prompt,optionsJson,correctAnswer,explanation,marks,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        question.id, question.grade, question.subject, question.lesson, question.questionType,
        question.prompt, question.optionsJson, question.correctAnswer, question.explanation, question.marks, question.createdAt
      );
    }
    for (const exam of backup.exams ?? []) {
      await db.runAsync(
        "INSERT INTO academy_exams (id,title,grade,subject,lesson,targetType,targetId,targetStudentIdsJson,durationMinutes,examDate,totalMarks,questionsJson,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        exam.id, exam.title, exam.grade, exam.subject, exam.lesson, exam.targetType, exam.targetId,
        exam.targetStudentIdsJson, exam.durationMinutes, exam.examDate, exam.totalMarks, exam.questionsJson, exam.createdAt
      );
    }
    for (const result of backup.examResults ?? []) {
      await db.runAsync(
        "INSERT INTO exam_results (id,examId,studentId,score,feedback,gradedAt) VALUES (?,?,?,?,?,?)",
        result.id, result.examId, result.studentId, result.score, result.feedback, result.gradedAt
      );
    }
    for (const homework of backup.studentHomework ?? []) {
      await db.runAsync(
        "INSERT INTO student_homework (id,studentId,subject,lesson,description,dueDate,status,teacherNote,createdAt) VALUES (?,?,?,?,?,?,?,?,?)",
        homework.id, homework.studentId, homework.subject, homework.lesson, homework.description,
        homework.dueDate, homework.status, homework.teacherNote, homework.createdAt
      );
    }
    for (const note of backup.studentAcademicNotes ?? []) {
      await db.runAsync(
        "INSERT INTO student_academic_notes (id,studentId,subject,title,body,createdAt) VALUES (?,?,?,?,?,?)",
        note.id, note.studentId, note.subject, note.title, note.body, note.createdAt
      );
    }
    for (const historical of backup.historicalSessions ?? []) {
      await db.runAsync(
        "INSERT INTO historical_sessions (id,studentId,groupId,groupName,subject,entryType,sessionCount,sessionDate,attendance,homework,notes,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        historical.id, historical.studentId, historical.groupId, historical.groupName, historical.subject,
        historical.entryType, historical.sessionCount, historical.sessionDate, historical.attendance,
        historical.homework, historical.notes, historical.createdAt
      );
    }
    if (backup.documents) {
      await db.runAsync("DELETE FROM academy_documents");
      for (const document of backup.documents) {
        await db.runAsync(
          "INSERT INTO academy_documents (id,title,fileName,fileUri,mimeType,sizeBytes,grade,subject,lesson,accessType,accessId,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
          document.id, document.title, document.fileName, document.fileUri, document.mimeType, document.sizeBytes,
          document.grade, document.subject, document.lesson, document.accessType, document.accessId, document.createdAt
        );
      }
    }
    for (const transaction of backup.transactions ?? []) {
      await db.runAsync(
        "INSERT INTO financeTransactions (id, type, amount, description, transactionDate, studentId, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)",
        transaction.id, transaction.type, transaction.amount, transaction.description,
        transaction.transactionDate, transaction.studentId ?? null, transaction.createdAt
      );
    }
    for (const slot of backup.timetable ?? []) {
      await db.runAsync(
        "INSERT INTO timetable (id, studentId, groupId, title, dayOfWeek, startTime, durationMinutes, subject, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        slot.id, slot.studentId, slot.groupId, slot.title, slot.dayOfWeek, slot.startTime,
        slot.durationMinutes, slot.subject, slot.active
      );
    }
    for (const exception of backup.timetableExceptions ?? []) {
      await db.runAsync(
        "INSERT OR REPLACE INTO timetable_exceptions (timetableSlotId, sessionDate, createdAt) VALUES (?, ?, ?)",
        exception.timetableSlotId, exception.sessionDate, exception.createdAt
      );
    }
  });
  // Version 1 backups predate the normalized subject relation.
  await migrateLegacyStudentSubjects(db);
}

export async function importLegacyBackup(backup: LegacyBackup) {
  const existingNames = new Set((await listStudents()).map(student => student.name.trim().toLocaleLowerCase("ar-EG")));
  let imported = 0;
  for (const student of backup.students ?? []) {
    const normalizedName = student.name?.trim();
    if (!normalizedName || existingNames.has(normalizedName.toLocaleLowerCase("ar-EG"))) continue;
    await createStudent({
      name: normalizedName,
      academy: backup.academies?.[0]?.name ?? null,
      subject: student.subject ?? null,
      phone: student.phone ?? student.parentPhone ?? null,
      totalSessions: student.totalSessions ?? 0,
      completedSessions: student.completedSessions ?? 0,
      remainingSessions: student.remainingSessions ?? student.totalSessions ?? 0,
      lastNotes: student.lastNotes ?? null,
    });
    existingNames.add(normalizedName.toLocaleLowerCase("ar-EG"));
    imported += 1;
  }
  return imported;
}

export function todayDate() {
  return localIsoDate();
}
