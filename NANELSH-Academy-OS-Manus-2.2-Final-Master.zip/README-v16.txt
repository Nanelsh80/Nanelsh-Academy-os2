NANELSH Academy OS — Manus 2.2 Master v16
Notifications: real native local notifications with custom sound, Android high-importance channel, vibration, banner/list display, and 30-minute session reminders.
Requires a rebuilt native Android/iOS binary because expo-notifications is a native module.
