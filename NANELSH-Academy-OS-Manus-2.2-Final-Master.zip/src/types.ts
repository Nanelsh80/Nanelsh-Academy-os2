export type Attendance = "حاضر" | "غائب" | "متأخر" | "بعذر";
export type SessionStatus = "scheduled" | "in_progress" | "completed";

export type AttendanceRecord = {
  id: number;
  sessionId: number | null;
  groupId: number | null;
  studentId: number;
  studentName: string;
  attendanceDate: string;
  status: Attendance;
  notes: string | null;
  createdAt: string;
};
export type TransactionType = "income" | "expense" | "refund" | "discount";

export type Exam = {
  id: number;
  title: string;
  track: string | null;
  grade: string | null;
  britishLevel: string | null;
  examBoard: string | null;
  qualification: string | null;
  subject: string | null;
  groupId: number | null;
  groupName: string | null;
  examDate: string;
  maxScore: number;
  notes: string | null;
  createdAt: string;
};

export type ExamScore = {
  id: number;
  examId: number;
  studentId: number;
  studentName: string;
  score: number;
  percentage: number;
  gradeLetter: string | null;
  notes: string | null;
  createdAt: string;
};

export type Student = {
  id: number;
  name: string;
  academy: string | null;
  track: string | null;
  grade: string | null;
  britishLevel: string | null;
  examBoard: string | null;
  qualification: string | null;
  subject: string | null;
  phone: string | null;
  totalSessions: number;
  completedSessions: number;
  remainingSessions: number;
  lastNotes: string | null;
  active: number;
  createdAt: string;
};

export type LessonSession = {
  id: number;
  studentId: number | null;
  groupId: number | null;
  studentName: string | null;
  groupName: string | null;
  academy: string | null;
  grade: string | null;
  britishLevel: string | null;
  examBoard: string | null;
  qualification: string | null;
  subject: string | null;
  sessionDate: string;
  startTime: string;
  durationMinutes: number;
  status: SessionStatus;
  attendance: Attendance | null;
  homework: string | null;
  previousHomeworkDone: number | null;
  notes: string | null;
  createdAt: string;
};

export type GroupMember = {
  id: number;
  groupId: number;
  studentId: number;
  studentName: string;
  active: number;
  createdAt: string;
};

export type TutoringGroup = {
  id: number;
  name: string;
  academy: string | null;
  track: string | null;
  grade: string | null;
  britishLevel: string | null;
  examBoard: string | null;
  qualification: string | null;
  subject: string | null;
  capacity: number;
  memberNames: string | null;
  totalSessions: number;
  completedSessions: number;
  remainingSessions: number;
  notes: string | null;
  createdAt: string;
};

export type StudentPayment = {
  id: number;
  studentId: number;
  studentName: string;
  amount: number;
  paymentDate: string;
  method: string | null;
  reference: string | null;
  notes: string | null;
  createdAt: string;
};

export type StudentSubscription = {
  id: number;
  studentId: number;
  studentName: string;
  totalAmount: number;
  paidAmount: number;
  discountAmount: number;
  balance: number;
  status: "active" | "partial" | "paid" | "overdue";
  renewalDate: string | null;
  notes: string | null;
  createdAt: string;
};

export type FinanceTransaction = {
  id: number;
  type: TransactionType;
  amount: number;
  description: string | null;
  transactionDate: string;
  createdAt: string;
};

export type TimetableSlot = {
  id: number;
  studentId: number | null;
  groupId: number | null;
  title: string;
  dayOfWeek: string;
  startTime: string;
  durationMinutes: number;
  subject: string | null;
  active: number;
};

export type DashboardSnapshot = {
  students: Student[];
  sessions: LessonSession[];
  groups: TutoringGroup[];
  transactions: FinanceTransaction[];
  timetable: TimetableSlot[];
  exams: Exam[];
  examScores: ExamScore[];
  attendanceRecords: AttendanceRecord[];
  subscriptions: StudentSubscription[];
  payments: StudentPayment[];
};

export type NativeBackup = {
  schema: "naneice-desk-native";
  version: 1;
  exportedAt: string;
  students: Student[];
  sessions: LessonSession[];
  groups: TutoringGroup[];
  transactions: FinanceTransaction[];
  timetable: TimetableSlot[];
  exams: Exam[];
  examScores: ExamScore[];
  attendanceRecords: AttendanceRecord[];
  subscriptions: StudentSubscription[];
  payments: StudentPayment[];
};

export type LegacyBackup = {
  academies?: Array<{ name: string }>;
  students?: Array<{
    name: string;
    subject?: string | null;
    phone?: string | null;
    parentPhone?: string | null;
    totalSessions?: number;
    completedSessions?: number;
    remainingSessions?: number;
    lastNotes?: string | null;
  }>;
};
