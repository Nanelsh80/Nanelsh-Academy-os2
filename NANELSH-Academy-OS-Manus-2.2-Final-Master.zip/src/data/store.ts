import * as SQLite from "expo-sqlite";
import type {
  DashboardSnapshot,
  FinanceTransaction,
  LegacyBackup,
  LessonSession,
  NativeBackup,
  Student,
  TimetableSlot,
  TutoringGroup,
  GroupMember,
  Exam,
  ExamScore,
  AttendanceRecord,
  StudentSubscription,
  StudentPayment,
} from "../types";

const DATABASE_NAME = "naneice-desk-native.db";
let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

function localIsoDate(date = new Date()) {
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 10);
}

function createdAt() {
  return new Date().toISOString();
}

async function getDb() {
  if (!databasePromise) {
    databasePromise = SQLite.openDatabaseAsync(DATABASE_NAME);
  }
  const db = await databasePromise;
  await db.execAsync("PRAGMA foreign_keys = ON;");
  return db;
}

export async function initializeStore() {
  const db = await getDb();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      academy TEXT,
      track TEXT,
      grade TEXT,
      britishLevel TEXT,
      examBoard TEXT,
      qualification TEXT,
      subject TEXT,
      phone TEXT,
      totalSessions INTEGER NOT NULL DEFAULT 0,
      completedSessions INTEGER NOT NULL DEFAULT 0,
      remainingSessions INTEGER NOT NULL DEFAULT 0,
      lastNotes TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      academy TEXT,
      track TEXT,
      grade TEXT,
      britishLevel TEXT,
      examBoard TEXT,
      qualification TEXT,
      subject TEXT,
      capacity INTEGER NOT NULL DEFAULT 12,
      memberNames TEXT,
      totalSessions INTEGER NOT NULL DEFAULT 0,
      completedSessions INTEGER NOT NULL DEFAULT 0,
      remainingSessions INTEGER NOT NULL DEFAULT 0,
      notes TEXT,
      createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS groupMembers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      groupId INTEGER NOT NULL,
      studentId INTEGER NOT NULL,
      studentName TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      createdAt TEXT NOT NULL,
      UNIQUE(groupId, studentId),
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE CASCADE,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER,
      groupId INTEGER,
      studentName TEXT,
      groupName TEXT,
      academy TEXT,
      subject TEXT,
      sessionDate TEXT NOT NULL,
      startTime TEXT NOT NULL,
      durationMinutes INTEGER NOT NULL DEFAULT 60,
      status TEXT NOT NULL DEFAULT 'scheduled',
      attendance TEXT,
      homework TEXT,
      previousHomeworkDone INTEGER,
      notes TEXT,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE SET NULL,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS studentSubscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER NOT NULL UNIQUE,
      studentName TEXT NOT NULL,
      totalAmount REAL NOT NULL DEFAULT 0,
      paidAmount REAL NOT NULL DEFAULT 0,
      discountAmount REAL NOT NULL DEFAULT 0,
      balance REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      renewalDate TEXT,
      notes TEXT,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS studentPayments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER NOT NULL,
      studentName TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      paymentDate TEXT NOT NULL,
      method TEXT,
      reference TEXT,
      notes TEXT,
      createdAt TEXT NOT NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS financeTransactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      description TEXT,
      transactionDate TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS exams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL, track TEXT, grade TEXT, britishLevel TEXT, examBoard TEXT, qualification TEXT, subject TEXT,
      groupId INTEGER, groupName TEXT, examDate TEXT NOT NULL, maxScore REAL NOT NULL DEFAULT 100, notes TEXT, createdAt TEXT NOT NULL,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS examScores (
      id INTEGER PRIMARY KEY AUTOINCREMENT, examId INTEGER NOT NULL, studentId INTEGER NOT NULL, studentName TEXT NOT NULL,
      score REAL NOT NULL DEFAULT 0, percentage REAL NOT NULL DEFAULT 0, gradeLetter TEXT, notes TEXT, createdAt TEXT NOT NULL,
      UNIQUE(examId, studentId), FOREIGN KEY(examId) REFERENCES exams(id) ON DELETE CASCADE, FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS attendanceRecords (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sessionId INTEGER,
      groupId INTEGER,
      studentId INTEGER NOT NULL,
      studentName TEXT NOT NULL,
      attendanceDate TEXT NOT NULL,
      status TEXT NOT NULL,
      notes TEXT,
      createdAt TEXT NOT NULL,
      UNIQUE(sessionId, studentId),
      FOREIGN KEY(sessionId) REFERENCES sessions(id) ON DELETE CASCADE,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE SET NULL,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS timetable (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      studentId INTEGER,
      groupId INTEGER,
      title TEXT NOT NULL,
      dayOfWeek TEXT NOT NULL,
      startTime TEXT NOT NULL,
      durationMinutes INTEGER NOT NULL DEFAULT 60,
      subject TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY(studentId) REFERENCES students(id) ON DELETE CASCADE,
      FOREIGN KEY(groupId) REFERENCES groups(id) ON DELETE CASCADE
    );
  `);
  // v6 academic structure: preserve all existing data and add optional grade fields.
  // v14 group membership: migrate legacy comma-separated memberNames into relational membership rows.
  const legacyGroups = await db.getAllAsync<TutoringGroup>("SELECT * FROM groups WHERE memberNames IS NOT NULL AND TRIM(memberNames) != ''");
  for (const group of legacyGroups) {
    const existing = await db.getFirstAsync<{ count: number }>("SELECT COUNT(*) as count FROM groupMembers WHERE groupId = ?", group.id);
    if ((existing?.count ?? 0) > 0) continue;
    const names = (group.memberNames || "").split(",").map(name => name.trim()).filter(Boolean);
    for (const name of names) {
      const student = await db.getFirstAsync<Student>("SELECT * FROM students WHERE name = ? LIMIT 1", name);
      if (student) {
        await db.runAsync(
          `INSERT OR IGNORE INTO groupMembers (groupId, studentId, studentName, active, createdAt) VALUES (?, ?, ?, 1, ?)`,
          group.id, student.id, student.name, createdAt()
        );
      }
    }
  }

  for (const table of ["students", "groups"]) {
    const columns = await db.getAllAsync<{ name: string }>(`PRAGMA table_info(${table})`);
    if (!columns.some(column => column.name === "track")) {
      await db.execAsync(`ALTER TABLE ${table} ADD COLUMN track TEXT;`);
    }
    if (!columns.some(column => column.name === "grade")) {
      await db.execAsync(`ALTER TABLE ${table} ADD COLUMN grade TEXT;`);
    }
    if (!columns.some(column => column.name === "britishLevel")) await db.execAsync(`ALTER TABLE ${table} ADD COLUMN britishLevel TEXT;`);
    if (!columns.some(column => column.name === "examBoard")) await db.execAsync(`ALTER TABLE ${table} ADD COLUMN examBoard TEXT;`);
    if (!columns.some(column => column.name === "qualification")) await db.execAsync(`ALTER TABLE ${table} ADD COLUMN qualification TEXT;`);
  }
}

export async function listStudents() {
  const db = await getDb();
  return db.getAllAsync<Student>("SELECT * FROM students ORDER BY active DESC, name COLLATE NOCASE ASC");
}

export async function createStudent(input: {
  name: string;
  academy?: string | null;
  track?: string | null;
  grade?: string | null;
  britishLevel?: string | null;
  examBoard?: string | null;
  qualification?: string | null;
  subject?: string | null;
  phone?: string | null;
  totalSessions?: number;
  completedSessions?: number;
  remainingSessions?: number;
  lastNotes?: string | null;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO students (name, academy, track, grade, britishLevel, examBoard, qualification, subject, phone, totalSessions, completedSessions, remainingSessions, lastNotes, active, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    input.name.trim(),
    input.academy?.trim() || null,
    input.track?.trim() || null,
    input.grade?.trim() || null,
    input.britishLevel?.trim() || null,
    input.examBoard?.trim() || null,
    input.qualification?.trim() || null,
    input.subject?.trim() || null,
    input.phone?.trim() || null,
    input.totalSessions ?? 0,
    input.completedSessions ?? 0,
    input.remainingSessions ?? input.totalSessions ?? 0,
    input.lastNotes?.trim() || null,
    createdAt()
  );
  return Number(result.lastInsertRowId);
}

export async function updateStudent(id: number, input: Partial<Omit<Student, "id" | "createdAt">>) {
  const db = await getDb();
  const current = await db.getFirstAsync<Student>("SELECT * FROM students WHERE id = ?", id);
  if (!current) throw new Error("الطالب غير موجود على هذا الجهاز");
  await db.runAsync(
    `UPDATE students SET name = ?, academy = ?, track = ?, grade = ?, britishLevel = ?, examBoard = ?, qualification = ?, subject = ?, phone = ?, totalSessions = ?, completedSessions = ?, remainingSessions = ?, lastNotes = ?, active = ? WHERE id = ?`,
    input.name?.trim() ?? current.name,
    input.academy === undefined ? current.academy : input.academy?.trim() || null,
    input.track === undefined ? current.track : input.track?.trim() || null,
    input.grade === undefined ? current.grade : input.grade?.trim() || null,
    input.britishLevel === undefined ? current.britishLevel : input.britishLevel?.trim() || null,
    input.examBoard === undefined ? current.examBoard : input.examBoard?.trim() || null,
    input.qualification === undefined ? current.qualification : input.qualification?.trim() || null,
    input.subject === undefined ? current.subject : input.subject?.trim() || null,
    input.phone === undefined ? current.phone : input.phone?.trim() || null,
    input.totalSessions ?? current.totalSessions,
    input.completedSessions ?? current.completedSessions,
    input.remainingSessions ?? current.remainingSessions,
    input.lastNotes === undefined ? current.lastNotes : input.lastNotes?.trim() || null,
    input.active ?? current.active,
    id
  );
}

export async function deleteStudent(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM students WHERE id = ?", id);
}

export async function getStudentSessions(studentId: number) {
  const db = await getDb();
  return db.getAllAsync<LessonSession>(
    "SELECT * FROM sessions WHERE studentId = ? ORDER BY sessionDate DESC, startTime DESC, id DESC LIMIT 80",
    studentId
  );
}

export async function listGroups() {
  const db = await getDb();
  return db.getAllAsync<TutoringGroup>("SELECT * FROM groups ORDER BY name COLLATE NOCASE ASC");
}

export async function createGroup(input: {
  name: string;
  academy?: string | null;
  track?: string | null;
  grade?: string | null;
  britishLevel?: string | null;
  examBoard?: string | null;
  qualification?: string | null;
  subject?: string | null;
  capacity?: number;
  memberNames?: string | null;
  totalSessions?: number;
  remainingSessions?: number;
  notes?: string | null;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO groups (name, academy, track, grade, britishLevel, examBoard, qualification, subject, capacity, memberNames, totalSessions, completedSessions, remainingSessions, notes, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    input.name.trim(),
    input.academy?.trim() || null,
    input.track?.trim() || null,
    input.grade?.trim() || null,
    input.britishLevel?.trim() || null,
    input.examBoard?.trim() || null,
    input.qualification?.trim() || null,
    input.subject?.trim() || null,
    Math.max(1, input.capacity ?? 12),
    input.memberNames?.trim() || null,
    input.totalSessions ?? 0,
    input.remainingSessions ?? input.totalSessions ?? 0,
    input.notes?.trim() || null,
    createdAt()
  );
  return Number(result.lastInsertRowId);
}

export async function deleteGroup(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM groups WHERE id = ?", id);
}

export async function updateGroup(id: number, input: Partial<Omit<TutoringGroup, "id" | "createdAt">>) {
  const db = await getDb();
  const current = await db.getFirstAsync<TutoringGroup>("SELECT * FROM groups WHERE id = ?", id);
  if (!current) throw new Error("المجموعة غير موجودة على هذا الجهاز");
  const capacity = Math.max(1, input.capacity ?? current.capacity);
  await db.runAsync(
    `UPDATE groups SET name = ?, academy = ?, track = ?, grade = ?, britishLevel = ?, examBoard = ?, qualification = ?, subject = ?, capacity = ?, memberNames = ?,
     totalSessions = ?, completedSessions = ?, remainingSessions = ?, notes = ? WHERE id = ?`,
    input.name?.trim() ?? current.name,
    input.academy === undefined ? current.academy : input.academy?.trim() || null,
    input.track === undefined ? current.track : input.track?.trim() || null,
    input.grade === undefined ? current.grade : input.grade?.trim() || null,
    input.britishLevel === undefined ? current.britishLevel : input.britishLevel?.trim() || null,
    input.examBoard === undefined ? current.examBoard : input.examBoard?.trim() || null,
    input.qualification === undefined ? current.qualification : input.qualification?.trim() || null,
    input.subject === undefined ? current.subject : input.subject?.trim() || null,
    capacity,
    input.memberNames === undefined ? current.memberNames : input.memberNames?.trim() || null,
    input.totalSessions ?? current.totalSessions,
    input.completedSessions ?? current.completedSessions,
    input.remainingSessions ?? current.remainingSessions,
    input.notes === undefined ? current.notes : input.notes?.trim() || null,
    id
  );
}

export async function listGroupMembers(groupId: number) {
  const db = await getDb();
  return db.getAllAsync<GroupMember>(
    `SELECT gm.* FROM groupMembers gm WHERE gm.groupId = ? AND gm.active = 1 ORDER BY gm.studentName COLLATE NOCASE ASC`,
    groupId
  );
}

export async function syncGroupMembers(groupId: number, studentIds: number[]) {
  const db = await getDb();
  const uniqueIds = [...new Set(studentIds.map(Number).filter(Number.isFinite))];
  await db.withTransactionAsync(async () => {
    const students = uniqueIds.length
      ? await db.getAllAsync<Student>(`SELECT * FROM students WHERE id IN (${uniqueIds.map(() => '?').join(',')})`, ...uniqueIds)
      : [];
    await db.runAsync("DELETE FROM groupMembers WHERE groupId = ?", groupId);
    for (const student of students) {
      await db.runAsync(
        `INSERT OR IGNORE INTO groupMembers (groupId, studentId, studentName, active, createdAt) VALUES (?, ?, ?, 1, ?)`,
        groupId, student.id, student.name, createdAt()
      );
    }
    const memberNames = students.map(student => student.name).join(', ');
    await db.runAsync("UPDATE groups SET memberNames = ? WHERE id = ?", memberNames || null, groupId);
  });
}

export async function addStudentToGroup(groupId: number, studentId: number) {
  const members = await listGroupMembers(groupId);
  await syncGroupMembers(groupId, [...members.map(member => member.studentId), studentId]);
}

export async function removeStudentFromGroup(groupId: number, studentId: number) {
  const members = await listGroupMembers(groupId);
  await syncGroupMembers(groupId, members.filter(member => member.studentId !== studentId).map(member => member.studentId));
}

export async function listSessions(date?: string) {
  const db = await getDb();
  if (date) {
    return db.getAllAsync<LessonSession>(
      "SELECT * FROM sessions WHERE sessionDate = ? ORDER BY startTime ASC, id DESC",
      date
    );
  }
  return db.getAllAsync<LessonSession>(
    "SELECT * FROM sessions ORDER BY sessionDate DESC, startTime DESC, id DESC LIMIT 120"
  );
}

export async function createSession(input: {
  studentId?: number | null;
  groupId?: number | null;
  studentName?: string | null;
  groupName?: string | null;
  academy?: string | null;
  subject?: string | null;
  sessionDate?: string;
  startTime: string;
  durationMinutes?: number;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `INSERT INTO sessions (studentId, groupId, studentName, groupName, academy, subject, sessionDate, startTime, durationMinutes, status, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', ?)`,
    input.studentId ?? null,
    input.groupId ?? null,
    input.studentName?.trim() || null,
    input.groupName?.trim() || null,
    input.academy?.trim() || null,
    input.subject?.trim() || null,
    input.sessionDate ?? localIsoDate(),
    input.startTime,
    input.durationMinutes ?? 60,
    createdAt()
  );
  return Number(result.lastInsertRowId);
}


export async function generateSessionsFromTimetable(daysAhead = 14) {
  const db = await getDb();
  const slots = await db.getAllAsync<TimetableSlot>("SELECT * FROM timetable WHERE active = 1");
  if (!slots.length) return 0;
  const dayMap: Record<string, number> = { "الأحد": 0, "الاثنين": 1, "الثلاثاء": 2, "الأربعاء": 3, "الخميس": 4, "الجمعة": 5, "السبت": 6 };
  const now = new Date();
  let inserted = 0;
  await db.withTransactionAsync(async () => {
    for (let offset = 0; offset <= daysAhead; offset += 1) {
      const date = new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset);
      const dateIso = localIsoDate(date);
      const dayName = Object.keys(dayMap).find(name => dayMap[name] === date.getDay());
      if (!dayName) continue;
      for (const slot of slots) {
        if (slot.dayOfWeek !== dayName) continue;
        const duplicate = await db.getFirstAsync<{ id: number }>(
          `SELECT id FROM sessions WHERE sessionDate = ? AND startTime = ? AND COALESCE(groupId, 0) = COALESCE(?, 0) AND COALESCE(studentId, 0) = COALESCE(?, 0) LIMIT 1`,
          dateIso, slot.startTime, slot.groupId ?? null, slot.studentId ?? null
        );
        if (duplicate) continue;
        let title = slot.title;
        let academy: string | null = null;
        let subject = slot.subject;
        let groupName: string | null = null;
        let studentName: string | null = null;
        if (slot.groupId) {
          const group = await db.getFirstAsync<TutoringGroup>("SELECT * FROM groups WHERE id = ?", slot.groupId);
          if (!group) continue;
          title = group.name; groupName = group.name; academy = group.academy; subject = subject || group.subject;
        } else if (slot.studentId) {
          const student = await db.getFirstAsync<Student>("SELECT * FROM students WHERE id = ?", slot.studentId);
          if (!student) continue;
          title = student.name; studentName = student.name; academy = student.academy; subject = subject || student.subject;
        } else continue;
        await db.runAsync(
          `INSERT INTO sessions (studentId, groupId, studentName, groupName, academy, subject, sessionDate, startTime, durationMinutes, status, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled', ?)`,
          slot.studentId ?? null, slot.groupId ?? null, studentName, groupName, academy, subject, dateIso, slot.startTime, slot.durationMinutes, createdAt()
        );
        inserted += 1;
      }
    }
  });
  return inserted;
}

export async function startSession(id: number) {
  const db = await getDb();
  await db.runAsync("UPDATE sessions SET status = 'in_progress' WHERE id = ? AND status = 'scheduled'", id);
}

export async function updateScheduledSession(input: {
  id: number;
  sessionDate: string;
  startTime: string;
  durationMinutes: number;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `UPDATE sessions SET sessionDate = ?, startTime = ?, durationMinutes = ?
     WHERE id = ? AND status != 'completed'`,
    input.sessionDate,
    input.startTime,
    Math.max(15, input.durationMinutes),
    input.id
  );
  if (!result.changes) throw new Error("لا يمكن تعديل موعد حصة مكتملة من هذه الشاشة");
}

export async function completeSession(input: {
  id: number;
  attendance: "حاضر" | "غائب" | "متأخر";
  homework?: string | null;
  previousHomeworkDone?: number | null;
  notes?: string | null;
}) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    const session = await db.getFirstAsync<LessonSession>("SELECT * FROM sessions WHERE id = ?", input.id);
    if (!session) throw new Error("الحصة غير موجودة على هذا الجهاز");
    await db.runAsync(
      `UPDATE sessions SET status = 'completed', attendance = ?, homework = ?, previousHomeworkDone = ?, notes = ? WHERE id = ?`,
      input.attendance,
      input.homework?.trim() || null,
      input.previousHomeworkDone ?? null,
      input.notes?.trim() || null,
      input.id
    );
    if (session.status === "completed") return;
    if (session.studentId) {
      await db.runAsync(
        `UPDATE students SET completedSessions = completedSessions + 1,
         remainingSessions = CASE WHEN remainingSessions > 0 THEN remainingSessions - 1 ELSE 0 END,
         lastNotes = COALESCE(?, lastNotes) WHERE id = ?`,
        input.notes?.trim() || null,
        session.studentId
      );
    }
    if (session.groupId) {
      await db.runAsync(
        `UPDATE groups SET completedSessions = completedSessions + 1,
         remainingSessions = CASE WHEN remainingSessions > 0 THEN remainingSessions - 1 ELSE 0 END,
         notes = COALESCE(?, notes) WHERE id = ?`,
        input.notes?.trim() || null,
        session.groupId
      );
      const members = await db.getAllAsync<GroupMember>(`SELECT * FROM groupMembers WHERE groupId = ? AND active = 1`, session.groupId);
      for (const member of members) {
        await db.runAsync(
          `INSERT INTO attendanceRecords (sessionId, groupId, studentId, studentName, attendanceDate, status, notes, createdAt)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(sessionId, studentId) DO UPDATE SET status=excluded.status, notes=excluded.notes`,
          session.id, session.groupId, member.studentId, member.studentName, session.sessionDate, input.attendance, input.notes?.trim() || null, createdAt()
        );
      }
    }
  });
}

export async function deleteSession(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM sessions WHERE id = ?", id);
}

export async function updateCompletedSession(input: {
  id: number;
  attendance: "حاضر" | "غائب" | "متأخر";
  homework?: string | null;
  previousHomeworkDone?: number | null;
  notes?: string | null;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    `UPDATE sessions SET attendance = ?, homework = ?, previousHomeworkDone = ?, notes = ?
     WHERE id = ? AND status = 'completed'`,
    input.attendance,
    input.homework?.trim() || null,
    input.previousHomeworkDone ?? null,
    input.notes?.trim() || null,
    input.id
  );
  if (!result.changes) throw new Error("الحصة ليست مكتملة أو لم تعد موجودة");
}

export async function getStudentSubscription(studentId: number) {
  const db = await getDb();
  return db.getFirstAsync<StudentSubscription>("SELECT * FROM studentSubscriptions WHERE studentId = ?", studentId);
}

export async function listStudentSubscriptions() {
  const db = await getDb();
  return db.getAllAsync<StudentSubscription>("SELECT * FROM studentSubscriptions ORDER BY balance DESC, studentName COLLATE NOCASE ASC");
}

export async function upsertStudentSubscription(input: { studentId: number; studentName: string; totalAmount: number; paidAmount: number; discountAmount?: number; renewalDate?: string | null; notes?: string | null }) {
  const db = await getDb();
  const totalAmount = Math.max(0, Number(input.totalAmount) || 0);
  const discountAmount = Math.max(0, Number(input.discountAmount) || 0);
  const paidAmount = Math.max(0, Math.min(Number(input.paidAmount) || 0, Math.max(0, totalAmount - discountAmount)));
  const balance = Math.max(0, totalAmount - discountAmount - paidAmount);
  const status: StudentSubscription["status"] = balance === 0 ? "paid" : paidAmount > 0 ? "partial" : "active";
  await db.runAsync(`INSERT INTO studentSubscriptions (studentId, studentName, totalAmount, paidAmount, discountAmount, balance, status, renewalDate, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(studentId) DO UPDATE SET studentName=excluded.studentName,totalAmount=excluded.totalAmount,paidAmount=excluded.paidAmount,discountAmount=excluded.discountAmount,balance=excluded.balance,status=excluded.status,renewalDate=excluded.renewalDate,notes=excluded.notes`, input.studentId, input.studentName, totalAmount, paidAmount, discountAmount, balance, status, input.renewalDate || null, input.notes?.trim() || null, createdAt());
}

export async function listStudentPayments(studentId?: number) {
  const db = await getDb();
  return studentId
    ? db.getAllAsync<StudentPayment>("SELECT * FROM studentPayments WHERE studentId = ? ORDER BY paymentDate DESC, id DESC", studentId)
    : db.getAllAsync<StudentPayment>("SELECT * FROM studentPayments ORDER BY paymentDate DESC, id DESC LIMIT 500");
}

export async function createStudentPayment(input: { studentId: number; studentName: string; amount: number; paymentDate?: string; method?: string | null; reference?: string | null; notes?: string | null }) {
  const db = await getDb();
  const amount = Math.max(0, Number(input.amount) || 0);
  if (!amount) throw new Error("قيمة الدفعة يجب أن تكون أكبر من صفر");
  return db.withTransactionAsync(async () => {
    const student = await db.getFirstAsync<Student>("SELECT id, name FROM students WHERE id = ?", input.studentId);
    if (!student) throw new Error("الطالبة غير موجودة");
    const account = await db.getFirstAsync<StudentSubscription>("SELECT * FROM studentSubscriptions WHERE studentId = ?", input.studentId);
    const maxPayable = account ? Math.max(0, account.totalAmount - account.discountAmount - account.paidAmount) : amount;
    const accepted = Math.min(amount, maxPayable || amount);
    const result = await db.runAsync(
      "INSERT INTO studentPayments (studentId, studentName, amount, paymentDate, method, reference, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      input.studentId, input.studentName.trim() || student.name, accepted, input.paymentDate ?? localIsoDate(), input.method?.trim() || null, input.reference?.trim() || null, input.notes?.trim() || null, createdAt()
    );
    if (account) {
      const paidAmount = Math.min(account.totalAmount - account.discountAmount, account.paidAmount + accepted);
      const balance = Math.max(0, account.totalAmount - account.discountAmount - paidAmount);
      const status: StudentSubscription["status"] = balance === 0 ? "paid" : paidAmount > 0 ? "partial" : "active";
      await db.runAsync("UPDATE studentSubscriptions SET paidAmount = ?, balance = ?, status = ? WHERE studentId = ?", paidAmount, balance, status, input.studentId);
    } else {
      await db.runAsync("INSERT INTO studentSubscriptions (studentId, studentName, totalAmount, paidAmount, discountAmount, balance, status, renewalDate, notes, createdAt) VALUES (?, ?, ?, ?, 0, ?, ?, NULL, NULL, ?)", input.studentId, input.studentName.trim() || student.name, accepted, accepted, 0, "paid", createdAt());
    }
    await db.runAsync("INSERT INTO financeTransactions (type, amount, description, transactionDate, createdAt) VALUES ('income', ?, ?, ?, ?)", accepted, `دفعة من ${input.studentName.trim() || student.name}`, input.paymentDate ?? localIsoDate(), createdAt());
    return Number(result.lastInsertRowId);
  });
}

export async function deleteStudentPayment(id: number) {
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    const payment = await db.getFirstAsync<StudentPayment>("SELECT * FROM studentPayments WHERE id = ?", id);
    if (!payment) return;
    await db.runAsync("DELETE FROM studentPayments WHERE id = ?", id);
    const account = await db.getFirstAsync<StudentSubscription>("SELECT * FROM studentSubscriptions WHERE studentId = ?", payment.studentId);
    if (account) {
      const paidAmount = Math.max(0, account.paidAmount - payment.amount);
      const balance = Math.max(0, account.totalAmount - account.discountAmount - paidAmount);
      const status: StudentSubscription["status"] = balance === 0 ? "paid" : paidAmount > 0 ? "partial" : "active";
      await db.runAsync("UPDATE studentSubscriptions SET paidAmount = ?, balance = ?, status = ? WHERE studentId = ?", paidAmount, balance, status, payment.studentId);
    }
  });
}

export async function listTransactions() {
  const db = await getDb();
  return db.getAllAsync<FinanceTransaction>(
    "SELECT * FROM financeTransactions ORDER BY transactionDate DESC, id DESC LIMIT 120"
  );
}

export async function createTransaction(input: {
  type: FinanceTransaction["type"];
  amount: number;
  description?: string | null;
  transactionDate?: string;
}) {
  const db = await getDb();
  const result = await db.runAsync(
    "INSERT INTO financeTransactions (type, amount, description, transactionDate, createdAt) VALUES (?, ?, ?, ?, ?)",
    input.type,
    Math.max(0, input.amount),
    input.description?.trim() || null,
    input.transactionDate ?? localIsoDate(),
    createdAt()
  );
  return Number(result.lastInsertRowId);
}

export async function deleteTransaction(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM financeTransactions WHERE id = ?", id);
}

export async function listAttendanceRecords() {
  const db = await getDb();
  return db.getAllAsync<AttendanceRecord>(
    "SELECT * FROM attendanceRecords ORDER BY attendanceDate DESC, id DESC LIMIT 500"
  );
}

export async function saveAttendanceRecord(input: {
  sessionId?: number | null; groupId?: number | null; studentId: number; studentName: string; attendanceDate: string; status: AttendanceRecord["status"]; notes?: string | null;
}) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO attendanceRecords (sessionId, groupId, studentId, studentName, attendanceDate, status, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(sessionId, studentId) DO UPDATE SET groupId=excluded.groupId, studentName=excluded.studentName, attendanceDate=excluded.attendanceDate, status=excluded.status, notes=excluded.notes`,
    input.sessionId ?? null, input.groupId ?? null, input.studentId, input.studentName.trim(), input.attendanceDate, input.status, input.notes?.trim() || null, createdAt()
  );
}

export async function deleteAttendanceRecord(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM attendanceRecords WHERE id = ?", id);
}

export async function listAttendanceForGroup(groupId: number, date?: string) {
  const db = await getDb();
  if (date) return db.getAllAsync<AttendanceRecord>("SELECT * FROM attendanceRecords WHERE groupId = ? AND attendanceDate = ? ORDER BY studentName COLLATE NOCASE ASC", groupId, date);
  return db.getAllAsync<AttendanceRecord>("SELECT * FROM attendanceRecords WHERE groupId = ? ORDER BY attendanceDate DESC, studentName COLLATE NOCASE ASC", groupId);
}

export async function listTimetable() {
  const db = await getDb();
  return db.getAllAsync<TimetableSlot>(
    "SELECT * FROM timetable WHERE active = 1 ORDER BY dayOfWeek ASC, startTime ASC"
  );
}

export async function listAllTimetable() {
  const db = await getDb();
  return db.getAllAsync<TimetableSlot>(
    "SELECT * FROM timetable ORDER BY active DESC, dayOfWeek ASC, startTime ASC"
  );
}

export async function createTimetableSlot(input: Omit<TimetableSlot, "id" | "active"> & { active?: number }) {
  const db = await getDb();
  const result = await db.runAsync(
    "INSERT INTO timetable (studentId, groupId, title, dayOfWeek, startTime, durationMinutes, subject, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
    input.studentId ?? null,
    input.groupId ?? null,
    input.title.trim(),
    input.dayOfWeek,
    input.startTime,
    input.durationMinutes,
    input.subject?.trim() || null,
    input.active ?? 1
  );
  return Number(result.lastInsertRowId);
}

export type TimetableSlotInput = Omit<TimetableSlot, "id" | "active"> & { active?: number };

export async function createRecurringTimetableSlots(inputs: TimetableSlotInput[]) {
  if (!inputs.length) throw new Error("اختاري يومًا واحدًا على الأقل للجدول المتكرر");
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    for (const input of inputs) {
      if (!input.title.trim() || !input.dayOfWeek.trim() || !/^\d{2}:\d{2}$/.test(input.startTime)) {
        throw new Error("بيانات الموعد المتكرر غير مكتملة");
      }
      await db.runAsync(
        "INSERT INTO timetable (studentId, groupId, title, dayOfWeek, startTime, durationMinutes, subject, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        input.studentId ?? null,
        input.groupId ?? null,
        input.title.trim(),
        input.dayOfWeek,
        input.startTime,
        Math.max(15, input.durationMinutes),
        input.subject?.trim() || null,
        input.active ?? 1
      );
    }
  });
  return inputs.length;
}

export async function updateTimetableSlot(input: {
  id: number;
  dayOfWeek: string;
  startTime: string;
  durationMinutes: number;
}) {
  const db = await getDb();
  await db.runAsync(
    "UPDATE timetable SET dayOfWeek = ?, startTime = ?, durationMinutes = ? WHERE id = ?",
    input.dayOfWeek,
    input.startTime,
    Math.max(15, input.durationMinutes),
    input.id
  );
}

export async function setTimetableSlotActive(id: number, active: boolean) {
  const db = await getDb();
  await db.runAsync("UPDATE timetable SET active = ? WHERE id = ?", active ? 1 : 0, id);
}

export async function deleteTimetableSlot(id: number) {
  const db = await getDb();
  await db.runAsync("DELETE FROM timetable WHERE id = ?", id);
}

export async function listExams() {
  const db = await getDb();
  return db.getAllAsync<Exam>("SELECT * FROM exams ORDER BY examDate DESC, id DESC");
}

export async function listExamScores(examId?: number) {
  const db = await getDb();
  return examId ? db.getAllAsync<ExamScore>("SELECT * FROM examScores WHERE examId = ? ORDER BY studentName COLLATE NOCASE ASC", examId) : db.getAllAsync<ExamScore>("SELECT * FROM examScores ORDER BY createdAt DESC, id DESC");
}

export async function createExam(input: Omit<Exam, "id" | "createdAt">) {
  const db = await getDb();
  const result = await db.runAsync(`INSERT INTO exams (title, track, grade, britishLevel, examBoard, qualification, subject, groupId, groupName, examDate, maxScore, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, input.title.trim(), input.track || null, input.grade || null, input.britishLevel || null, input.examBoard || null, input.qualification || null, input.subject || null, input.groupId ?? null, input.groupName || null, input.examDate, Math.max(1, input.maxScore || 100), input.notes?.trim() || null, createdAt());
  return Number(result.lastInsertRowId);
}

export async function deleteExam(id: number) { const db = await getDb(); await db.runAsync("DELETE FROM exams WHERE id = ?", id); }

function scoreLetter(percentage: number) {
  if (percentage >= 90) return "A*"; if (percentage >= 80) return "A"; if (percentage >= 70) return "B"; if (percentage >= 60) return "C"; if (percentage >= 50) return "D"; if (percentage >= 40) return "E"; return "U";
}

export async function saveExamScore(input: { examId: number; studentId: number; studentName: string; score: number; maxScore: number; notes?: string | null }) {
  const db = await getDb();
  const score = Math.max(0, Math.min(Number(input.score) || 0, Number(input.maxScore) || 100));
  const percentage = Math.round((score / Math.max(1, input.maxScore)) * 1000) / 10;
  await db.runAsync(`INSERT INTO examScores (examId, studentId, studentName, score, percentage, gradeLetter, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(examId, studentId) DO UPDATE SET studentName=excluded.studentName, score=excluded.score, percentage=excluded.percentage, gradeLetter=excluded.gradeLetter, notes=excluded.notes`, input.examId, input.studentId, input.studentName, score, percentage, scoreLetter(percentage), input.notes?.trim() || null, createdAt());
}

export async function deleteExamScore(id: number) { const db = await getDb(); await db.runAsync("DELETE FROM examScores WHERE id = ?", id); }

export async function getSnapshot(): Promise<DashboardSnapshot> {
  const [students, sessions, groups, transactions, timetable, exams, examScores, attendanceRecords, subscriptions, payments] = await Promise.all([
    listStudents(), listSessions(), listGroups(), listTransactions(), listAllTimetable(), listExams(), listExamScores(), listAttendanceRecords(), listStudentSubscriptions(), listStudentPayments(),
  ]);
  return { students, sessions, groups, transactions, timetable, exams, examScores, attendanceRecords, subscriptions, payments };
}

export async function exportBackup(): Promise<NativeBackup> {
  const snapshot = await getSnapshot();
  return {
    schema: "naneice-desk-native",
    version: 1,
    exportedAt: createdAt(),
    ...snapshot,
  };
}

async function clearAllTables(db: SQLite.SQLiteDatabase) {
  await db.execAsync(`
    DELETE FROM attendanceRecords;
    DELETE FROM sessions;
    DELETE FROM timetable;
    DELETE FROM financeTransactions;
    DELETE FROM studentPayments;
    DELETE FROM studentSubscriptions;
    DELETE FROM students;
    DELETE FROM groups;
    DELETE FROM examScores;
    DELETE FROM exams;
  `);
}

export async function restoreNativeBackup(backup: NativeBackup) {
  if (backup.schema !== "naneice-desk-native" || backup.version !== 1) {
    throw new Error("صيغة النسخة الاحتياطية غير مدعومة");
  }
  const db = await getDb();
  await db.withTransactionAsync(async () => {
    await clearAllTables(db);
    for (const student of backup.students ?? []) {
      await db.runAsync(
        "INSERT INTO students (id, name, academy, track, grade, britishLevel, examBoard, qualification, subject, phone, totalSessions, completedSessions, remainingSessions, lastNotes, active, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        student.id, student.name, student.academy, student.track, student.grade, student.britishLevel, student.examBoard, student.qualification, student.subject, student.phone,
        student.totalSessions, student.completedSessions, student.remainingSessions, student.lastNotes, student.active, student.createdAt
      );
    }
    for (const group of backup.groups ?? []) {
      await db.runAsync(
        "INSERT INTO groups (id, name, academy, track, grade, britishLevel, examBoard, qualification, subject, capacity, memberNames, totalSessions, completedSessions, remainingSessions, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        group.id, group.name, group.academy, group.track, group.grade, group.britishLevel, group.examBoard, group.qualification, group.subject, group.capacity, group.memberNames,
        group.totalSessions, group.completedSessions, group.remainingSessions, group.notes, group.createdAt
      );
    }
    for (const session of backup.sessions ?? []) {
      await db.runAsync(
        "INSERT INTO sessions (id, studentId, groupId, studentName, groupName, academy, subject, sessionDate, startTime, durationMinutes, status, attendance, homework, previousHomeworkDone, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        session.id, session.studentId, session.groupId, session.studentName, session.groupName,
        session.academy, session.subject, session.sessionDate, session.startTime,
        session.durationMinutes, session.status, session.attendance, session.homework,
        session.previousHomeworkDone, session.notes, session.createdAt
      );
    }
    for (const record of backup.attendanceRecords ?? []) {
      await db.runAsync(
        "INSERT INTO attendanceRecords (id, sessionId, groupId, studentId, studentName, attendanceDate, status, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        record.id, record.sessionId, record.groupId, record.studentId, record.studentName, record.attendanceDate, record.status, record.notes, record.createdAt
      );
    }
    for (const payment of backup.payments ?? []) {
      await db.runAsync(
        "INSERT INTO studentPayments (id, studentId, studentName, amount, paymentDate, method, reference, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        payment.id, payment.studentId, payment.studentName, payment.amount, payment.paymentDate, payment.method, payment.reference, payment.notes, payment.createdAt
      );
    }
    for (const subscription of backup.subscriptions ?? []) {
      await db.runAsync("INSERT INTO studentSubscriptions (id, studentId, studentName, totalAmount, paidAmount, discountAmount, balance, status, renewalDate, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", subscription.id, subscription.studentId, subscription.studentName, subscription.totalAmount, subscription.paidAmount, subscription.discountAmount, subscription.balance, subscription.status, subscription.renewalDate, subscription.notes, subscription.createdAt);
    }
    for (const transaction of backup.transactions ?? []) {
      await db.runAsync(
        "INSERT INTO financeTransactions (id, type, amount, description, transactionDate, createdAt) VALUES (?, ?, ?, ?, ?, ?)",
        transaction.id, transaction.type, transaction.amount, transaction.description,
        transaction.transactionDate, transaction.createdAt
      );
    }
    for (const exam of backup.exams ?? []) {
      await db.runAsync(
        "INSERT INTO exams (id, title, track, grade, britishLevel, examBoard, qualification, subject, groupId, groupName, examDate, maxScore, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        exam.id, exam.title, exam.track, exam.grade, exam.britishLevel, exam.examBoard, exam.qualification, exam.subject, exam.groupId, exam.groupName, exam.examDate, exam.maxScore, exam.notes, exam.createdAt
      );
    }
    for (const score of backup.examScores ?? []) {
      await db.runAsync(
        "INSERT INTO examScores (id, examId, studentId, studentName, score, percentage, gradeLetter, notes, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        score.id, score.examId, score.studentId, score.studentName, score.score, score.percentage, score.gradeLetter, score.notes, score.createdAt
      );
    }
    for (const slot of backup.timetable ?? []) {
      await db.runAsync(
        "INSERT INTO timetable (id, studentId, groupId, title, dayOfWeek, startTime, durationMinutes, subject, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        slot.id, slot.studentId, slot.groupId, slot.title, slot.dayOfWeek, slot.startTime,
        slot.durationMinutes, slot.subject, slot.active
      );
    }
  });
}

export async function importLegacyBackup(backup: LegacyBackup) {
  const existingNames = new Set((await listStudents()).map(student => student.name.trim().toLocaleLowerCase("ar-EG")));
  let imported = 0;
  for (const student of backup.students ?? []) {
    const normalizedName = student.name?.trim();
    if (!normalizedName || existingNames.has(normalizedName.toLocaleLowerCase("ar-EG"))) continue;
    await createStudent({
      name: normalizedName,
      academy: backup.academies?.[0]?.name ?? null,
      subject: student.subject ?? null,
      phone: student.phone ?? student.parentPhone ?? null,
      totalSessions: student.totalSessions ?? 0,
      completedSessions: student.completedSessions ?? 0,
      remainingSessions: student.remainingSessions ?? student.totalSessions ?? 0,
      lastNotes: student.lastNotes ?? null,
    });
    existingNames.add(normalizedName.toLocaleLowerCase("ar-EG"));
    imported += 1;
  }
  return imported;
}

export function todayDate() {
  return localIsoDate();
}
