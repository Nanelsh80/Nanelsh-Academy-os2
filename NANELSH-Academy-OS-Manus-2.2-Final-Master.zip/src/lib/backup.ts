import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { exportBackup, importLegacyBackup, restoreNativeBackup } from "../data/store";
import type { LegacyBackup, LessonSession, NativeBackup } from "../types";

const BACKUP_FILE = "naneice-desk-native-backup.json";
const REPORT_FILE = "naneice-desk-session-report.txt";
const ACADEMIC_REPORT_FILE = "nanelsh-academic-report.txt";

function safeParse(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("الملف المختار ليس نسخة JSON صالحة");
  }
}

function isNativeBackup(value: unknown): value is NativeBackup {
  return Boolean(
    value &&
      typeof value === "object" &&
      (value as NativeBackup).schema === "naneice-desk-native" &&
      (value as NativeBackup).version === 1
  );
}

function isLegacyBackup(value: unknown): value is LegacyBackup {
  return Boolean(value && typeof value === "object" && Array.isArray((value as LegacyBackup).students));
}

export async function shareLocalBackup() {
  const backup = await exportBackup();
  const directory = FileSystem.cacheDirectory;
  if (!directory) throw new Error("لا يمكن الوصول إلى مساحة حفظ الملفات على الجهاز");
  const fileUri = `${directory}${BACKUP_FILE}`;
  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(backup, null, 2), {
    encoding: FileSystem.EncodingType.UTF8,
  });
  if (!(await Sharing.isAvailableAsync())) {
    throw new Error("المشاركة غير متاحة على هذا الجهاز");
  }
  await Sharing.shareAsync(fileUri, {
    mimeType: "application/json",
    dialogTitle: "حفظ نسخة Naneice Desk Native",
    UTI: "public.json",
  });
  return backup;
}

export async function chooseAndRestoreBackup() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ["application/json", "text/json", "text/plain"],
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (result.canceled || !result.assets[0]) return { canceled: true as const, imported: 0 };

  const raw = await FileSystem.readAsStringAsync(result.assets[0].uri, {
    encoding: FileSystem.EncodingType.UTF8,
  });
  const parsed = safeParse(raw);

  if (isNativeBackup(parsed)) {
    await restoreNativeBackup(parsed);
    return {
      canceled: false as const,
      imported: parsed.students.length,
      source: "native" as const,
    };
  }

  if (isLegacyBackup(parsed)) {
    const imported = await importLegacyBackup(parsed);
    return { canceled: false as const, imported, source: "legacy" as const };
  }

  throw new Error("الملف لا يحتوي على نسخة مدعومة من Naneice Desk");
}

function reportDate(date: string) {
  return new Intl.DateTimeFormat("ar-EG-u-ca-gregory", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${date}T12:00:00`));
}

export async function shareAcademicReport(text: string) {
  const directory = FileSystem.cacheDirectory;
  if (!directory) throw new Error("لا يمكن الوصول إلى مساحة حفظ التقرير على الجهاز");
  const fileUri = `${directory}${ACADEMIC_REPORT_FILE}`;
  await FileSystem.writeAsStringAsync(fileUri, text, { encoding: FileSystem.EncodingType.UTF8 });
  if (!(await Sharing.isAvailableAsync())) throw new Error("المشاركة غير متاحة على هذا الجهاز");
  await Sharing.shareAsync(fileUri, { mimeType: "text/plain", dialogTitle: "مشاركة التقرير الأكاديمي" });
}

export async function shareSessionReport(session: LessonSession) {
  const directory = FileSystem.cacheDirectory;
  if (!directory) throw new Error("لا يمكن الوصول إلى مساحة حفظ التقرير على الجهاز");
  const recipient = session.studentName || session.groupName || "الطالب/المجموعة";
  const lines = [
    "تقرير حصة — Naneice Desk",
    "",
    `اليوم والتاريخ: ${reportDate(session.sessionDate)}`,
    `وقت الحصة: ${session.startTime}`,
    `الطالب/المجموعة: ${recipient}`,
    `الأكاديمية: ${session.academy || "غير محددة"}`,
    `المادة: ${session.subject || "غير محددة"}`,
    `الحضور: ${session.attendance || "غير مسجل"}`,
    `الواجب السابق: ${session.previousHomeworkDone === 1 ? "تم" : session.previousHomeworkDone === 0 ? "لم يتم" : "غير مسجل"}`,
    `الواجب الجديد: ${session.homework || "لا يوجد"}`,
    `ملاحظات: ${session.notes || "لا توجد"}`,
  ];
  const fileUri = `${directory}${REPORT_FILE}`;
  await FileSystem.writeAsStringAsync(fileUri, lines.join("\n"), {
    encoding: FileSystem.EncodingType.UTF8,
  });
  if (!(await Sharing.isAvailableAsync())) {
    throw new Error("المشاركة غير متاحة على هذا الجهاز");
  }
  await Sharing.shareAsync(fileUri, {
    mimeType: "text/plain",
    dialogTitle: "إرسال تقرير الحصة",
  });
}
