import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import type { LessonSession, Exam, StudentSubscription } from "../types";

const CHANNEL_ID = "nanelsh-academy-sessions-v2";
const SOUND = "nanelsh_chime.wav";
const REMINDER_MINUTES = 30;

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function configureNotifications(requestPermission = true) {
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
      name: "تنبيهات الحصص",
      importance: Notifications.AndroidImportance.HIGH,
      sound: SOUND,
      vibrationPattern: [0, 250, 150, 250],
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      enableVibrate: true,
      enableLights: true,
    });
  }

  const current = await Notifications.getPermissionsAsync();
  if (current.status === "granted") return true;
  if (!requestPermission) return false;
  const requested = await Notifications.requestPermissionsAsync({
    android: { allowAlert: true, allowSound: true, allowVibrate: true },
  });
  return requested.status === "granted";
}

function sessionDateTime(session: LessonSession) {
  const [hours, minutes] = session.startTime.split(":").map(Number);
  const date = new Date(`${session.sessionDate}T00:00:00`);
  date.setHours(Number.isFinite(hours) ? hours : 0, Number.isFinite(minutes) ? minutes : 0, 0, 0);
  return date;
}

function reminderDate(session: LessonSession) {
  return new Date(sessionDateTime(session).getTime() - REMINDER_MINUTES * 60_000);
}

function sessionTitle(session: LessonSession) {
  return session.groupName || session.studentName || "الحصة القادمة";
}

function isFutureScheduled(session: LessonSession) {
  return session.status === "scheduled" && reminderDate(session).getTime() > Date.now() + 5_000;
}

export async function scheduleSessionReminder(session: LessonSession) {
  if (!isFutureScheduled(session)) return null;
  const enabled = await configureNotifications();
  if (!enabled) return null;
  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: "⏰ حصة قادمة",
      body: `حصة ${sessionTitle(session)} تبدأ بعد ${REMINDER_MINUTES} دقيقة · ${session.subject || ""}`.trim(),
      sound: SOUND,
      data: { type: "session-reminder", sessionId: session.id, screen: "sessions" },
      interruptionLevel: "timeSensitive",
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: reminderDate(session), ...(Platform.OS === "android" ? { channelId: CHANNEL_ID } : {}) },
  });
  return id;
}

export async function syncSessionReminders(sessions: LessonSession[]) {
  const enabled = await configureNotifications(false);
  if (!enabled) return { scheduled: 0, enabled: false };

  const existing = await Notifications.getAllScheduledNotificationsAsync();
  for (const item of existing) {
    const data = item.content.data as { type?: string } | undefined;
    if (data?.type === "session-reminder") {
      await Notifications.cancelScheduledNotificationAsync(item.identifier);
    }
  }

  let scheduled = 0;
  for (const session of sessions) {
    if (await scheduleSessionReminder(session)) scheduled += 1;
  }
  return { scheduled, enabled: true };
}


function dateAtLocalTime(dateString: string, hour: number, minute = 0) {
  const date = new Date(`${dateString}T00:00:00`);
  date.setHours(hour, minute, 0, 0);
  return date;
}

async function scheduleGeneric(title: string, body: string, date: Date, data: Record<string, string>) {
  if (date.getTime() <= Date.now() + 5_000) return null;
  return Notifications.scheduleNotificationAsync({
    content: { title, body, sound: SOUND, data, interruptionLevel: "active" },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date, ...(Platform.OS === "android" ? { channelId: CHANNEL_ID } : {}) },
  });
}

export async function syncAcademicReminders(exams: Exam[], subscriptions: StudentSubscription[]) {
  const enabled = await configureNotifications(false);
  if (!enabled) return { scheduled: 0, enabled: false };
  const existing = await Notifications.getAllScheduledNotificationsAsync();
  for (const item of existing) {
    const data = item.content.data as { type?: string } | undefined;
    if (data?.type === "exam-reminder" || data?.type === "renewal-reminder") {
      await Notifications.cancelScheduledNotificationAsync(item.identifier);
    }
  }
  let scheduled = 0;
  for (const exam of exams) {
    const date = dateAtLocalTime(exam.examDate, 8);
    date.setDate(date.getDate() - 1);
    const id = await scheduleGeneric("📝 اختبار قادم", `${exam.title}${exam.subject ? ` · ${exam.subject}` : ""} غدًا`, date, { type: "exam-reminder", examId: String(exam.id), screen: "exams" });
    if (id) scheduled += 1;
  }
  for (const subscription of subscriptions) {
    if (!subscription.renewalDate || subscription.status === "paid") continue;
    const date = dateAtLocalTime(subscription.renewalDate, 10);
    date.setDate(date.getDate() - 3);
    const id = await scheduleGeneric("💰 موعد تجديد الاشتراك", `${subscription.studentName} · متبقي ${subscription.balance.toLocaleString("ar-EG")} جنيه`, date, { type: "renewal-reminder", studentId: String(subscription.studentId), screen: "finance" });
    if (id) scheduled += 1;
  }
  return { scheduled, enabled: true };
}

export async function sendAttendanceAlert(studentName: string, status: string, date: string) {
  if (status !== "غائب" && status !== "بعذر") return null;
  const enabled = await configureNotifications(false);
  if (!enabled) return null;
  return Notifications.scheduleNotificationAsync({
    content: {
      title: status === "غائب" ? "⚠️ غياب طالبة" : "📄 غياب بعذر",
      body: `${studentName} · ${date} · تم تسجيل ${status}`,
      sound: SOUND,
      data: { type: "attendance-alert", screen: "attendance" },
      interruptionLevel: "active",
    },
    trigger: null,
  });
}

export async function sendTestNotification() {
  const enabled = await configureNotifications();
  if (!enabled) throw new Error("لم يتم السماح بالتنبيهات. افتحي إعدادات Android واسمحي بالإشعارات والصوت.");
  return Notifications.scheduleNotificationAsync({
    content: {
      title: "🌿 NANELSH Academy OS",
      body: "التنبيهات تعمل بنجاح — سيصلك تنبيه الحصة مع صوت وظهور على الشاشة.",
      sound: SOUND,
      data: { type: "test" },
      interruptionLevel: "active",
    },
    trigger: null,
  });
}

export function onNotificationResponse(callback: (screen?: string) => void) {
  return Notifications.addNotificationResponseReceivedListener(response => {
    const data = response.notification.request.content.data as { screen?: string } | undefined;
    callback(data?.screen);
  });
}

export async function getNotificationPermissionState() {
  const permissions = await Notifications.getPermissionsAsync();
  return permissions.status;
}
