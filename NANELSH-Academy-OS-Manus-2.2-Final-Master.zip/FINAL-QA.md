# NANELSH Academy OS — Final Master QA

## Master rules
- Manus 2.2 native Expo/React Native remains the functional base.
- Official NANELSH visual identity is the visual reference.
- NANELSH Academy OS is academy/education only.
- Arabic personal-life modules are not part of this app.

## Included modules
- Students and Student 360
- Arabic grades: Grade 4 Primary through Grade 3 Secondary
- Subjects: Science, Biology, Chemistry
- British section: Year 4–13, IGCSE, AS, A Level, Cambridge, Pearson Edexcel
- Groups and group membership
- Timetable and generated sessions
- Individual attendance
- Exams, scores and academic progress
- Student and group academic reports
- Unified student finance
- Payments and balances
- Native Android notifications
- In-app Notification Center
- Backup/restore

## Native notification requirements
After changing native notification configuration, rebuild the Android binary. The project includes `eas.json` with a preview APK profile.

## Build
Use an Expo/EAS-enabled environment:
`eas build --platform android --profile preview`
