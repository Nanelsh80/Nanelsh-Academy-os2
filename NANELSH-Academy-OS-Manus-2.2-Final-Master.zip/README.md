# NANELSH Academy OS — Manus 2.2 Final Master

Based on the Manus 2.2 native Expo/React Native master with the NANELSH visual identity and British curriculum support.

## v6 additions
- British curriculum exam engine.
- Exams linked to track, Year/grade, British level, Exam Board, qualification, subject and optional group.
- Individual student score entry.
- Automatic percentage and grade calculation (A*–U).
- Exam averages and British exam metrics.
- SQLite persistence and backup/restore support for exams and scores.
- Original Manus features remain the base; this phase adds the academic assessment layer.

## Notifications
- Real Android/iOS local notifications via `expo-notifications`.
- Session reminders are scheduled 30 minutes before upcoming scheduled sessions.
- Notifications use the system default sound and high-importance Android channel so they can appear on screen.
- The Settings screen includes a notification test action.
- Android notification permission is requested on first launch.


## Final Master
- Official NANELSH visual identity applied to the Manus 2.2 native base.
- Finalization includes academic, British, attendance, reports, unified finance, payments, timetable/session, and notification layers.
- See `FINAL-QA.md` for the scope and native build notes.
