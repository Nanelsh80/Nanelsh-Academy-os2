import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import DateTimePicker from "@react-native-community/datetimepicker";
import * as Haptics from "expo-haptics";
import { StatusBar } from "expo-status-bar";
import { type ComponentProps, type ReactNode, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type ListRenderItemInfo,
} from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import {
  completeSession,
  createGroup,
  createSession,
  createStudent,
  createRecurringTimetableSlots,
  generateSessionsFromTimetable,
  createTransaction,
  deleteGroup,
  deleteSession,
  deleteStudent,
  deleteTimetableSlot,
  deleteTransaction,
  createExam,
  deleteExam,
  saveExamScore,
  saveAttendanceRecord,
  deleteAttendanceRecord,
  getSnapshot,
  initializeStore,
  setTimetableSlotActive,
  startSession,
  todayDate,
  updateCompletedSession,
  updateGroup,
  updateScheduledSession,
  updateStudent,
  updateTimetableSlot,
  upsertStudentSubscription,
  createStudentPayment,
  deleteStudentPayment,
  listGroupMembers,
  syncGroupMembers,
} from "./src/data/store";
import { chooseAndRestoreBackup, shareLocalBackup, shareSessionReport, shareAcademicReport } from "./src/lib/backup";
import { configureNotifications, getNotificationPermissionState, sendTestNotification, syncSessionReminders, syncAcademicReminders, sendAttendanceAlert, onNotificationResponse } from "./src/lib/notifications";
import type {
  DashboardSnapshot,
  FinanceTransaction,
  LessonSession,
  Student,
  TimetableSlot,
  TransactionType,
  TutoringGroup,
  Exam,
  ExamScore,
  AttendanceRecord,
  StudentSubscription,
  StudentPayment,
} from "./src/types";

const COLORS = {
  background: "#F8F2E8",
  surface: "#FFFDF8",
  ink: "#173F3B",
  muted: "#6E7973",
  primary: "#1E7A75",
  primaryDeep: "#0F5F5B",
  lavender: "#DDEBE6",
  lavenderSoft: "#F3F0E7",
  peach: "#EACDB8",
  blush: "#F6E4DA",
  sky: "#E7EFEA",
  border: "#E5D9C9",
  danger: "#B65F4F",
  dangerSoft: "#F8E8E2",
  warning: "#A56D35",
  warningSoft: "#F7EBD7",
  success: "#2F7D72",
  successSoft: "#E5F0EC",
};

type Tab = "home" | "students" | "sessions" | "attendance" | "groups" | "british" | "exams" | "progress" | "reports" | "finance" | "settings";
type ModalKind = "student" | "session" | "complete" | "group" | "finance" | "payment" | "timetable" | "studentDetail" | "groupDetail" | "sessionEdit" | "report" | "timetableEdit" | "exam" | "examScores" | null;
type IconName = ComponentProps<typeof MaterialIcons>["name"];

const TABS: Array<{ key: Tab; title: string; icon: IconName }> = [
  { key: "home", title: "الرئيسية", icon: "home-filled" },
  { key: "students", title: "الطلاب", icon: "school" },
  { key: "sessions", title: "الحصص", icon: "calendar-month" },
  { key: "attendance", title: "الحضور", icon: "fact-check" },
  { key: "groups", title: "المجموعات", icon: "groups" },
  { key: "british", title: "القسم البريطاني", icon: "language" },
  { key: "exams", title: "الاختبارات", icon: "assignment" },
  { key: "progress", title: "التقدم الأكاديمي", icon: "trending-up" },
  { key: "reports", title: "التقارير", icon: "description" },
  { key: "finance", title: "المالية", icon: "account-balance-wallet" },
  { key: "settings", title: "إعدادات", icon: "tune" },
];

const DAYS = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];
const DEFAULT_WEEKLY_TIME = "16:00";
const GRADES = [
  "الصف الرابع الابتدائي", "الصف الخامس الابتدائي", "الصف السادس الابتدائي",
  "الصف الأول الإعدادي", "الصف الثاني الإعدادي", "الصف الثالث الإعدادي",
  "الصف الأول الثانوي", "الصف الثاني الثانوي", "الصف الثالث الثانوي",
] as const;
const SUBJECTS = ["علوم", "أحياء", "كيمياء"] as const;
const TRACKS = ["القسم العربي", "القسم البريطاني"] as const;
const BRITISH_GRADES = ["Year 4", "Year 5", "Year 6", "Year 7", "Year 8", "Year 9", "Year 10", "Year 11", "Year 12", "Year 13"] as const;
const BRITISH_LEVELS = ["Primary", "Lower Secondary", "IGCSE", "AS Level", "A Level"] as const;
const EXAM_BOARDS = ["Cambridge", "Pearson Edexcel"] as const;
const BRITISH_QUALIFICATIONS = ["Checkpoint", "IGCSE", "AS", "A Level"] as const;
type Grade = typeof GRADES[number];
type Subject = typeof SUBJECTS[number];

function AcademicPicker({ label, value, options, onChange }: { label: string; value: string; options: readonly string[]; onChange: (value: string) => void }) {
  return <View style={{ marginBottom: 10 }}>
    <Text style={styles.fieldLabel}>{label}</Text>
    <View style={styles.choiceWrap}>
      {options.map(option => <Choice key={option} label={option} selected={value === option} onPress={() => onChange(option)} />)}
    </View>
  </View>;
}


function timeToDate(time: string) {
  const [hours, minutes] = time.split(":").map(Number);
  return new Date(2000, 0, 1, Number.isFinite(hours) ? hours : 16, Number.isFinite(minutes) ? minutes : 0);
}

function dateToTime(date: Date) {
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function formatTime(time: string) {
  return new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit" }).format(timeToDate(time));
}

function haptic() {
  void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

function formatDate(date: string) {
  return new Intl.DateTimeFormat("ar-EG-u-ca-gregory", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${date}T12:00:00`));
}

function formatMoney(amount: number) {
  return new Intl.NumberFormat("ar-EG", {
    style: "currency",
    currency: "EGP",
    maximumFractionDigits: 0,
  }).format(amount);
}

function sessionLabel(session: LessonSession) {
  return session.studentName || session.groupName || "حصة بدون عنوان";
}

function attendanceTone(attendance: LessonSession["attendance"]) {
  if (attendance === "حاضر") return { color: COLORS.success, background: COLORS.successSoft };
  if (attendance === "متأخر") return { color: COLORS.warning, background: COLORS.warningSoft };
  if (attendance === "غائب") return { color: COLORS.danger, background: COLORS.dangerSoft };
  return { color: COLORS.muted, background: COLORS.lavenderSoft };
}

function statusLabel(status: LessonSession["status"]) {
  if (status === "completed") return "مكتملة";
  if (status === "in_progress") return "قيد التنفيذ";
  return "مجدولة";
}

function statusTone(status: LessonSession["status"]) {
  if (status === "completed") return { color: COLORS.success, background: COLORS.successSoft };
  if (status === "in_progress") return { color: COLORS.primaryDeep, background: COLORS.lavender };
  return { color: COLORS.warning, background: COLORS.warningSoft };
}

function AppButton({
  title,
  onPress,
  icon,
  tone = "primary",
  disabled = false,
  compact = false,
}: {
  title: string;
  onPress: () => void;
  icon?: IconName;
  tone?: "primary" | "soft" | "outline" | "danger";
  disabled?: boolean;
  compact?: boolean;
}) {
  const palette =
    tone === "primary"
      ? { backgroundColor: COLORS.primary, text: "#FFFDF8", borderColor: COLORS.primary }
      : tone === "danger"
        ? { backgroundColor: COLORS.dangerSoft, text: COLORS.danger, borderColor: "#E8C3B9" }
        : tone === "soft"
          ? { backgroundColor: COLORS.lavender, text: COLORS.primaryDeep, borderColor: COLORS.lavender }
          : { backgroundColor: "transparent", text: COLORS.primaryDeep, borderColor: COLORS.border };
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      disabled={disabled}
      onPress={() => {
        haptic();
        onPress();
      }}
      style={({ pressed }) => [
        styles.button,
        compact && styles.buttonCompact,
        {
          backgroundColor: palette.backgroundColor,
          borderColor: palette.borderColor,
          opacity: disabled ? 0.45 : pressed ? 0.82 : 1,
          transform: [{ scale: pressed && !disabled ? 0.98 : 1 }],
        },
      ]}
    >
      {icon ? <MaterialIcons name={icon} size={compact ? 17 : 19} color={palette.text} /> : null}
      <Text style={[styles.buttonText, compact && styles.buttonTextCompact, { color: palette.text }]}>{title}</Text>
    </Pressable>
  );
}

function IconButton({ label, icon, onPress, tone = "default" }: { label: string; icon: IconName; onPress: () => void; tone?: "default" | "danger" }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={() => {
        haptic();
        onPress();
      }}
      style={({ pressed }) => [
        styles.iconButton,
        tone === "danger" && { backgroundColor: COLORS.dangerSoft },
        pressed && { opacity: 0.7 },
      ]}
    >
      <MaterialIcons name={icon} size={20} color={tone === "danger" ? COLORS.danger : COLORS.primaryDeep} />
    </Pressable>
  );
}

function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionHeaderText}>
        <Text style={styles.sectionTitle}>{title}</Text>
        {subtitle ? <Text style={styles.sectionSubtitle}>{subtitle}</Text> : null}
      </View>
      {action}
    </View>
  );
}

function Metric({ icon, label, value, tint }: { icon: IconName; label: string; value: string | number; tint: string }) {
  return (
    <View style={styles.metricCard}>
      <View style={[styles.metricIcon, { backgroundColor: tint }]}>
        <MaterialIcons name={icon} size={20} color={COLORS.primaryDeep} />
      </View>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function EmptyState({ icon, title, body, action }: { icon: IconName; title: string; body: string; action?: React.ReactNode }) {
  return (
    <View style={styles.emptyState}>
      <View style={styles.emptyIcon}><MaterialIcons name={icon} size={30} color={COLORS.primary} /></View>
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyBody}>{body}</Text>
      {action ? <View style={{ marginTop: 14 }}>{action}</View> : null}
    </View>
  );
}

function InputField({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType,
  multiline = false,
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  keyboardType?: "default" | "numeric" | "phone-pad";
  multiline?: boolean;
}) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#92958D"
        keyboardType={keyboardType}
        textAlign="right"
        multiline={multiline}
        style={[styles.input, multiline && styles.inputMultiline]}
      />
    </View>
  );
}

function Choice({ label, selected, onPress, tone = "primary" }: { label: string; selected: boolean; onPress: () => void; tone?: "primary" | "danger" | "warning" }) {
  const selectedColor = tone === "danger" ? COLORS.danger : tone === "warning" ? COLORS.warning : COLORS.primaryDeep;
  const selectedBackground = tone === "danger" ? COLORS.dangerSoft : tone === "warning" ? COLORS.warningSoft : COLORS.lavender;
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      onPress={() => { haptic(); onPress(); }}
      style={({ pressed }) => [
        styles.choice,
        selected && { backgroundColor: selectedBackground, borderColor: selectedColor },
        pressed && { opacity: 0.72 },
      ]}
    >
      <Text style={[styles.choiceText, selected && { color: selectedColor }]}>{label}</Text>
    </Pressable>
  );
}

function Sheet({ visible, title, subtitle, onClose, children }: { visible: boolean; title: string; subtitle?: string; onClose: () => void; children: ReactNode }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={styles.sheet}>
          <View style={styles.sheetHandle} />
          <View style={styles.sheetTop}>
            <View style={{ flex: 1 }}>
              <Text style={styles.sheetTitle}>{title}</Text>
              {subtitle ? <Text style={styles.sheetSubtitle}>{subtitle}</Text> : null}
            </View>
            <IconButton label="إغلاق" icon="close" onPress={onClose} />
          </View>
          <ScrollView contentContainerStyle={styles.sheetScroll} keyboardShouldPersistTaps="handled">
            {children}
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function NativeHeader({ onReload, onOpenNotifications, notificationCount }: { onReload: () => void; onOpenNotifications: () => void; notificationCount: number }) {
  return (
    <View style={styles.appHeader}>
      <View style={styles.brandRow}>
        <View style={styles.brandMark}><Image source={require("./assets/nanelsh-logo.png")} style={styles.brandLogo} resizeMode="contain" /></View>
        <View>
          <Text style={styles.brandName}>NANELSH Academy</Text>
          <Text style={styles.brandCaption}>نظام إدارة الأكاديمية</Text>
        </View>
      </View>
      <View style={styles.headerActions}><View><IconButton label="فتح التنبيهات" icon="notifications" onPress={onOpenNotifications} />{notificationCount > 0 ? <View style={styles.notificationBadge}><Text style={styles.notificationBadgeText}>{notificationCount > 9 ? "9+" : notificationCount}</Text></View> : null}</View><IconButton label="تحديث البيانات المحلية" icon="refresh" onPress={onReload} /></View>
    </View>
  );
}

function HomeScreen({ snapshot, onOpen, onQuickComplete }: { snapshot: DashboardSnapshot; onOpen: (kind: ModalKind) => void; onQuickComplete: (session: LessonSession) => void }) {
  const today = todayDate();
  const todaySessions = snapshot.sessions.filter(session => session.sessionDate === today);
  const completed = todaySessions.filter(session => session.status === "completed");
  const upcoming = todaySessions.filter(session => session.status !== "completed");
  const lowSessions = snapshot.students.filter(student => student.active && student.remainingSessions <= 3);
  const completedSessions = snapshot.sessions.filter(session => session.status === "completed");
  const attendanceRate = completedSessions.length
    ? Math.round((completedSessions.filter(session => session.attendance === "حاضر" || session.attendance === "متأخر").length / completedSessions.length) * 100)
    : 0;
  const monthlyPrefix = today.slice(0, 7);
  const net = snapshot.transactions.reduce((sum, transaction) => {
    return transaction.type === "income" ? sum + transaction.amount : sum - transaction.amount;
  }, 0);
  const monthlyNet = snapshot.transactions
    .filter(transaction => transaction.transactionDate.startsWith(monthlyPrefix))
    .reduce((sum, transaction) => transaction.type === "income" ? sum + transaction.amount : sum - transaction.amount, 0);

  return (
    <FlatList
      data={upcoming}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <>
          <View style={styles.heroCard}>
            <View style={styles.heroGlowOne} />
            <View style={styles.heroGlowTwo} />
            <Text style={styles.heroEyebrow}>مركز التحكم اليومي</Text>
            <Text style={styles.heroTitle}>مرحبًا بكِ في يومك التعليمي</Text>
            <Text style={styles.heroBody}>{formatDate(today)}</Text>
            <View style={styles.heroActions}>
              <AppButton title="إضافة حصة" icon="add-circle-outline" onPress={() => onOpen("session")} tone="soft" compact />
              <AppButton title="إضافة طالبة" icon="person-add-alt-1" onPress={() => onOpen("student")} tone="outline" compact />
            </View>
          </View>

          <View style={styles.metricsGrid}>
            <Metric icon="today" label="حصص اليوم" value={todaySessions.length} tint={COLORS.lavender} />
            <Metric icon="done-all" label="منتهية" value={completed.length} tint={COLORS.successSoft} />
            <Metric icon="school" label="طلاب نشطون" value={snapshot.students.filter(student => student.active).length} tint={COLORS.peach} />
            <Metric icon="account-balance-wallet" label="الصافي" value={formatMoney(net)} tint={COLORS.sky} />
          </View>

          <View style={styles.insightCard}>
            <View style={styles.insightItem}>
              <View style={[styles.insightIcon, { backgroundColor: COLORS.successSoft }]}><MaterialIcons name="fact-check" size={19} color={COLORS.success} /></View>
              <View style={{ flex: 1 }}><Text style={styles.insightValue}>{attendanceRate}%</Text><Text style={styles.insightLabel}>معدل الحضور المسجّل</Text></View>
            </View>
            <View style={styles.insightDivider} />
            <View style={styles.insightItem}>
              <View style={[styles.insightIcon, { backgroundColor: COLORS.lavender }]}><MaterialIcons name="trending-up" size={19} color={COLORS.primaryDeep} /></View>
              <View style={{ flex: 1 }}><Text style={styles.insightValue}>{formatMoney(monthlyNet)}</Text><Text style={styles.insightLabel}>صافي الشهر الحالي</Text></View>
            </View>
          </View>

          <SectionHeader title="حصص اليوم القادمة" subtitle={upcoming.length ? "ابدئي أو أنهي الحصة مباشرة من هاتفك" : "لا توجد حصص مجدولة متبقية اليوم"} />
        </>
      }
      ListEmptyComponent={
        <EmptyState
          icon="event-available"
          title="لا توجد حصص متبقية اليوم"
          body="أضيفي حصة جديدة، وستظهر هنا مع أزرار البدء والإنهاء."
          action={<AppButton title="جدولة حصة" icon="add" onPress={() => onOpen("session")} compact />}
        />
      }
      renderItem={({ item }) => <SessionCard session={item} onComplete={() => onQuickComplete(item)} />}
      ListFooterComponent={
        <>
          <SectionHeader title="تحتاج متابعة" subtitle="تنبيهات الحساب محفوظة على الجهاز" />
          {lowSessions.length ? (
            lowSessions.slice(0, 4).map(student => (
              <View key={student.id} style={styles.followUpRow}>
                <View style={styles.avatar}><Text style={styles.avatarText}>{student.name.slice(0, 1)}</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.rowTitle}>{student.name}</Text>
                  <Text style={styles.rowSub}>متبقي {student.remainingSessions} حصة</Text>
                </View>
                <View style={styles.lowBadge}><Text style={styles.lowBadgeText}>اشتراك</Text></View>
              </View>
            ))
          ) : (
            <View style={styles.softNotice}><MaterialIcons name="verified" size={18} color={COLORS.success} /><Text style={styles.softNoticeText}>لا توجد اشتراكات منخفضة حاليًا.</Text></View>
          )}
        </>
      }
    />
  );
}

function SessionCard({ session, onStart, onComplete, onEdit, onReport, onDelete }: { session: LessonSession; onStart?: () => void; onComplete?: () => void; onEdit?: () => void; onReport?: () => void; onDelete?: () => void }) {
  const status = statusTone(session.status);
  return (
    <View style={styles.sessionCard}>
      <View style={styles.sessionAccent} />
      <View style={styles.sessionTop}>
        <View style={{ flex: 1 }}>
          <Text style={styles.sessionTime}>{session.startTime}</Text>
          <Text style={styles.sessionName}>{sessionLabel(session)}</Text>
          <Text style={styles.sessionMeta}>{[session.academy, session.subject, `${session.durationMinutes} دقيقة`].filter(Boolean).join(" · ")}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: status.background }]}><Text style={[styles.statusText, { color: status.color }]}>{statusLabel(session.status)}</Text></View>
      </View>
      {session.status === "completed" ? (
        <View style={styles.completedInfo}>
          <View style={[styles.attendanceBadge, { backgroundColor: attendanceTone(session.attendance).background }]}> 
            <Text style={[styles.attendanceText, { color: attendanceTone(session.attendance).color }]}>{session.attendance || "غير مسجل"}</Text>
          </View>
          <Text numberOfLines={1} style={styles.completedNotes}>{session.notes || session.homework || "تم حفظ تقرير الحصة محليًا"}</Text>
          {onReport ? <IconButton label="إرسال تقرير الحصة" icon="share" onPress={onReport} /> : null}
          {onEdit ? <IconButton label="تعديل تقرير الحصة" icon="edit" onPress={onEdit} /> : null}
          {onDelete ? <IconButton label="حذف الحصة" icon="delete-outline" onPress={onDelete} tone="danger" /> : null}
        </View>
      ) : (
        <View style={styles.sessionActions}>
          {session.status === "scheduled" && onStart ? <AppButton title="ابدئي الحصة" icon="play-arrow" onPress={onStart} compact /> : null}
          {onComplete ? <AppButton title="إنهاء الحصة" icon="check-circle-outline" onPress={onComplete} tone={session.status === "scheduled" ? "outline" : "primary"} compact /> : null}
          {onEdit ? <IconButton label="تعديل موعد الحصة" icon="edit-calendar" onPress={onEdit} /> : null}
          {onDelete ? <IconButton label="حذف الحصة" icon="delete-outline" onPress={onDelete} tone="danger" /> : null}
        </View>
      )}
    </View>
  );
}

function StudentsScreen({ students, onAdd, onOpen, onDelete }: { students: Student[]; onAdd: () => void; onOpen: (student: Student) => void; onDelete: (student: Student) => void }) {
  const [query, setQuery] = useState("");
  const normalizedQuery = query.trim().toLocaleLowerCase("ar-EG");
  const filteredStudents = normalizedQuery
    ? students.filter(student => [student.name, student.academy, student.subject, student.phone].some(value => value?.toLocaleLowerCase("ar-EG").includes(normalizedQuery)))
    : students;
  return (
    <FlatList
      data={filteredStudents}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={<><SectionHeader title="الطلاب" subtitle={`عدد الطالبات: ${students.length}`} action={<AppButton title="إضافة" icon="person-add-alt-1" onPress={onAdd} compact />} /><View style={styles.searchBox}><MaterialIcons name="search" size={20} color={COLORS.muted} /><TextInput value={query} onChangeText={setQuery} placeholder="ابحثي بالاسم أو الأكاديمية أو المادة" placeholderTextColor="#92958D" textAlign="right" style={styles.searchInput} /></View></>}
      ListEmptyComponent={<EmptyState icon="school" title={students.length ? "لا توجد نتائج مطابقة" : "لا يوجد طلاب بعد"} body={students.length ? "جرّبي كلمة بحث مختلفة." : "أضيفي أول طالبة لبدء متابعة الحصص والاشتراكات."} action={!students.length ? <AppButton title="إضافة طالبة" icon="add" onPress={onAdd} compact /> : undefined} />}
      renderItem={({ item }) => (
        <View style={styles.studentCard}>
          <Pressable accessibilityRole="button" accessibilityLabel={`فتح ملف ${item.name}`} onPress={() => onOpen(item)} style={({ pressed }) => [styles.studentPressTarget, pressed && { opacity: 0.7 }]}>
            <View style={styles.avatar}><Text style={styles.avatarText}>{item.name.slice(0, 1)}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>{item.name}</Text>
              <Text style={styles.rowSub}>{[item.academy, item.grade, item.subject].filter(Boolean).join(" · ") || "لم تُحدّد الأكاديمية أو المادة"}</Text>
              <View style={styles.progressRow}>
                <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.min(100, item.totalSessions ? (item.completedSessions / item.totalSessions) * 100 : 0)}%` }]} /></View>
                <Text style={styles.progressText}>{item.completedSessions}/{item.totalSessions}</Text>
              </View>
              <Text style={styles.remainingText}>المتبقي: {item.remainingSessions} حصة</Text>
            </View>
          </Pressable>
          <IconButton label={`حذف ${item.name}`} icon="delete-outline" onPress={() => onDelete(item)} tone="danger" />
        </View>
      )}
    />
  );
}

function StudentDetailSheet({ student, sessions, exams, scores, payments, subscriptions, onClose, onSaved, onAddPayment }: { student: Student | null; sessions: LessonSession[]; exams: Exam[]; scores: ExamScore[]; payments: StudentPayment[]; subscriptions: StudentSubscription[]; onClose: () => void; onSaved: () => Promise<void>; onAddPayment: (student: Student) => void }) {
  const [name, setName] = useState("");
  const [academy, setAcademy] = useState("");
  const [grade, setGrade] = useState("");
  const [britishLevel, setBritishLevel] = useState("");
  const [examBoard, setExamBoard] = useState("");
  const [qualification, setQualification] = useState("");
  const [track, setTrack] = useState("القسم العربي");
  const [subject, setSubject] = useState("");
  const [phone, setPhone] = useState("");
  const [total, setTotal] = useState("0");
  const [remaining, setRemaining] = useState("0");
  const [notes, setNotes] = useState("");
  const [active, setActive] = useState(1);
  const [saving, setSaving] = useState(false);
  const [totalAmount, setTotalAmount] = useState("0");
  const [paidAmount, setPaidAmount] = useState("0");
  const [discountAmount, setDiscountAmount] = useState("0");
  const [renewalDate, setRenewalDate] = useState("");

  useEffect(() => {
    if (!student) return;
    setName(student.name);
    setAcademy(student.academy || "");
    setTrack(student.track || "القسم العربي");
    setGrade(student.grade || "");
    setBritishLevel(student.britishLevel || ""); setExamBoard(student.examBoard || ""); setQualification(student.qualification || "");
    setSubject(student.subject || "");
    setPhone(student.phone || "");
    setTotal(String(student.totalSessions));
    setRemaining(String(student.remainingSessions));
    setNotes(student.lastNotes || "");
    setActive(student.active);
    const account = subscriptions.find(item => item.studentId === student.id);
    setTotalAmount(String(account?.totalAmount ?? 0));
    setPaidAmount(String(account?.paidAmount ?? 0));
    setDiscountAmount(String(account?.discountAmount ?? 0));
    setRenewalDate(account?.renewalDate || "");
  }, [student?.id, subscriptions]);

  const history = student ? sessions.filter(session => session.studentId === student.id).slice(0, 4) : [];
  const studentScores = student ? scores.filter(score => score.studentId === student.id) : [];
  const studentExams = studentScores.map(score => exams.find(exam => exam.id === score.examId)).filter(Boolean) as Exam[];
  const examAverage = studentScores.length ? Math.round(studentScores.reduce((sum, score) => sum + score.percentage, 0) / studentScores.length) : 0;
  const isBritish = track === "القسم البريطاني" || student?.track === "القسم البريطاني";
  async function save() {
    if (!student || !name.trim()) return Alert.alert("الاسم مطلوب", "اكتبي اسم الطالبة أولًا.");
    const totalSessions = Math.max(0, Number(total) || 0);
    const remainingSessions = Math.max(0, Number(remaining) || 0);
    try {
      setSaving(true);
      await updateStudent(student.id, { name, academy, track, grade, britishLevel, examBoard, qualification, subject, phone, totalSessions, remainingSessions, lastNotes: notes, active });
      await upsertStudentSubscription({ studentId: student.id, studentName: name.trim(), totalAmount: Number(totalAmount) || 0, paidAmount: Number(paidAmount) || 0, discountAmount: Number(discountAmount) || 0, renewalDate: renewalDate.trim() || null });
      await onSaved();
      Alert.alert("تم الحفظ", "تم تحديث ملف الطالبة والاشتراك محليًا.");
    } catch (error) {
      Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى.");
    } finally { setSaving(false); }
  }

  return <Sheet visible={Boolean(student)} title={student ? `ملف ${student.name}` : "ملف الطالبة"} subtitle="تعديل البيانات والاشتراك من الهاتف" onClose={onClose}>
    <View style={styles.profileSummary}>
      <View style={styles.profileAvatar}><Text style={styles.profileAvatarText}>{student?.name.slice(0, 1)}</Text></View>
      <View style={{ flex: 1 }}><Text style={styles.profileBalance}>{student?.remainingSessions ?? 0} حصة متبقية</Text><Text style={styles.profileCaption}>{student?.completedSessions ?? 0} من {student?.totalSessions ?? 0} حصة منجزة</Text></View>
    </View>
    <InputField label="الاسم" value={name} onChangeText={setName} />
    <InputField label="الأكاديمية" value={academy} onChangeText={setAcademy} />
    <AcademicPicker label="القسم" value={track} options={TRACKS} onChange={setTrack} />{track === "القسم البريطاني" ? <><AcademicPicker label="Year / المرحلة البريطانية" value={grade} options={BRITISH_GRADES} onChange={setGrade} /><AcademicPicker label="المستوى" value={britishLevel} options={BRITISH_LEVELS} onChange={setBritishLevel} /><AcademicPicker label="Exam Board" value={examBoard} options={EXAM_BOARDS} onChange={setExamBoard} /><AcademicPicker label="Qualification" value={qualification} options={BRITISH_QUALIFICATIONS} onChange={setQualification} /></> : null}
    <AcademicPicker label="المادة" value={subject} options={SUBJECTS} onChange={setSubject} />
    <InputField label="رقم الهاتف" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
    <SectionHeader title="الحساب المالي الموحد" subtitle="حساب واحد للطالبة مهما تعددت المواد" action={student ? <AppButton title="دفعة" icon="payments" onPress={() => onAddPayment(student)} compact /> : undefined} />
    <View style={styles.profileFinanceCard}>
      <View style={styles.inlineFields}><View style={{ flex: 1 }}><InputField label="قيمة الاشتراك" value={totalAmount} onChangeText={setTotalAmount} keyboardType="numeric" placeholder="0" /></View><View style={{ flex: 1 }}><InputField label="المدفوع" value={paidAmount} onChangeText={setPaidAmount} keyboardType="numeric" placeholder="0" /></View></View>
      <View style={styles.inlineFields}><View style={{ flex: 1 }}><InputField label="الخصم" value={discountAmount} onChangeText={setDiscountAmount} keyboardType="numeric" placeholder="0" /></View><View style={{ flex: 1 }}><InputField label="تجديد الاشتراك" value={renewalDate} onChangeText={setRenewalDate} placeholder="YYYY-MM-DD" /></View></View>
      <Text style={styles.inlineHint}>المتبقي: {formatMoney(Math.max(0, (Number(totalAmount)||0) - (Number(discountAmount)||0) - (Number(paidAmount)||0)))} جنيه</Text>
    </View>
    <SectionHeader title="سجل الدفعات" subtitle={student ? `إجمالي الدفعات المسجلة: ${formatMoney(payments.filter(item => item.studentId === student.id).reduce((sum, item) => sum + item.amount, 0))} جنيه` : undefined} />
    {student && payments.filter(item => item.studentId === student.id).slice(0, 8).map(payment => <View key={payment.id} style={styles.profilePaymentRow}><View style={styles.profilePaymentIcon}><MaterialIcons name="payments" size={18} color={COLORS.primaryDeep} /></View><View style={{flex:1}}><Text style={styles.rowTitle}>{formatMoney(payment.amount)} جنيه</Text><Text style={styles.rowSub}>{formatDate(payment.paymentDate)}{payment.method ? ` · ${payment.method}` : ""}{payment.reference ? ` · ${payment.reference}` : ""}</Text></View></View>)}
    {student && !payments.some(item => item.studentId === student.id) ? <Text style={styles.inlineHint}>لا توجد دفعات مسجلة بعد. استخدمي زر «دفعة» لتسجيل أول دفعة.</Text> : null}
    <View style={styles.inlineFields}><View style={{ flex: 1 }}><InputField label="إجمالي الحصص" value={total} onChangeText={setTotal} keyboardType="numeric" /></View><View style={{ flex: 1 }}><InputField label="المتبقي" value={remaining} onChangeText={setRemaining} keyboardType="numeric" /></View></View>
    <Text style={styles.fieldLabel}>حالة الملف</Text>
    <View style={styles.choiceRow}><Choice label="نشط" selected={active === 1} onPress={() => setActive(1)} /><Choice label="موقوف" selected={active === 0} onPress={() => setActive(0)} tone="warning" /></View>
    <InputField label="آخر ملاحظة" value={notes} onChangeText={setNotes} placeholder="ملاحظة متابعة أو تفضيل مهم" multiline />
    <SectionHeader title="آخر الحصص" subtitle={history.length ? "سجل محفوظ محليًا" : "لا توجد حصص مسجلة بعد"} />
    {history.length ? history.map(session => <View key={session.id} style={styles.profileSessionRow}><View style={[styles.attendanceBadge, { backgroundColor: attendanceTone(session.attendance).background }]}><Text style={[styles.attendanceText, { color: attendanceTone(session.attendance).color }]}>{session.attendance || statusLabel(session.status)}</Text></View><View style={{ flex: 1 }}><Text style={styles.rowSub}>{formatDate(session.sessionDate)} · {session.startTime}</Text><Text numberOfLines={1} style={styles.profileSessionNotes}>{session.notes || session.homework || "لا توجد ملاحظات"}</Text></View></View>) : <Text style={styles.inlineHint}>أضيفي حصة من تبويب الحصص لتظهر في هذا السجل.</Text>}
    {isBritish ? <>
      <SectionHeader title="السجل الأكاديمي البريطاني" subtitle={studentScores.length ? `${studentScores.length} اختبار · متوسط ${examAverage}%` : "لا توجد درجات مسجلة بعد"} />
      <View style={styles.profileAcademicCard}>
        <View style={styles.profileAcademicMetric}><Text style={styles.profileAcademicValue}>{student?.britishLevel || "—"}</Text><Text style={styles.profileAcademicLabel}>Level</Text></View>
        <View style={styles.profileAcademicMetric}><Text style={styles.profileAcademicValue}>{student?.examBoard || "—"}</Text><Text style={styles.profileAcademicLabel}>Exam Board</Text></View>
        <View style={styles.profileAcademicMetric}><Text style={styles.profileAcademicValue}>{student?.qualification || "—"}</Text><Text style={styles.profileAcademicLabel}>Qualification</Text></View>
        <View style={styles.profileAcademicMetric}><Text style={styles.profileAcademicValue}>{examAverage ? `${examAverage}%` : "—"}</Text><Text style={styles.profileAcademicLabel}>Average</Text></View>
      </View>
      {studentScores.length ? studentScores.slice(0, 8).map(score => { const exam = exams.find(item => item.id === score.examId); return <View key={score.id} style={styles.profileExamRow}><View style={styles.profileExamGrade}><Text style={styles.profileExamGradeText}>{score.gradeLetter || "—"}</Text></View><View style={{flex:1}}><Text style={styles.rowTitle}>{exam?.title || "اختبار"}</Text><Text style={styles.rowSub}>{[exam?.subject, exam?.examBoard, exam?.qualification, exam?.examDate ? formatDate(exam.examDate) : ""].filter(Boolean).join(" · ")}</Text></View><Text style={styles.profileExamScore}>{score.score}/{exam?.maxScore ?? "—"}</Text></View> }) : <Text style={styles.inlineHint}>عند إدخال درجات اختبارات القسم البريطاني ستظهر هنا تلقائيًا.</Text>}
    </> : null}
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ التعديلات"} icon="save" onPress={save} disabled={saving} />
  </Sheet>;
}

function SessionsScreen({ sessions, timetable, onOpen, onStart, onComplete, onEdit, onReport, onDelete, onEditSlot, onToggleSlot, onDeleteSlot, onGenerateSessions }: { sessions: LessonSession[]; timetable: TimetableSlot[]; onOpen: (kind: "session" | "timetable") => void; onStart: (session: LessonSession) => void; onComplete: (session: LessonSession) => void; onEdit: (session: LessonSession) => void; onReport: (session: LessonSession) => void; onDelete: (session: LessonSession) => void; onEditSlot: (slot: TimetableSlot) => void; onToggleSlot: (slot: TimetableSlot) => void; onDeleteSlot: (slot: TimetableSlot) => void; onGenerateSessions: () => void }) {
  const [mode, setMode] = useState<"today" | "history" | "timetable">("today");
  const today = todayDate();
  const filtered = mode === "today" ? sessions.filter(session => session.sessionDate === today) : sessions;
  return (
    <FlatList
      data={mode === "timetable" ? timetable : filtered}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <>
          <SectionHeader title="الحصص والجدول" subtitle="ابدئي وأنهي الحصص دون مغادرة التطبيق" action={<View style={{ flexDirection: "row", gap: 8 }}>{mode === "timetable" ? <AppButton title="إنشاء الحصص" icon="auto-awesome" onPress={onGenerateSessions} tone="soft" compact /> : null}<AppButton title={mode === "timetable" ? "موعد" : "حصة"} icon="add" onPress={() => onOpen(mode === "timetable" ? "timetable" : "session")} compact /></View>} />
          <View style={styles.segmented}>
            <Choice label="اليوم" selected={mode === "today"} onPress={() => setMode("today")} />
            <Choice label="السجل" selected={mode === "history"} onPress={() => setMode("history")} />
            <Choice label="الأسبوع" selected={mode === "timetable"} onPress={() => setMode("timetable")} />
          </View>
        </>
      }
      ListEmptyComponent={<EmptyState icon={mode === "timetable" ? "calendar-month" : "event-note"} title={mode === "timetable" ? "لا توجد مواعيد أسبوعية" : "لا توجد حصص هنا"} body={mode === "timetable" ? "أضيفي موعدًا متكررًا للطالب أو المجموعة." : "أضيفي حصة جديدة من زر الإضافة."} />}
      renderItem={(info: ListRenderItemInfo<LessonSession | TimetableSlot>) => {
        if (mode === "timetable") {
          const slot = info.item as TimetableSlot;
          return <View style={[styles.slotCard, !slot.active && styles.slotCardPaused]}><View style={styles.slotIcon}><MaterialIcons name={slot.active ? "repeat" : "pause-circle-outline"} size={20} color={slot.active ? COLORS.primaryDeep : COLORS.muted} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{slot.title}</Text><Text style={styles.rowSub}>{slot.dayOfWeek} · {slot.startTime} · {slot.durationMinutes} دقيقة</Text>{slot.subject ? <Text style={styles.remainingText}>{slot.subject}</Text> : null}{!slot.active ? <Text style={styles.pausedText}>موقوف — لن يظهر ضمن خطة الأسبوع</Text> : null}</View><View style={styles.slotActions}><IconButton label="تعديل الموعد الأسبوعي" icon="edit" onPress={() => onEditSlot(slot)} /><IconButton label={slot.active ? "إيقاف الموعد" : "تفعيل الموعد"} icon={slot.active ? "pause" : "play-arrow"} onPress={() => onToggleSlot(slot)} /><IconButton label="حذف الموعد الأسبوعي" icon="delete-outline" onPress={() => onDeleteSlot(slot)} tone="danger" /></View></View>;
        }
        const session = info.item as LessonSession;
        return <SessionCard session={session} onStart={() => onStart(session)} onComplete={() => onComplete(session)} onEdit={() => onEdit(session)} onReport={session.status === "completed" ? () => onReport(session) : undefined} onDelete={() => onDelete(session)} />;
      }}
    />
  );
}

function BritishSectionScreen({ students, groups, onAddStudent, onAddGroup, onOpenStudent, onOpenGroup }: { students: Student[]; groups: TutoringGroup[]; onAddStudent: () => void; onAddGroup: () => void; onOpenStudent: (student: Student) => void; onOpenGroup: (group: TutoringGroup) => void }) {
  const britishStudents = students.filter(item => item.track === "القسم البريطاني");
  const britishGroups = groups.filter(item => item.track === "القسم البريطاني");
  return <FlatList
    data={britishStudents}
    keyExtractor={item => `british-student-${item.id}`}
    contentContainerStyle={styles.listContent}
    ListHeaderComponent={<View>
      <SectionHeader title="القسم البريطاني" subtitle="British Section · إدارة الطلاب والمجموعات والمواد البريطانية" action={<View style={{ flexDirection: "row", gap: 8 }}><AppButton title="مجموعة" icon="group-add" onPress={onAddGroup} compact /><AppButton title="طالبة" icon="person-add-alt-1" onPress={onAddStudent} compact /></View>} />
      <View style={styles.summaryCard}><View><Text style={styles.summaryLabel}>طالبات القسم البريطاني</Text><Text style={styles.summaryValue}>{britishStudents.length}</Text></View><View><Text style={styles.summaryLabel}>المجموعات</Text><Text style={styles.summaryValue}>{britishGroups.length}</Text></View><View><Text style={styles.summaryLabel}>المراحل</Text><Text style={styles.summaryValue}>{BRITISH_GRADES.length}</Text></View></View>
      <Text style={styles.sectionMiniTitle}>المجموعات البريطانية</Text>
      {britishGroups.length ? britishGroups.map(group => <Pressable key={group.id} onPress={() => onOpenGroup(group)} style={styles.rowCard}><View style={styles.groupIcon}><MaterialIcons name="language" size={22} color={COLORS.primaryDeep} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{group.name}</Text><Text style={styles.rowSub}>{[group.grade, group.subject, `${group.memberNames ? group.memberNames.split(",").filter(Boolean).length : 0} طالبات`].filter(Boolean).join(" · ")}</Text></View><MaterialIcons name="chevron-left" size={22} color={COLORS.muted} /></Pressable>) : <Text style={styles.inlineHint}>لم تُنشأ مجموعات بريطانية بعد.</Text>}
      <Text style={[styles.sectionMiniTitle, { marginTop: 14 }]}>طالبات القسم البريطاني</Text>
    </View>}
    renderItem={({ item }) => <Pressable onPress={() => onOpenStudent(item)} style={styles.rowCard}><View style={styles.studentAvatar}><Text style={styles.studentAvatarText}>{item.name.slice(0,1)}</Text></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.name}</Text><Text style={styles.rowSub}>{[item.grade, item.subject].filter(Boolean).join(" · ") || "لم تُحدّد المرحلة أو المادة"}</Text></View><MaterialIcons name="chevron-left" size={22} color={COLORS.muted} /></Pressable>}
    ListEmptyComponent={<EmptyState icon="language" title="لا توجد طالبات بالقسم البريطاني" body="أضيفي أول طالبة وحددي القسم البريطاني والـ Year أو IGCSE / A Level." action={<AppButton title="إضافة طالبة" icon="person-add-alt-1" onPress={onAddStudent} compact />} />}
  />;
}

function GroupsScreen({ groups, onAdd, onOpen, onDelete }: { groups: TutoringGroup[]; onAdd: () => void; onOpen: (group: TutoringGroup) => void; onDelete: (group: TutoringGroup) => void }) {
  return (
    <FlatList
      data={groups}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={<SectionHeader title="المجموعات" subtitle="اشتراك موحّد وحصص جماعية محلية" action={<AppButton title="مجموعة" icon="group-add" onPress={onAdd} compact />} />}
      ListEmptyComponent={<EmptyState icon="groups" title="لا توجد مجموعات" body="أنشئي مجموعة وحددي السعة والاشتراك والحصص." action={<AppButton title="إنشاء مجموعة" icon="add" onPress={onAdd} compact />} />}
      renderItem={({ item }) => (
        <View style={styles.groupCard}>
          <View style={styles.groupTop}><Pressable accessibilityRole="button" accessibilityLabel={`فتح تفاصيل ${item.name}`} onPress={() => onOpen(item)} style={({ pressed }) => [styles.groupPressTarget, pressed && { opacity: 0.7 }]}><View style={styles.groupIcon}><MaterialIcons name="groups" size={22} color={COLORS.primaryDeep} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.name}</Text><Text style={styles.rowSub}>{[item.academy, item.grade, item.subject].filter(Boolean).join(" · ") || "تفاصيل الصف والمادة غير محددة"}</Text></View></Pressable><IconButton label={`حذف ${item.name}`} icon="delete-outline" onPress={() => onDelete(item)} tone="danger" /></View>
          <View style={styles.groupStats}><View><Text style={styles.groupStatValue}>{item.totalSessions}</Text><Text style={styles.groupStatLabel}>الإجمالي</Text></View><View><Text style={styles.groupStatValue}>{item.completedSessions}</Text><Text style={styles.groupStatLabel}>المنجزة</Text></View><View><Text style={styles.groupStatValue}>{item.remainingSessions}</Text><Text style={styles.groupStatLabel}>المتبقي</Text></View><View><Text style={styles.groupStatValue}>{item.capacity}</Text><Text style={styles.groupStatLabel}>السعة</Text></View></View>
          {item.memberNames ? <View style={styles.memberStrip}><MaterialIcons name="people-alt" size={16} color={COLORS.muted} /><Text style={styles.memberText}>{item.memberNames}</Text></View> : null}
        </View>
      )}
    />
  );
}

function ExamsScreen({ exams, scores, onAdd, onOpen, onDelete }: { exams: Exam[]; scores: ExamScore[]; onAdd: () => void; onOpen: (exam: Exam) => void; onDelete: (exam: Exam) => void }) {
  const british = exams.filter(exam => exam.track === "القسم البريطاني");
  const average = scores.length ? Math.round(scores.reduce((sum, item) => sum + item.percentage, 0) / scores.length) : 0;
  return <FlatList data={exams} keyExtractor={item => String(item.id)} contentContainerStyle={styles.listContent}
    ListHeaderComponent={<><SectionHeader title="الاختبارات والدرجات" subtitle="الامتحان → الطالب → الدرجة → النسبة → التقدير" action={<AppButton title="اختبار" icon="add-task" onPress={onAdd} compact />} />
      <View style={styles.metricsGrid}><View style={styles.metricCard}><Text style={styles.metricValue}>{exams.length}</Text><Text style={styles.metricLabel}>اختبارات</Text></View><View style={styles.metricCard}><Text style={styles.metricValue}>{scores.length}</Text><Text style={styles.metricLabel}>درجات مسجلة</Text></View><View style={styles.metricCard}><Text style={styles.metricValue}>{average}%</Text><Text style={styles.metricLabel}>متوسط الدرجات</Text></View><View style={styles.metricCard}><Text style={styles.metricValue}>{british.length}</Text><Text style={styles.metricLabel}>اختبارات بريطاني</Text></View></View></>}
    ListEmptyComponent={<EmptyState icon="assignment" title="لا توجد اختبارات" body="أنشئي أول اختبار واربطِيه بالصف والمادة والمجموعة." action={<AppButton title="إنشاء اختبار" icon="add" onPress={onAdd} compact />} />}
    renderItem={({ item }) => { const rows=scores.filter(score=>score.examId===item.id); const avg=rows.length ? Math.round(rows.reduce((a,b)=>a+b.percentage,0)/rows.length) : 0; return <View style={styles.examCard}><View style={styles.examTop}><View style={styles.examIcon}><MaterialIcons name="assignment" size={22} color={COLORS.primaryDeep}/></View><View style={{flex:1}}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.rowSub}>{[item.track,item.grade,item.britishLevel,item.subject,item.examBoard,item.qualification].filter(Boolean).join(" · ") || "اختبار أكاديمي"}</Text></View><IconButton label={`حذف ${item.title}`} icon="delete-outline" onPress={()=>onDelete(item)} tone="danger"/></View><View style={styles.examMeta}><Text style={styles.examMetaText}>{formatDate(item.examDate)} · الدرجة النهائية {item.maxScore}</Text><Text style={styles.examMetaText}>{rows.length} درجات · متوسط {avg}%</Text></View><AppButton title={rows.length ? "إدارة الدرجات" : "إدخال الدرجات"} icon="grading" onPress={()=>onOpen(item)} compact tone="soft" /></View>; }} />;
}

function ExamSheet({ visible, onClose, onSaved, groups }: { visible: boolean; onClose: () => void; onSaved: () => Promise<void>; groups: TutoringGroup[] }) {
  const [title,setTitle]=useState(""); const [track,setTrack]=useState("القسم البريطاني"); const [grade,setGrade]=useState(""); const [level,setLevel]=useState(""); const [board,setBoard]=useState(""); const [qualification,setQualification]=useState(""); const [subject,setSubject]=useState(""); const [groupId,setGroupId]=useState<number|null>(null); const [date,setDate]=useState(todayDate()); const [max,setMax]=useState("100"); const [notes,setNotes]=useState(""); const [saving,setSaving]=useState(false);
  const matchingGroups=groups.filter(g=>g.track===track && (!subject || g.subject===subject) && (!grade || g.grade===grade));
  useEffect(()=>{ if(visible){setTitle("");setTrack("القسم البريطاني");setGrade("");setLevel("");setBoard("");setQualification("");setSubject("");setGroupId(null);setDate(todayDate());setMax("100");setNotes("");}},[visible]);
  async function save(){ if(!title.trim()) return Alert.alert("اسم الاختبار مطلوب","اكتبي اسم الاختبار."); if(!subject) return Alert.alert("المادة مطلوبة","اختاري المادة."); try{setSaving(true);const group=groups.find(g=>g.id===groupId);await createExam({title,track,grade:grade||null,britishLevel:level||null,examBoard:board||null,qualification:qualification||null,subject,groupId,groupName:group?.name||null,examDate:date,maxScore:Number(max)||100,notes});await onSaved();onClose();Alert.alert("تم حفظ الاختبار","يمكنك الآن إدخال درجات الطالبات.");}catch(e){Alert.alert("تعذر الحفظ",e instanceof Error?e.message:"حاولي مرة أخرى.")}finally{setSaving(false)}}
  return <Sheet visible={visible} title="إنشاء اختبار" subtitle="اربطِيه بالمنهج البريطاني أو القسم العربي" onClose={onClose}><AcademicPicker label="القسم" value={track} options={TRACKS} onChange={v=>{setTrack(v);setGroupId(null)}} />{track==="القسم البريطاني"?<><AcademicPicker label="Year" value={grade} options={BRITISH_GRADES} onChange={v=>{setGrade(v);setGroupId(null)}}/><AcademicPicker label="المستوى" value={level} options={BRITISH_LEVELS} onChange={setLevel}/><AcademicPicker label="Exam Board" value={board} options={EXAM_BOARDS} onChange={setBoard}/><AcademicPicker label="Qualification" value={qualification} options={BRITISH_QUALIFICATIONS} onChange={setQualification}/></>:<AcademicPicker label="الصف" value={grade} options={GRADES} onChange={v=>{setGrade(v);setGroupId(null)}}/>}<AcademicPicker label="المادة" value={subject} options={SUBJECTS} onChange={v=>{setSubject(v);setGroupId(null)}}/><Text style={styles.fieldLabel}>المجموعة</Text><View style={styles.choiceWrap}>{matchingGroups.map(g=><Choice key={g.id} label={g.name} selected={groupId===g.id} onPress={()=>setGroupId(g.id)}/>)}</View>{matchingGroups.length===0?<Text style={styles.inlineHint}>لا توجد مجموعة مطابقة بعد؛ يمكن حفظ الاختبار بدون مجموعة.</Text>:null}<InputField label="اسم الاختبار" value={title} onChangeText={setTitle} placeholder="مثال: IGCSE Biology Mock 1"/><InputField label="التاريخ" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD"/><InputField label="الدرجة النهائية" value={max} onChangeText={setMax} keyboardType="numeric" placeholder="100"/><InputField label="ملاحظات" value={notes} onChangeText={setNotes} placeholder="اختياري" multiline/><AppButton title={saving?"جارٍ الحفظ...":"حفظ الاختبار"} icon="save" onPress={save} disabled={saving}/></Sheet>;
}

function ExamScoresSheet({ exam, students, scores, onClose, onSaved }: { exam: Exam|null; students: Student[]; scores: ExamScore[]; onClose:()=>void; onSaved:()=>Promise<void> }) {
  const eligible=students.filter(s=>s.active && (!exam?.track || s.track===exam.track) && (!exam?.grade || s.grade===exam.grade) && (!exam?.subject || s.subject===exam.subject || !s.subject) && (!exam?.britishLevel || s.britishLevel===exam.britishLevel || !s.britishLevel));
  const [values,setValues]=useState<Record<number,string>>({}); const [saving,setSaving]=useState(false);
  useEffect(()=>{ if(exam){const next:Record<number,string>={};scores.filter(x=>x.examId===exam.id).forEach(x=>next[x.studentId]=String(x.score));setValues(next)}},[exam?.id,scores]);
  async function save(){if(!exam)return;try{setSaving(true);for(const student of eligible){const raw=values[student.id];if(raw!==undefined&&raw!=="")await saveExamScore({examId:exam.id,studentId:student.id,studentName:student.name,score:Number(raw)||0,maxScore:exam.maxScore});}await onSaved();Alert.alert("تم حفظ الدرجات","تم تحديث النسب والتقديرات تلقائيًا.");onClose()}catch(e){Alert.alert("تعذر حفظ الدرجات",e instanceof Error?e.message:"حاولي مرة أخرى.")}finally{setSaving(false)}}
  return <Sheet visible={Boolean(exam)} title={exam?.title||"درجات الاختبار"} subtitle={exam?[`${exam.subject||""} · ${exam.maxScore} درجة`,exam.examBoard,exam.qualification].filter(Boolean).join(" · "):undefined} onClose={onClose}><View style={styles.examInfoCard}><Text style={styles.rowTitle}>{exam?.grade||""} {exam?.britishLevel?`· ${exam.britishLevel}`:""}</Text><Text style={styles.rowSub}>{exam?.groupName||"كل الطالبات المطابقات"}</Text></View>{eligible.length?eligible.map(student=>{const existing=scores.find(x=>x.examId===exam?.id&&x.studentId===student.id);return <View key={student.id} style={styles.scoreRow}><View style={{flex:1}}><Text style={styles.rowTitle}>{student.name}</Text><Text style={styles.rowSub}>{existing?`${existing.percentage}% · ${existing.gradeLetter}`:"لم تُسجل بعد"}</Text></View><TextInput value={values[student.id]??""} onChangeText={v=>setValues(cur=>({...cur,[student.id]:v}))} keyboardType="decimal-pad" placeholder="الدرجة" placeholderTextColor="#92958D" style={[styles.input,{width:90,textAlign:"center"}]}/></View>}) : <Text style={styles.inlineHint}>لا توجد طالبات مطابقات لهذا الاختبار. تأكدي من القسم والصف والمادة.</Text>}<AppButton title={saving?"جارٍ حفظ الدرجات...":"حفظ الدرجات"} icon="grading" onPress={save} disabled={saving||!eligible.length}/></Sheet>;
}

function AttendanceScreen({ students, groups, sessions, records, onSaved }: { students: Student[]; groups: TutoringGroup[]; sessions: LessonSession[]; records: AttendanceRecord[]; onSaved: () => Promise<void> }) {
  const [groupId, setGroupId] = useState<number | null>(groups[0]?.id ?? null);
  const [date, setDate] = useState(todayDate());
  const [saving, setSaving] = useState(false);
  const group = groups.find(item => item.id === groupId) ?? null;
  const members = group?.memberNames ? group.memberNames.split(",").map(x => x.trim()).filter(Boolean) : [];
  const memberStudents = members.map(name => students.find(s => s.name.trim() === name)).filter(Boolean) as Student[];
  const groupSession = sessions.find(s => s.groupId === groupId && s.sessionDate === date);
  const statuses = new Map(records.filter(r => r.groupId === groupId && r.attendanceDate === date).map(r => [r.studentId, r]));
  const [local, setLocal] = useState<Record<number, AttendanceRecord["status"]>>({});
  useEffect(() => { const next: Record<number, AttendanceRecord["status"]> = {}; memberStudents.forEach(st => { next[st.id] = statuses.get(st.id)?.status ?? "حاضر"; }); setLocal(next); }, [groupId, date, records.length, group?.memberNames]);
  async function saveAll() {
    if (!group || !memberStudents.length) return Alert.alert("لا توجد طالبات", "أضيفي الطالبات إلى المجموعة أولًا.");
    try { setSaving(true); for (const student of memberStudents) { const status = local[student.id] ?? "حاضر"; await saveAttendanceRecord({ sessionId: groupSession?.id ?? null, groupId: group.id, studentId: student.id, studentName: student.name, attendanceDate: date, status }); if (status === "غائب" || status === "بعذر") void sendAttendanceAlert(student.name, status, date); } await onSaved(); Alert.alert("تم حفظ الحضور", `تم حفظ حضور ${memberStudents.length} طالبة.`); } catch (error) { Alert.alert("تعذر حفظ الحضور", error instanceof Error ? error.message : "حاولي مرة أخرى."); } finally { setSaving(false); }
  }
  const counts = Object.values(local).reduce((a, v) => { a[v] = (a[v] ?? 0) + 1; return a; }, {} as Record<string, number>);
  return <ScrollView contentContainerStyle={styles.scrollContent}>
    <SectionHeader title="الحضور" subtitle="حضور فردي لكل طالبة مرتبط بالمجموعة والحصة والتاريخ" />
    <View style={styles.filterCard}><Text style={styles.fieldLabel}>المجموعة</Text><View style={styles.choiceWrap}>{groups.map(g => <Choice key={g.id} label={g.name} selected={groupId === g.id} onPress={() => setGroupId(g.id)} />)}</View><InputField label="التاريخ" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" /></View>
    {group ? <View style={styles.summaryCard}><View><Text style={styles.summaryLabel}>حاضر</Text><Text style={styles.summaryValue}>{counts["حاضر"] ?? 0}</Text></View><View><Text style={styles.summaryLabel}>متأخر</Text><Text style={styles.summaryValue}>{counts["متأخر"] ?? 0}</Text></View><View><Text style={styles.summaryLabel}>غائب</Text><Text style={styles.summaryValue}>{counts["غائب"] ?? 0}</Text></View><View><Text style={styles.summaryLabel}>بعذر</Text><Text style={styles.summaryValue}>{counts["بعذر"] ?? 0}</Text></View></View> : null}
    {memberStudents.length ? memberStudents.map(student => <View key={student.id} style={styles.rowCard}><View style={styles.studentAvatar}><Text style={styles.studentAvatarText}>{student.name.slice(0,1)}</Text></View><View style={{flex:1}}><Text style={styles.rowTitle}>{student.name}</Text><Text style={styles.rowSub}>{student.grade || student.britishLevel || ""} · {student.subject || group?.subject || ""}</Text><View style={styles.choiceWrap}>{(["حاضر","متأخر","غائب","بعذر"] as const).map(status => <Choice key={status} label={status} selected={local[student.id] === status} onPress={() => setLocal(current => ({...current, [student.id]: status}))} tone={status === "غائب" || status === "بعذر" ? "danger" : status === "متأخر" ? "warning" : undefined} />)}</View>{local[student.id] === "غائب" || local[student.id] === "بعذر" ? <AppButton title="رسالة لولي الأمر" icon="chat" compact tone="soft" onPress={() => { const label = local[student.id] === "بعذر" ? "بعذر" : "غائب"; void shareAcademicReport(`إشعار حضور — NANELSH Academy OS\n\nالطالبة: ${student.name}\nالمجموعة: ${group.name}\nالتاريخ: ${date}\nالحالة: ${label}\n\nيرجى التواصل مع الأكاديمية عند الحاجة.`).catch(error => Alert.alert("تعذر مشاركة الرسالة", error instanceof Error ? error.message : "حاولي مرة أخرى.")); }} /> : null}</View></View>) : <EmptyState icon="groups" title="لا توجد طالبات في المجموعة" body="افتحي المجموعة وأضيفي الطالبات أولًا." />}
    <AppButton title={saving ? "جارٍ حفظ الحضور..." : "حفظ حضور المجموعة"} icon="save" onPress={() => void saveAll()} disabled={saving || !memberStudents.length} />
    <Text style={styles.inlineHint}>يمكن تعديل حضور كل طالبة بشكل مستقل، ثم مشاركة تقرير الغياب من صفحة التقارير.</Text>
  </ScrollView>;
}

function AcademicReportsScreen({ students, exams, scores, groups, sessions }: { students: Student[]; exams: Exam[]; scores: ExamScore[]; groups: TutoringGroup[]; sessions: LessonSession[] }) {
  const [filter, setFilter] = useState<"all" | "british" | "arabic">("all");
  const filtered = students.filter(s => filter === "all" || (filter === "british" ? s.track === "القسم البريطاني" : s.track !== "القسم البريطاني"));
  const makeStudentReport = (student: Student) => {
    const studentScores = scores.filter(score => score.studentId === student.id);
    const average = studentScores.length ? studentScores.reduce((sum, score) => sum + score.percentage, 0) / studentScores.length : 0;
    const lines = [
      "NANELSH Academy OS — التقرير الأكاديمي", "",
      `الطالبة: ${student.name}`, `القسم: ${student.track || "غير محدد"}`, `الصف / Year: ${student.grade || "غير محدد"}`,
      `المادة: ${student.subject || "غير محددة"}`, ...(student.track === "القسم البريطاني" ? [`Level: ${student.britishLevel || "—"}`, `Exam Board: ${student.examBoard || "—"}`, `Qualification: ${student.qualification || "—"}`] : []),
      `متوسط الاختبارات: ${studentScores.length ? `${Math.round(average)}%` : "لا توجد درجات"}`, `عدد الاختبارات: ${studentScores.length}`, "",
      "نتائج الاختبارات:", ...studentScores.map(score => { const exam = exams.find(e => e.id === score.examId); return `• ${exam?.title || "اختبار"} — ${score.score}/${score.maxScore} — ${score.percentage}% — ${score.gradeLetter || "—"}`; }),
      "", "المجموعات المرتبطة:", ...groups.filter(g => (g.memberNames || "").split(",").map(x => x.trim()).includes(student.name)).map(g => `• ${g.name} — ${g.subject || ""} — ${g.grade || ""}`),
    ];
    return lines.join("\n");
  };
  const shareStudent = async (student: Student) => { try { await shareAcademicReport(makeStudentReport(student)); } catch (e) { Alert.alert("تعذر مشاركة التقرير", e instanceof Error ? e.message : "حاولي مرة أخرى."); } };
  const makeGroupReport = (group: TutoringGroup) => {
    const names = (group.memberNames || "").split(",").map(x => x.trim()).filter(Boolean);
    const members = students.filter(s => names.includes(s.name));
    const groupExams = exams.filter(e => e.groupId === group.id || (e.groupName && e.groupName === group.name));
    const groupScores = scores.filter(sc => groupExams.some(e => e.id === sc.examId));
    const average = groupScores.length ? groupScores.reduce((sum, sc) => sum + sc.percentage, 0) / groupScores.length : 0;
    const sessionsForGroup = sessions.filter(s => s.groupId === group.id || (s.groupName && s.groupName === group.name));
    const attendanceSessions = sessionsForGroup.filter(s => s.attendance);
    const present = attendanceSessions.filter(s => s.attendance === "حاضر" || s.attendance === "متأخر").length;
    const absent = attendanceSessions.filter(s => s.attendance === "غائب").length;
    const lines = [
      "NANELSH Academy OS — تقرير المجموعة", "",
      `المجموعة: ${group.name}`, `القسم: ${group.track || "غير محدد"}`, `الصف / Year: ${group.grade || "غير محدد"}`,
      `المادة: ${group.subject || "غير محددة"}`, ...(group.track === "القسم البريطاني" ? [`Level: ${group.britishLevel || "—"}`, `Exam Board: ${group.examBoard || "—"}`, `Qualification: ${group.qualification || "—"}`] : []),
      `عدد الطالبات: ${members.length}`, `متوسط الاختبارات: ${groupScores.length ? `${Math.round(average)}%` : "لا توجد درجات"}`,
      `الحصص المسجلة: ${sessionsForGroup.length}`, `الحضور المسجل: ${attendanceSessions.length}`, `حاضر/متأخر: ${present}`, `غائب: ${absent}`, "",
      "الطالبات:", ...members.map(student => { const ss = scores.filter(sc => sc.studentId === student.id && groupExams.some(e => e.id === sc.examId)); const avg = ss.length ? Math.round(ss.reduce((a,b) => a + b.percentage, 0) / ss.length) : null; return `• ${student.name} — ${avg === null ? "لا توجد درجات" : `${avg}%`}`; }),
      "", "الاختبارات:", ...groupExams.map(exam => `• ${exam.title} — ${formatDate(exam.examDate)} — ${exam.subject || ""}`),
    ];
    return lines.join("\n");
  };
  const shareGroup = async (group: TutoringGroup) => { try { await shareAcademicReport(makeGroupReport(group)); } catch (e) { Alert.alert("تعذر مشاركة تقرير المجموعة", e instanceof Error ? e.message : "حاولي مرة أخرى."); } };
  return <FlatList
    data={filtered}
    keyExtractor={item => `report-${item.id}`}
    contentContainerStyle={styles.listContent}
    ListHeaderComponent={<View><SectionHeader title="التقارير الأكاديمية" subtitle="تقارير فردية وتقارير مجموعات جاهزة للمشاركة عبر WhatsApp" />
      <View style={styles.choiceWrap}><Choice label="كل الطالبات" selected={filter === "all"} onPress={() => setFilter("all")} /><Choice label="العربي" selected={filter === "arabic"} onPress={() => setFilter("arabic")} /><Choice label="القسم البريطاني" selected={filter === "british"} onPress={() => setFilter("british")} /></View>
      <View style={styles.summaryCard}><Text style={styles.summaryLabel}>تقارير المجموعات</Text>{groups.length ? groups.map(group => { const count = (group.memberNames || "").split(",").map(x => x.trim()).filter(Boolean).length; return <View key={`group-report-${group.id}`} style={styles.reportGroupRow}><View style={styles.groupIcon}><MaterialIcons name="groups" size={20} color={COLORS.primaryDeep}/></View><View style={{flex:1}}><Text style={styles.rowTitle}>{group.name}</Text><Text style={styles.rowSub}>{[group.track, group.grade, group.subject, `${count} طالبات`].filter(Boolean).join(" · ")}</Text></View><AppButton title="مشاركة" icon="share" onPress={() => void shareGroup(group)} compact /></View>; }) : <Text style={styles.inlineHint}>لا توجد مجموعات بعد.</Text>}</View></View>}
    renderItem={({ item }) => { const ss=scores.filter(x=>x.studentId===item.id); const avg=ss.length?Math.round(ss.reduce((a,b)=>a+b.percentage,0)/ss.length):0; return <View style={styles.reportCard}><View style={styles.studentAvatar}><Text style={styles.studentAvatarText}>{item.name.slice(0,1)}</Text></View><View style={{flex:1}}><Text style={styles.rowTitle}>{item.name}</Text><Text style={styles.rowSub}>{[item.track,item.grade,item.subject].filter(Boolean).join(" · ")}</Text><Text style={styles.reportAverage}>{ss.length ? `متوسط الاختبارات ${avg}%` : "لا توجد درجات بعد"}</Text></View><AppButton title="مشاركة" icon="share" onPress={() => void shareStudent(item)} compact /></View>; }}
    ListEmptyComponent={<EmptyState icon="description" title="لا توجد طالبات" body="أضيفي الطالبات أولًا لإنشاء التقارير الأكاديمية." />}
  />;
}

function AcademicProgressScreen({ students, exams, scores }: { students: Student[]; exams: Exam[]; scores: ExamScore[] }) {
  const britishStudents = students.filter(student => student.track === "القسم البريطاني");
  const rows = britishStudents.map(student => {
    const studentScores = scores.filter(score => score.studentId === student.id);
    const average = studentScores.length ? studentScores.reduce((sum, score) => sum + score.percentage, 0) / studentScores.length : 0;
    const ordered = [...studentScores].sort((a, b) => a.id - b.id);
    const first = ordered[0]?.percentage ?? null;
    const last = ordered.at(-1)?.percentage ?? null;
    const delta = first !== null && last !== null && ordered.length > 1 ? last - first : 0;
    const strongest = studentScores.length ? Math.max(...studentScores.map(score => score.percentage)) : 0;
    const weakest = studentScores.length ? Math.min(...studentScores.map(score => score.percentage)) : 0;
    const status = !studentScores.length ? "لا توجد درجات" : average >= 85 ? "ممتاز" : average >= 70 ? "جيد جدًا" : average >= 60 ? "جيد" : "يحتاج متابعة";
    return { student, studentScores, average, delta, strongest, weakest, status };
  }).sort((a, b) => b.average - a.average);
  const allScores = scores.filter(score => exams.some(exam => exam.id === score.examId));
  const overall = allScores.length ? Math.round(allScores.reduce((sum, score) => sum + score.percentage, 0) / allScores.length) : 0;
  const improving = rows.filter(row => row.delta > 2).length;
  const needsSupport = rows.filter(row => row.studentScores.length && row.average < 60).length;
  return <FlatList
    data={rows}
    keyExtractor={item => `progress-${item.student.id}`}
    contentContainerStyle={styles.listContent}
    ListHeaderComponent={<View>
      <SectionHeader title="التقدم الأكاديمي" subtitle="متابعة تطور الطالبات بناءً على نتائج الاختبارات" />
      <View style={styles.metricsGrid}>
        <View style={styles.metricCard}><Text style={styles.metricValue}>{overall}%</Text><Text style={styles.metricLabel}>متوسط الدرجات</Text></View>
        <View style={styles.metricCard}><Text style={styles.metricValue}>{scores.length}</Text><Text style={styles.metricLabel}>درجات مسجلة</Text></View>
        <View style={styles.metricCard}><Text style={styles.metricValue}>{improving}</Text><Text style={styles.metricLabel}>في تحسن</Text></View>
        <View style={styles.metricCard}><Text style={styles.metricValue}>{needsSupport}</Text><Text style={styles.metricLabel}>تحتاج متابعة</Text></View>
      </View>
      <View style={styles.summaryCard}><View style={{ flex: 1 }}><Text style={styles.summaryLabel}>لوحة المتابعة</Text><Text style={styles.inlineHint}>يتم احتساب المتوسط والاتجاه وأفضل وأضعف نتيجة لكل طالبة تلقائيًا من سجل الاختبارات.</Text></View></View>
    </View>}
    renderItem={({ item }) => <View style={styles.examCard}>
      <View style={styles.examTop}><View style={styles.studentAvatar}><Text style={styles.studentAvatarText}>{item.student.name.slice(0,1)}</Text></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.student.name}</Text><Text style={styles.rowSub}>{[item.student.grade, item.student.subject, item.student.britishLevel, item.student.examBoard, item.student.qualification].filter(Boolean).join(" · ")}</Text></View><Text style={[styles.progressStatus, item.average >= 85 ? styles.progressGood : item.average < 60 ? styles.progressAlert : styles.progressNeutral]}>{item.status}</Text></View>
      <View style={styles.examMeta}><Text style={styles.examMetaText}>المتوسط {Math.round(item.average)}% · أفضل {Math.round(item.strongest)}% · أضعف {Math.round(item.weakest)}%</Text><Text style={styles.examMetaText}>{item.studentScores.length} اختبارًا مسجلًا {item.delta ? `· الاتجاه ${item.delta > 0 ? "↑" : "↓"} ${Math.abs(Math.round(item.delta))}%` : ""}</Text></View>
      <View style={styles.progressBar}><View style={[styles.academicProgressFill, { width: `${Math.min(100, Math.max(0, item.average))}%` }]} /></View>
    </View>}
    ListEmptyComponent={<EmptyState icon="trending-up" title="لا توجد بيانات أكاديمية بعد" body="أضيفي طالبات بالقسم البريطاني ثم أنشئي اختبارات وسجلي الدرجات لتظهر لوحة التقدم هنا." />}
  />;
}

function FinanceScreen({ transactions, subscriptions, onOpen, onDelete }: { transactions: FinanceTransaction[]; subscriptions: StudentSubscription[]; onOpen: () => void; onDelete: (transaction: FinanceTransaction) => void }) {
  const summary = useMemo(() => {
    const values = { income: 0, expense: 0, refund: 0, discount: 0 };
    transactions.forEach(transaction => { values[transaction.type] += transaction.amount; });
    return { ...values, net: values.income - values.expense - values.refund - values.discount };
  }, [transactions]);
  return (
    <FlatList
      data={transactions}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <>
          <SectionHeader title="المالية" subtitle="صافي الحساب = الإيرادات − المصروفات − الاستردادات − الخصومات" action={<AppButton title="حركة" icon="add-card" onPress={onOpen} compact />} />
          <View style={styles.financeNetCard}><Text style={styles.financeNetLabel}>صافي الحساب</Text><Text style={styles.financeNetValue}>{formatMoney(summary.net)}</Text><Text style={styles.financeNetFoot}>محفوظ محليًا على هذا الهاتف</Text></View>
          <View style={styles.financeMetrics}><MiniFinance label="إيرادات" value={summary.income} color={COLORS.success} background={COLORS.successSoft} /><MiniFinance label="مصروفات" value={summary.expense} color={COLORS.warning} background={COLORS.warningSoft} /><MiniFinance label="استرداد" value={summary.refund} color={COLORS.danger} background={COLORS.dangerSoft} /><MiniFinance label="خصومات" value={summary.discount} color={COLORS.primaryDeep} background={COLORS.lavender} /></View>
          <View style={styles.unifiedFinanceCard}><Text style={styles.financeSectionTitle}>حسابات الطالبات الموحدة</Text><View style={styles.financeMetrics}><MiniFinance label="إجمالي المتبقي" value={subscriptions.reduce((sum, item) => sum + item.balance, 0)} color={COLORS.danger} background={COLORS.dangerSoft} /><MiniFinance label="حسابات مكتملة" value={subscriptions.filter(item => item.status === "paid").length} color={COLORS.success} background={COLORS.successSoft} /></View>{subscriptions.filter(item => item.balance > 0).slice(0, 5).map(item => <View key={item.id} style={styles.subscriptionRow}><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.studentName}</Text><Text style={styles.rowSub}>المتبقي {formatMoney(item.balance)} جنيه{item.renewalDate ? ` · التجديد ${item.renewalDate}` : ""}</Text></View><Text style={styles.subscriptionBalance}>{formatMoney(item.balance)}</Text></View>)}</View>
          <SectionHeader title="آخر الحركات" />
        </>
      }
      ListEmptyComponent={<EmptyState icon="receipt-long" title="لا توجد حركات مالية" body="أضيفي إيرادًا أو مصروفًا أو استردادًا أو خصمًا." />}
      renderItem={({ item }) => <TransactionRow transaction={item} onDelete={() => onDelete(item)} />}
    />
  );
}

function MiniFinance({ label, value, color, background }: { label: string; value: number; color: string; background: string }) {
  return <View style={[styles.miniFinance, { backgroundColor: background }]}><Text style={[styles.miniFinanceValue, { color }]}>{formatMoney(value)}</Text><Text style={[styles.miniFinanceLabel, { color }]}>{label}</Text></View>;
}

function TransactionRow({ transaction, onDelete }: { transaction: FinanceTransaction; onDelete: () => void }) {
  const details: Record<TransactionType, { label: string; icon: IconName; color: string; background: string }> = {
    income: { label: "إيراد", icon: "south-west", color: COLORS.success, background: COLORS.successSoft },
    expense: { label: "مصروف", icon: "north-east", color: COLORS.warning, background: COLORS.warningSoft },
    refund: { label: "استرداد", icon: "undo", color: COLORS.danger, background: COLORS.dangerSoft },
    discount: { label: "خصم", icon: "sell", color: COLORS.primaryDeep, background: COLORS.lavender },
  };
  const detail = details[transaction.type];
  return <View style={styles.transactionRow}><View style={[styles.transactionIcon, { backgroundColor: detail.background }]}><MaterialIcons name={detail.icon} size={19} color={detail.color} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{transaction.description || detail.label}</Text><Text style={styles.rowSub}>{detail.label} · {formatDate(transaction.transactionDate)}</Text></View><View style={{ alignItems: "flex-end", gap: 8 }}><Text style={[styles.transactionAmount, { color: detail.color }]}>{formatMoney(transaction.amount)}</Text><Pressable accessibilityRole="button" accessibilityLabel="حذف الحركة" onPress={onDelete}><Text style={styles.deleteText}>حذف</Text></Pressable></View></View>;
}

function SettingsScreen({ onReload }: { onReload: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  const [notificationStatus, setNotificationStatus] = useState("غير معروف");
  useEffect(() => { void getNotificationPermissionState().then(status => setNotificationStatus(status === "granted" ? "مفعّلة" : "غير مفعّلة")); }, []);
  async function testNotifications() {
    try { setBusy(true); await sendTestNotification(); setNotificationStatus("مفعّلة"); Alert.alert("تم الاختبار", "سيظهر الآن تنبيه بصوت على الشاشة. إذا لم يظهر، افتحي إعدادات Android واسمحي بالإشعارات والصوت."); }
    catch (error) { Alert.alert("التنبيهات غير مفعّلة", error instanceof Error ? error.message : "اسمحي بالتنبيهات من إعدادات Android."); }
    finally { setBusy(false); }
  }
  async function backup() {
    try {
      setBusy(true);
      await shareLocalBackup();
      Alert.alert("تم إنشاء النسخة", "احفظي ملف JSON في مكان آمن على هاتفك.");
    } catch (error) {
      Alert.alert("تعذر إنشاء النسخة", error instanceof Error ? error.message : "حدث خطأ غير متوقع");
    } finally { setBusy(false); }
  }
  async function restore() {
    try {
      setBusy(true);
      const result = await chooseAndRestoreBackup();
      if (!result.canceled) {
        await onReload();
        Alert.alert("تم الاستيراد", result.source === "legacy" ? `تمت إضافة ${result.imported} طالبة من نسخة الموقع القديمة.` : `تمت استعادة ${result.imported} طالبة مع بيانات التطبيق المحلي.`);
      }
    } catch (error) {
      Alert.alert("تعذر الاستيراد", error instanceof Error ? error.message : "حدث خطأ غير متوقع");
    } finally { setBusy(false); }
  }
  const items = [
    { title: `تنبيهات الحصص · ${notificationStatus}`, body: "تنبيه قبل الحصة بـ30 دقيقة مع صوت وظهور على الشاشة.", icon: "notifications-active" as IconName, action: testNotifications },
    { title: "تصدير نسخة احتياطية", body: "ملف JSON مستقل لتخزين كل بيانات الهاتف.", icon: "upload-file" as IconName, action: backup },
    { title: "استيراد نسخة احتياطية", body: "يدعم نسخة التطبيق المحلي ونسخة الطلاب البسيطة من الموقع السابق.", icon: "download" as IconName, action: restore },
  ];
  return <FlatList data={items} keyExtractor={item => item.title} contentContainerStyle={styles.listContent} ListHeaderComponent={<><SectionHeader title="الإعدادات والبيانات" subtitle="لا يتم فتح الموقع أو تضمينه داخل التطبيق." /><View style={styles.localPrivacyCard}><MaterialIcons name="phonelink-lock" size={25} color={COLORS.primaryDeep} /><View style={{ flex: 1 }}><Text style={styles.localPrivacyTitle}>بياناتك على جهازك</Text><Text style={styles.localPrivacyBody}>الطلاب والحصص والمالية محفوظة في قاعدة بيانات محلية داخل Android. استخدمي النسخ الاحتياطي عند تغيير الهاتف.</Text></View></View><SectionHeader title="النسخ والنقل" /></>} renderItem={({ item }) => <Pressable accessibilityRole="button" accessibilityLabel={item.title} disabled={busy} onPress={item.action} style={({ pressed }) => [styles.settingsRow, pressed && { opacity: 0.75 }, busy && { opacity: 0.45 }]}><View style={styles.settingsIcon}><MaterialIcons name={item.icon} size={22} color={COLORS.primaryDeep} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.rowSub}>{item.body}</Text></View><MaterialIcons name="chevron-left" size={22} color={COLORS.muted} /></Pressable>} ListFooterComponent={<View style={styles.aboutCard}><Text style={styles.aboutTitle}>NANELSH Academy Native</Text><Text style={styles.aboutText}>إصدار Android محلي أولًا. لا يعتمد على WebView ولا يفتح واجهة الموقع.</Text><Text style={styles.aboutText}>التاريخ ظاهر بالتقويم الميلادي العربي.</Text></View>} />;
}

function StudentSheet({ visible, onClose, onSaved, subscriptions }: { visible: boolean; onClose: () => void; onSaved: () => Promise<void>; subscriptions: StudentSubscription[] }) {
  const [name, setName] = useState(""); const [academy, setAcademy] = useState(""); const [track, setTrack] = useState("القسم العربي"); const [grade, setGrade] = useState(""); const [britishLevel, setBritishLevel] = useState(""); const [examBoard, setExamBoard] = useState(""); const [qualification, setQualification] = useState(""); const [subject, setSubject] = useState(""); const [phone, setPhone] = useState(""); const [total, setTotal] = useState("0"); const [saving, setSaving] = useState(false);
  async function save() { if (!name.trim()) return Alert.alert("الاسم مطلوب", "اكتبي اسم الطالبة أولًا."); try { setSaving(true); await createStudent({ name, academy, track, grade, britishLevel, examBoard, qualification, subject, phone, totalSessions: Number(total) || 0, remainingSessions: Number(total) || 0 }); await onSaved(); onClose(); } catch { Alert.alert("تعذر الحفظ", "حاولي مرة أخرى."); } finally { setSaving(false); } }
  return <Sheet visible={visible} title="إضافة طالبة" subtitle="بيانات محلية على الهاتف" onClose={onClose}><InputField label="اسم الطالبة *" value={name} onChangeText={setName} placeholder="مثال: مريم أحمد" /><InputField label="الأكاديمية" value={academy} onChangeText={setAcademy} placeholder="مثال: NANELSH Academy" /><AcademicPicker label="القسم" value={track} options={TRACKS} onChange={setTrack} />{track === "القسم البريطاني" ? <><AcademicPicker label="Year / المرحلة البريطانية" value={grade} options={BRITISH_GRADES} onChange={setGrade} /><AcademicPicker label="المستوى" value={britishLevel} options={BRITISH_LEVELS} onChange={setBritishLevel} /><AcademicPicker label="Exam Board" value={examBoard} options={EXAM_BOARDS} onChange={setExamBoard} /><AcademicPicker label="Qualification" value={qualification} options={BRITISH_QUALIFICATIONS} onChange={setQualification} /></> : <AcademicPicker label="الصف" value={grade} options={GRADES} onChange={setGrade} />}<AcademicPicker label="المادة" value={subject} options={SUBJECTS} onChange={setSubject} /><InputField label="رقم الهاتف" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="01..." /><InputField label="عدد حصص الاشتراك" value={total} onChangeText={setTotal} keyboardType="numeric" /><AppButton title={saving ? "جارٍ الحفظ..." : "حفظ الطالبة"} icon="check" onPress={save} disabled={saving} /></Sheet>;
}

function GroupSheet({ visible, onClose, onSaved }: { visible: boolean; onClose: () => void; onSaved: () => Promise<void> }) {
  const [name, setName] = useState(""); const [academy, setAcademy] = useState(""); const [track, setTrack] = useState("القسم العربي"); const [grade, setGrade] = useState(""); const [britishLevel, setBritishLevel] = useState(""); const [examBoard, setExamBoard] = useState(""); const [qualification, setQualification] = useState(""); const [subject, setSubject] = useState(""); const [capacity, setCapacity] = useState("12"); const [total, setTotal] = useState("0"); const [members, setMembers] = useState(""); const [saving, setSaving] = useState(false);
  async function save() { if (!name.trim()) return Alert.alert("اسم المجموعة مطلوب", "اكتبي اسم المجموعة أولًا."); const memberCount = members.split(",").map(member => member.trim()).filter(Boolean).length; const numericCapacity = Math.max(1, Number(capacity) || 1); if (numericCapacity < memberCount) return Alert.alert("السعة غير كافية", `يوجد ${memberCount} أعضاء مسجلين. ارفعي السعة أولًا.`); try { setSaving(true); await createGroup({ name, academy, track, grade, britishLevel, examBoard, qualification, subject, capacity: numericCapacity, totalSessions: Number(total) || 0, remainingSessions: Number(total) || 0, memberNames: members }); await onSaved(); onClose(); } catch { Alert.alert("تعذر الحفظ", "حاولي مرة أخرى."); } finally { setSaving(false); } }
  return <Sheet visible={visible} title="إنشاء مجموعة" subtitle="اشتراك وحصص جماعية موحّدة" onClose={onClose}><InputField label="اسم المجموعة *" value={name} onChangeText={setName} placeholder="مثال: مجموعة الصف السابع" /><InputField label="الأكاديمية" value={academy} onChangeText={setAcademy} /><AcademicPicker label="القسم" value={track} options={TRACKS} onChange={setTrack} />{track === "القسم البريطاني" ? <><AcademicPicker label="Year / المرحلة البريطانية" value={grade} options={BRITISH_GRADES} onChange={setGrade} /><AcademicPicker label="المستوى" value={britishLevel} options={BRITISH_LEVELS} onChange={setBritishLevel} /><AcademicPicker label="Exam Board" value={examBoard} options={EXAM_BOARDS} onChange={setExamBoard} /><AcademicPicker label="Qualification" value={qualification} options={BRITISH_QUALIFICATIONS} onChange={setQualification} /></> : <AcademicPicker label="الصف" value={grade} options={GRADES} onChange={setGrade} />}<AcademicPicker label="المادة" value={subject} options={SUBJECTS} onChange={setSubject} /><InputField label="السعة" value={capacity} onChangeText={setCapacity} keyboardType="numeric" /><InputField label="إجمالي الحصص" value={total} onChangeText={setTotal} keyboardType="numeric" /><InputField label="الأعضاء (اختياري)" value={members} onChangeText={setMembers} placeholder="أسماء مفصولة بفاصلة" /><AppButton title={saving ? "جارٍ الحفظ..." : "حفظ المجموعة"} icon="check" onPress={save} disabled={saving} /></Sheet>;
}

function GroupDetailSheet({ group, students, onClose, onSaved }: { group: TutoringGroup | null; students: Student[]; onClose: () => void; onSaved: () => Promise<void> }) {
  const [name, setName] = useState("");
  const [academy, setAcademy] = useState("");
  const [grade, setGrade] = useState("");
  const [britishLevel, setBritishLevel] = useState(""); const [examBoard, setExamBoard] = useState(""); const [qualification, setQualification] = useState("");
  const [track, setTrack] = useState("القسم العربي");
  const [subject, setSubject] = useState("");
  const [capacity, setCapacity] = useState("12");
  const [total, setTotal] = useState("0");
  const [remaining, setRemaining] = useState("0");
  const [members, setMembers] = useState("");
  const [selectedMemberIds, setSelectedMemberIds] = useState<number[]>([]);
  const [loadingMembers, setLoadingMembers] = useState(false);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    let active = true;
    async function load() {
      if (!group) return;
      setName(group.name); setAcademy(group.academy || ""); setTrack(group.track || "القسم العربي"); setGrade(group.grade || ""); setBritishLevel(group.britishLevel || ""); setExamBoard(group.examBoard || ""); setQualification(group.qualification || ""); setSubject(group.subject || ""); setCapacity(String(group.capacity));
      setTotal(String(group.totalSessions)); setRemaining(String(group.remainingSessions)); setMembers(group.memberNames || ""); setNotes(group.notes || "");
      setLoadingMembers(true);
      try {
        const rows = await listGroupMembers(group.id);
        if (active) {
          setSelectedMemberIds(rows.map(row => row.studentId));
          setMembers(rows.map(row => row.studentName).join(", ") || group.memberNames || "");
        }
      } finally { if (active) setLoadingMembers(false); }
    }
    void load();
    return () => { active = false; };
  }, [group?.id]);
  const memberCount = selectedMemberIds.length;
  const eligibleStudents = students.filter(student => student.active && (!group?.track || !student.track || student.track === group.track) && (!group?.grade || !student.grade || student.grade === group.grade) && (!group?.subject || !student.subject || student.subject === group.subject));
  const toggleMember = (studentId: number) => setSelectedMemberIds(current => current.includes(studentId) ? current.filter(id => id !== studentId) : [...current, studentId]);
  async function save() {
    if (!group || !name.trim()) return Alert.alert("اسم المجموعة مطلوب", "اكتبي اسم المجموعة أولًا.");
    const numericCapacity = Math.max(1, Number(capacity) || 1);
    if (numericCapacity < memberCount) return Alert.alert("السعة غير كافية", `يوجد ${memberCount} أعضاء مسجلين. ارفعي السعة أو قللي الأعضاء أولًا.`);
    try {
      setSaving(true);
      await updateGroup(group.id, { name, academy, track, grade, britishLevel, examBoard, qualification, subject, capacity: numericCapacity, totalSessions: Math.max(0, Number(total) || 0), remainingSessions: Math.max(0, Number(remaining) || 0), memberNames: members, notes });
      await syncGroupMembers(group.id, selectedMemberIds);
      await onSaved();
      Alert.alert("تم الحفظ", "تم تحديث بيانات المجموعة والاشتراك محليًا.");
    } catch (error) { Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(group)} title={group ? `مجموعة ${group.name}` : "المجموعة"} subtitle="تعديل الأعضاء والسعة والاشتراك" onClose={onClose}>
    <View style={styles.groupCapacityCallout}><MaterialIcons name="groups" size={22} color={COLORS.primaryDeep} /><View style={{ flex: 1 }}><Text style={styles.groupCapacityTitle}>{memberCount}/{capacity || "0"} أعضاء</Text><Text style={styles.groupCapacityBody}>لا يمكن حفظ سعة أقل من عدد الأعضاء.</Text></View></View>
    <InputField label="اسم المجموعة" value={name} onChangeText={setName} />
    <InputField label="الأكاديمية" value={academy} onChangeText={setAcademy} />
    <AcademicPicker label="القسم" value={track} options={TRACKS} onChange={setTrack} />
    {track === "القسم البريطاني" ? <><AcademicPicker label="Year / المرحلة البريطانية" value={grade} options={BRITISH_GRADES} onChange={setGrade} /><AcademicPicker label="المستوى" value={britishLevel} options={BRITISH_LEVELS} onChange={setBritishLevel} /><AcademicPicker label="Exam Board" value={examBoard} options={EXAM_BOARDS} onChange={setExamBoard} /><AcademicPicker label="Qualification" value={qualification} options={BRITISH_QUALIFICATIONS} onChange={setQualification} /></> : <AcademicPicker label="الصف" value={grade} options={GRADES} onChange={setGrade} />}
    <AcademicPicker label="المادة" value={subject} options={SUBJECTS} onChange={setSubject} />
    <View style={styles.inlineFields}><View style={{ flex: 1 }}><InputField label="السعة" value={capacity} onChangeText={setCapacity} keyboardType="numeric" /></View><View style={{ flex: 1 }}><InputField label="إجمالي الحصص" value={total} onChangeText={setTotal} keyboardType="numeric" /></View></View>
    <InputField label="الحصص المتبقية" value={remaining} onChangeText={setRemaining} keyboardType="numeric" />
    <Text style={styles.fieldLabel}>طالبات المجموعة ({memberCount}/{capacity || "0"})</Text>
    {loadingMembers ? <ActivityIndicator size="small" color={COLORS.primary} /> : eligibleStudents.length ? <View style={styles.memberPickerList}>{eligibleStudents.map(student => { const selected = selectedMemberIds.includes(student.id); return <Pressable key={student.id} onPress={() => toggleMember(student.id)} style={[styles.memberPickerRow, selected && styles.memberPickerRowSelected]}><View style={[styles.memberPickerCheck, selected && styles.memberPickerCheckSelected]}><MaterialIcons name={selected ? "check" : "person-outline"} size={17} color={selected ? "#fff" : COLORS.primaryDeep} /></View><View style={{flex:1}}><Text style={styles.rowTitle}>{student.name}</Text><Text style={styles.rowSub}>{[student.grade, student.subject].filter(Boolean).join(" · ") || "طالبة"}</Text></View></Pressable>; })}</View> : <Text style={styles.inlineHint}>لا توجد طالبات مطابقة حاليًا. أضيفي الطالبات أولًا ثم ارجعي للمجموعة.</Text>}
    <Text style={styles.inlineHint}>يمكنك الاحتفاظ بالبيانات القديمة؛ سيحفظ النظام الآن عضوية كل طالبة كبيانات مستقلة مرتبطة بالمجموعة.</Text>
    <InputField label="ملاحظات المجموعة" value={notes} onChangeText={setNotes} multiline />
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ التعديلات"} icon="save" onPress={save} disabled={saving} />
  </Sheet>;
}

function SessionSheet({ visible, onClose, onSaved, students, groups }: { visible: boolean; onClose: () => void; onSaved: () => Promise<void>; students: Student[]; groups: TutoringGroup[] }) {
  const [kind, setKind] = useState<"student" | "group">("student");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [date, setDate] = useState(todayDate());
  const [time, setTime] = useState("16:00");
  const [duration, setDuration] = useState("60");
  const [saving, setSaving] = useState(false);
  const sources = kind === "student" ? students.filter(student => student.active) : groups;
  useEffect(() => { if (sources.length && !sources.some(source => source.id === selectedId)) setSelectedId(sources[0].id); }, [kind, sources, selectedId]);
  useEffect(() => { if (visible) setDate(todayDate()); }, [visible]);
  async function save() {
    const source = sources.find(entry => entry.id === selectedId);
    if (!source) return Alert.alert("اختاري الاسم", kind === "student" ? "اختاري طالبة للحصة." : "اختاري مجموعة للحصة.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return Alert.alert("التاريخ غير صحيح", "اكتبي التاريخ بصيغة 2026-10-01.");
    try {
      setSaving(true);
      if (kind === "student") {
        const student = source as Student;
        await createSession({ studentId: student.id, studentName: student.name, academy: student.academy, subject: student.subject, sessionDate: date, startTime: time, durationMinutes: Number(duration) || 60 });
      } else {
        const group = source as TutoringGroup;
        await createSession({ groupId: group.id, groupName: group.name, academy: group.academy, subject: group.subject, sessionDate: date, startTime: time, durationMinutes: Number(duration) || 60 });
      }
      await onSaved();
      onClose();
    } catch { Alert.alert("تعذر الجدولة", "تحققي من البيانات ثم حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={visible} title="جدولة حصة" subtitle="اختاري أي تاريخ ميلادي للحصة" onClose={onClose}>
    <Text style={styles.fieldLabel}>نوع الحصة</Text><View style={styles.choiceRow}><Choice label="فردية" selected={kind === "student"} onPress={() => setKind("student")} /><Choice label="مجموعة" selected={kind === "group"} onPress={() => setKind("group")} /></View>
    <Text style={[styles.fieldLabel, { marginTop: 12 }]}>{kind === "student" ? "الطالبة" : "المجموعة"}</Text><View style={styles.choiceWrap}>{sources.map(source => <Choice key={source.id} label={source.name} selected={selectedId === source.id} onPress={() => setSelectedId(source.id)} />)}</View>
    {sources.length === 0 ? <Text style={styles.inlineHint}>{kind === "student" ? "أضيفي طالبة أولًا." : "أنشئي مجموعة أولًا."}</Text> : null}
    <InputField label="تاريخ الحصة (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="2026-10-01" />
    <InputField label="وقت البداية" value={time} onChangeText={setTime} placeholder="16:00" />
    <InputField label="مدة الحصة بالدقائق" value={duration} onChangeText={setDuration} keyboardType="numeric" />
    <AppButton title={saving ? "جارٍ الجدولة..." : "حفظ الحصة"} icon="event-available" onPress={save} disabled={saving || sources.length === 0} />
  </Sheet>;
}

function SessionEditSheet({ session, onClose, onSaved }: { session: LessonSession | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const [date, setDate] = useState(todayDate());
  const [time, setTime] = useState("16:00");
  const [duration, setDuration] = useState("60");
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (session) { setDate(session.sessionDate); setTime(session.startTime); setDuration(String(session.durationMinutes)); } }, [session?.id]);
  async function save() {
    if (!session) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return Alert.alert("التاريخ غير صحيح", "اكتبي التاريخ بصيغة 2026-10-01.");
    try {
      setSaving(true);
      await updateScheduledSession({ id: session.id, sessionDate: date, startTime: time, durationMinutes: Number(duration) || 60 });
      await onSaved();
      onClose();
      Alert.alert("تم التعديل", "تم تحديث موعد الحصة محليًا.");
    } catch (error) { Alert.alert("تعذر التعديل", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(session) && session?.status !== "completed"} title="تعديل موعد الحصة" subtitle={session ? sessionLabel(session) : undefined} onClose={onClose}>
    <InputField label="تاريخ الحصة (YYYY-MM-DD)" value={date} onChangeText={setDate} />
    <InputField label="وقت البداية" value={time} onChangeText={setTime} />
    <InputField label="مدة الحصة بالدقائق" value={duration} onChangeText={setDuration} keyboardType="numeric" />
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ الموعد"} icon="save" onPress={save} disabled={saving} />
  </Sheet>;
}

function CompletedSessionEditSheet({ session, onClose, onSaved, onShare }: { session: LessonSession | null; onClose: () => void; onSaved: () => Promise<void>; onShare: (session: LessonSession) => Promise<void> }) {
  const [attendance, setAttendance] = useState<"حاضر" | "غائب" | "متأخر">("حاضر");
  const [homework, setHomework] = useState("");
  const [previous, setPrevious] = useState<0 | 1 | null>(null);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (!session) return;
    setAttendance(session.attendance || "حاضر");
    setHomework(session.homework || "");
    setPrevious(session.previousHomeworkDone === 1 ? 1 : session.previousHomeworkDone === 0 ? 0 : null);
    setNotes(session.notes || "");
  }, [session?.id]);
  async function save() {
    if (!session) return;
    try {
      setSaving(true);
      await updateCompletedSession({ id: session.id, attendance, homework, previousHomeworkDone: previous, notes });
      await onSaved();
      Alert.alert("تم حفظ التقرير", "تم تعديل بيانات الحصة دون خصم اشتراك إضافي.");
    } catch (error) { Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(session) && session?.status === "completed"} title="تعديل تقرير الحصة" subtitle={session ? `${sessionLabel(session)} · ${formatDate(session.sessionDate)}` : undefined} onClose={onClose}>
    <Text style={styles.fieldLabel}>الحضور</Text><View style={styles.choiceRow}><Choice label="حاضر" selected={attendance === "حاضر"} onPress={() => setAttendance("حاضر")} /><Choice label="غائب" selected={attendance === "غائب"} onPress={() => setAttendance("غائب")} tone="danger" /><Choice label="متأخر" selected={attendance === "متأخر"} onPress={() => setAttendance("متأخر")} tone="warning" /></View>
    <Text style={[styles.fieldLabel, { marginTop: 12 }]}>الواجب السابق</Text><View style={styles.choiceRow}><Choice label="تم" selected={previous === 1} onPress={() => setPrevious(1)} /><Choice label="لم يتم" selected={previous === 0} onPress={() => setPrevious(0)} tone="danger" /></View>
    <InputField label="الواجب الجديد" value={homework} onChangeText={setHomework} multiline />
    <InputField label="الملاحظات" value={notes} onChangeText={setNotes} multiline />
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ التعديلات"} icon="save" onPress={save} disabled={saving} />
    {session ? <AppButton title="إرسال التقرير" icon="share" onPress={() => void onShare({ ...session, attendance, homework, previousHomeworkDone: previous, notes })} tone="soft" /> : null}
  </Sheet>;
}

function CompletionSheet({ session, onClose, onSaved }: { session: LessonSession | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const [attendance, setAttendance] = useState<"حاضر" | "غائب" | "متأخر">("حاضر"); const [homework, setHomework] = useState(""); const [previous, setPrevious] = useState<0 | 1 | null>(null); const [notes, setNotes] = useState(""); const [saving, setSaving] = useState(false);
  useEffect(() => { setAttendance("حاضر"); setHomework(""); setPrevious(null); setNotes(""); }, [session?.id]);
  async function save() { if (!session) return; try { setSaving(true); await completeSession({ id: session.id, attendance, homework, previousHomeworkDone: previous, notes }); await onSaved(); onClose(); } catch (error) { Alert.alert("تعذر إنهاء الحصة", error instanceof Error ? error.message : "حاولي مرة أخرى."); } finally { setSaving(false); } }
  return <Sheet visible={Boolean(session)} title="إنهاء الحصة" subtitle={session ? `${sessionLabel(session)} · ${session.startTime}` : undefined} onClose={onClose}><Text style={styles.fieldLabel}>الحضور</Text><View style={styles.choiceRow}><Choice label="حاضر" selected={attendance === "حاضر"} onPress={() => setAttendance("حاضر")} /><Choice label="غائب" selected={attendance === "غائب"} onPress={() => setAttendance("غائب")} tone="danger" /><Choice label="متأخر" selected={attendance === "متأخر"} onPress={() => setAttendance("متأخر")} tone="warning" /></View><Text style={[styles.fieldLabel, { marginTop: 12 }]}>الواجب السابق</Text><View style={styles.choiceRow}><Choice label="تم" selected={previous === 1} onPress={() => setPrevious(1)} /><Choice label="لم يتم" selected={previous === 0} onPress={() => setPrevious(0)} tone="danger" /></View><InputField label="واجب جديد" value={homework} onChangeText={setHomework} placeholder="اكتبي الواجب المطلوب" multiline /><InputField label="ملاحظات" value={notes} onChangeText={setNotes} placeholder="ملخص الحصة أو ملاحظة لولي الأمر" multiline /><AppButton title={saving ? "جارٍ الحفظ..." : "إنهاء وحفظ التقرير"} icon="check-circle" onPress={save} disabled={saving} /></Sheet>;
}

function PaymentSheet({ student, visible, onClose, onSaved }: { student: Student | null; visible: boolean; onClose: () => void; onSaved: () => Promise<void> }) {
  const [amount, setAmount] = useState(""); const [date, setDate] = useState(todayDate()); const [method, setMethod] = useState("تحويل"); const [reference, setReference] = useState(""); const [notes, setNotes] = useState(""); const [saving, setSaving] = useState(false);
  useEffect(() => { if (visible) { setAmount(""); setDate(todayDate()); setMethod("تحويل"); setReference(""); setNotes(""); } }, [visible, student?.id]);
  async function save() { if (!student) return; const numeric=Number(amount); if(!numeric || numeric<=0) return Alert.alert("المبلغ غير صحيح","اكتبي مبلغًا أكبر من صفر."); try { setSaving(true); await createStudentPayment({studentId:student.id,studentName:student.name,amount:numeric,paymentDate:date,method,reference,notes}); await onSaved(); Alert.alert("تم تسجيل الدفعة",`تم تحديث حساب ${student.name} تلقائيًا.`); onClose(); } catch(e) { Alert.alert("تعذر تسجيل الدفعة",e instanceof Error?e.message:"حاولي مرة أخرى."); } finally { setSaving(false); } }
  return <Sheet visible={visible} title="تسجيل دفعة" subtitle={student ? `الحساب الموحد · ${student.name}` : undefined} onClose={onClose}>
    <InputField label="المبلغ بالجنيه *" value={amount} onChangeText={setAmount} keyboardType="numeric" placeholder="0" />
    <InputField label="تاريخ الدفع" value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" />
    <Text style={styles.fieldLabel}>طريقة الدفع</Text><View style={styles.choiceWrap}>{["نقدي","تحويل","فوري","بطاقة"].map(item=><Choice key={item} label={item} selected={method===item} onPress={()=>setMethod(item)} />)}</View>
    <InputField label="رقم المرجع / الإيصال" value={reference} onChangeText={setReference} placeholder="اختياري" />
    <InputField label="ملاحظات" value={notes} onChangeText={setNotes} placeholder="مثال: دفعة شهر أكتوبر" multiline />
    <AppButton title={saving?"جارٍ التسجيل...":"تسجيل الدفعة وتحديث الحساب"} icon="payments" onPress={save} disabled={saving} />
  </Sheet>;
}

function FinanceSheet({ visible, onClose, onSaved }: { visible: boolean; onClose: () => void; onSaved: () => Promise<void> }) {
  const [type, setType] = useState<TransactionType>("income"); const [amount, setAmount] = useState(""); const [description, setDescription] = useState(""); const [saving, setSaving] = useState(false);
  const options: Array<{ type: TransactionType; label: string; tone: "primary" | "warning" | "danger" }> = [{ type: "income", label: "إيراد", tone: "primary" }, { type: "expense", label: "مصروف", tone: "warning" }, { type: "refund", label: "استرداد", tone: "danger" }, { type: "discount", label: "خصم", tone: "warning" }];
  async function save() { const numeric = Number(amount); if (!numeric || numeric <= 0) return Alert.alert("المبلغ غير صحيح", "اكتبي مبلغًا أكبر من صفر."); try { setSaving(true); await createTransaction({ type, amount: numeric, description }); await onSaved(); onClose(); } catch { Alert.alert("تعذر الحفظ", "حاولي مرة أخرى."); } finally { setSaving(false); } }
  return <Sheet visible={visible} title="حركة مالية" subtitle="تُحسب تلقائيًا في صافي الحساب" onClose={onClose}><Text style={styles.fieldLabel}>نوع الحركة</Text><View style={styles.choiceWrap}>{options.map(option => <Choice key={option.type} label={option.label} selected={type === option.type} onPress={() => setType(option.type)} tone={option.tone} />)}</View><InputField label="المبلغ بالجنيه" value={amount} onChangeText={setAmount} keyboardType="numeric" placeholder="0" /><InputField label="الوصف" value={description} onChangeText={setDescription} placeholder="مثال: تجديد اشتراك سبتمبر" /><AppButton title={saving ? "جارٍ الحفظ..." : "حفظ الحركة"} icon="check" onPress={save} disabled={saving} /></Sheet>;
}

function TimetableSheet({ visible, onClose, onSaved, students, groups }: { visible: boolean; onClose: () => void; onSaved: () => Promise<void>; students: Student[]; groups: TutoringGroup[] }) {
  const [kind, setKind] = useState<"student" | "group">("student");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [weeklyTimes, setWeeklyTimes] = useState<Record<string, string>>({});
  const [duration, setDuration] = useState(60);
  const [timePickerDay, setTimePickerDay] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const sources = kind === "student" ? students.filter(student => student.active) : groups;
  const selectedDays = DAYS.filter(day => Boolean(weeklyTimes[day]));

  useEffect(() => { if (sources.length && !sources.some(source => source.id === selectedId)) setSelectedId(sources[0].id); }, [kind, sources, selectedId]);
  useEffect(() => { if (visible) { setWeeklyTimes({}); setDuration(60); setTimePickerDay(null); } }, [visible]);

  function toggleDay(day: string) {
    setWeeklyTimes(current => {
      if (current[day]) {
        const { [day]: _removed, ...remaining } = current;
        return remaining;
      }
      return { ...current, [day]: DEFAULT_WEEKLY_TIME };
    });
  }

  async function save() {
    const source = sources.find(entry => entry.id === selectedId);
    if (!source) return Alert.alert("اختاري الاسم", "اختاري طالبة أو مجموعة.");
    if (!selectedDays.length) return Alert.alert("اختاري الأيام", "اختاري يومًا واحدًا على الأقل للجدول المتكرر.");
    try {
      setSaving(true);
      const inserted = await createRecurringTimetableSlots(selectedDays.map(day => ({
        studentId: kind === "student" ? source.id : null,
        groupId: kind === "group" ? source.id : null,
        title: source.name,
        dayOfWeek: day,
        startTime: weeklyTimes[day],
        durationMinutes: duration,
        subject: kind === "student" ? (source as Student).subject : (source as TutoringGroup).subject,
      })));
      await onSaved();
      onClose();
      Alert.alert("تم حفظ الجدول", `تمت إضافة ${inserted} مواعيد أسبوعية متكررة.`);
    } catch (error) {
      Alert.alert("تعذر حفظ الجدول", error instanceof Error ? error.message : "حاولي مرة أخرى.");
    } finally { setSaving(false); }
  }

  return <Sheet visible={visible} title="جدول أسبوعي متكرر" subtitle="اختاري عدة أيام وحددي وقتًا خاصًا لكل يوم" onClose={() => { setTimePickerDay(null); onClose(); }}>
    <Text style={styles.fieldLabel}>نوع الجدول</Text><View style={styles.choiceRow}><Choice label="طالبة" selected={kind === "student"} onPress={() => setKind("student")} /><Choice label="مجموعة" selected={kind === "group"} onPress={() => setKind("group")} /></View>
    <Text style={[styles.fieldLabel, { marginTop: 12 }]}>{kind === "student" ? "الطالبة" : "المجموعة"}</Text><View style={styles.choiceWrap}>{sources.map(source => <Choice key={source.id} label={source.name} selected={selectedId === source.id} onPress={() => setSelectedId(source.id)} />)}</View>
    {sources.length === 0 ? <Text style={styles.inlineHint}>{kind === "student" ? "أضيفي طالبة نشطة أولًا." : "أنشئي مجموعة أولًا."}</Text> : null}
    <Text style={[styles.fieldLabel, { marginTop: 12 }]}>الأيام المتكررة</Text>
    <View style={styles.daysGrid}>{DAYS.map(day => {
      const selected = Boolean(weeklyTimes[day]);
      return <Pressable key={day} accessibilityRole="checkbox" accessibilityLabel={`تكرار يوم ${day}`} accessibilityState={{ checked: selected }} onPress={() => toggleDay(day)} style={({ pressed }) => [styles.dayPicker, selected && styles.dayPickerSelected, pressed && { opacity: 0.72 }]}><MaterialIcons name={selected ? "check-circle" : "radio-button-unchecked"} size={18} color={selected ? COLORS.primaryDeep : COLORS.muted} /><Text style={[styles.dayPickerText, selected && styles.dayPickerTextSelected]}>{day}</Text></Pressable>;
    })}</View>
    {selectedDays.length ? <View style={styles.timeSelectionCard}><View style={styles.timeSelectionHeader}><Text style={styles.timeSelectionTitle}>وقت البداية لكل يوم</Text><Text style={styles.timeSelectionHint}>اضغطي الساعة لفتح اختيار الوقت</Text></View>{selectedDays.map(day => <View key={day} style={styles.dayTimeRow}><Text style={styles.dayTimeLabel}>{day}</Text><Pressable accessibilityRole="button" accessibilityLabel={`تعديل وقت ${day}`} onPress={() => setTimePickerDay(day)} style={({ pressed }) => [styles.timePickerButton, pressed && { opacity: 0.75 }]}><MaterialIcons name="schedule" size={18} color={COLORS.primaryDeep} /><Text style={styles.timePickerButtonText}>{formatTime(weeklyTimes[day])}</Text><MaterialIcons name="expand-more" size={18} color={COLORS.muted} /></Pressable></View>)}</View> : <Text style={styles.inlineHint}>اختاري الأيام أولًا، ثم حددي ساعة كل يوم من زر الساعة.</Text>}
    {timePickerDay ? <DateTimePicker value={timeToDate(weeklyTimes[timePickerDay] ?? DEFAULT_WEEKLY_TIME)} mode="time" display={Platform.OS === "ios" ? "spinner" : "clock"} is24Hour={false} onChange={(event, date) => { if (Platform.OS === "android") setTimePickerDay(null); if (event.type === "set" && date) setWeeklyTimes(current => ({ ...current, [timePickerDay]: dateToTime(date) })); }} /> : null}
    <Text style={[styles.fieldLabel, { marginTop: 4 }]}>مدة الحصة</Text><View style={styles.choiceWrap}>{[30, 45, 60, 90, 120].map(minutes => <Choice key={minutes} label={`${minutes} دقيقة`} selected={duration === minutes} onPress={() => setDuration(minutes)} />)}</View>
    <AppButton title={saving ? "جارٍ حفظ الجدول..." : selectedDays.length ? `حفظ ${selectedDays.length} مواعيد متكررة` : "حفظ المواعيد المتكررة"} icon="repeat" onPress={save} disabled={saving || sources.length === 0} />
  </Sheet>;
}

function TimetableEditSheet({ slot, onClose, onSaved }: { slot: TimetableSlot | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const [day, setDay] = useState(DAYS[0]);
  const [time, setTime] = useState("16:00");
  const [duration, setDuration] = useState(60);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (slot) { setDay(slot.dayOfWeek); setTime(slot.startTime); setDuration(slot.durationMinutes); setShowTimePicker(false); } }, [slot?.id]);
  async function save() {
    if (!slot) return;
    try {
      setSaving(true);
      await updateTimetableSlot({ id: slot.id, dayOfWeek: day, startTime: time, durationMinutes: duration });
      await onSaved();
      onClose();
      Alert.alert("تم التعديل", "تم تحديث الموعد الأسبوعي.");
    } catch (error) { Alert.alert("تعذر التعديل", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(slot)} title="تعديل الموعد الأسبوعي" subtitle={slot?.title} onClose={onClose}>
    <Text style={styles.fieldLabel}>اليوم</Text><View style={styles.choiceWrap}>{DAYS.map(item => <Choice key={item} label={item} selected={day === item} onPress={() => setDay(item)} />)}</View>
    <Text style={[styles.fieldLabel, { marginTop: 8 }]}>وقت البداية</Text><Pressable accessibilityRole="button" accessibilityLabel="اختيار وقت البداية" onPress={() => setShowTimePicker(true)} style={({ pressed }) => [styles.editTimePickerButton, pressed && { opacity: 0.75 }]}><MaterialIcons name="schedule" size={20} color={COLORS.primaryDeep} /><Text style={styles.editTimePickerText}>{formatTime(time)}</Text><Text style={styles.editTimePickerHint}>تغيير</Text></Pressable>
    {showTimePicker ? <DateTimePicker value={timeToDate(time)} mode="time" display={Platform.OS === "ios" ? "spinner" : "clock"} is24Hour={false} onChange={(event, date) => { if (Platform.OS === "android") setShowTimePicker(false); if (event.type === "set" && date) setTime(dateToTime(date)); }} /> : null}
    <Text style={[styles.fieldLabel, { marginTop: 8 }]}>مدة الحصة</Text><View style={styles.choiceWrap}>{[30, 45, 60, 90, 120].map(minutes => <Choice key={minutes} label={`${minutes} دقيقة`} selected={duration === minutes} onPress={() => setDuration(minutes)} />)}</View>
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ التعديلات"} icon="save" onPress={save} disabled={saving} />
  </Sheet>;
}

function NotificationCenter({ snapshot, visible, onClose, onOpenTab }: { snapshot: DashboardSnapshot; visible: boolean; onClose: () => void; onOpenTab: (tab: Tab) => void }) {
  const today = todayDate();
  const upcomingSessions = snapshot.sessions.filter(s => s.status === "scheduled" && s.sessionDate >= today).sort((a,b) => `${a.sessionDate} ${a.startTime}`.localeCompare(`${b.sessionDate} ${b.startTime}`)).slice(0, 6);
  const upcomingExams = snapshot.exams.filter(e => e.examDate >= today).sort((a,b) => a.examDate.localeCompare(b.examDate)).slice(0, 6);
  const renewals = snapshot.subscriptions.filter(s => s.renewalDate && s.status !== "paid" && s.renewalDate >= today).sort((a,b) => String(a.renewalDate).localeCompare(String(b.renewalDate))).slice(0, 6);
  const absent = snapshot.attendanceRecords.filter(r => (r.status === "غائب" || r.status === "بعذر") && r.attendanceDate >= today).slice(0, 8);
  const items = [
    ...upcomingSessions.map(s => ({ id:`session-${s.id}`, icon:"schedule" as IconName, title:"حصة قادمة", body:`${sessionLabel(s)} · ${formatDate(s.sessionDate)} · ${formatTime(s.startTime)}`, tone:"primary", tab:"sessions" as Tab })),
    ...upcomingExams.map(e => ({ id:`exam-${e.id}`, icon:"assignment" as IconName, title:"اختبار قادم", body:`${e.title}${e.subject ? ` · ${e.subject}` : ""} · ${formatDate(e.examDate)}`, tone:"warning", tab:"exams" as Tab })),
    ...renewals.map(r => ({ id:`renew-${r.id}`, icon:"payments" as IconName, title:"موعد تجديد اشتراك", body:`${r.studentName} · ${formatDate(r.renewalDate!)}`, tone:"danger", tab:"finance" as Tab })),
    ...absent.map(a => ({ id:`attendance-${a.id}`, icon:a.status === "غائب" ? "warning" as IconName : "description" as IconName, title:a.status === "غائب" ? "غياب مسجل" : "غياب بعذر", body:`${a.studentName} · ${formatDate(a.attendanceDate)}`, tone:"danger", tab:"attendance" as Tab })),
  ];
  return <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
    <View style={styles.notificationBackdrop}>
      <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
      <View style={styles.notificationSheet}>
        <View style={styles.sheetHandle} />
        <View style={styles.notificationHeader}><View style={{flex:1}}><Text style={styles.sheetTitle}>مركز التنبيهات</Text><Text style={styles.sheetSubtitle}>تنبيهات الأكاديمية المحفوظة والمواعيد القادمة</Text></View><IconButton label="إغلاق" icon="close" onPress={onClose} /></View>
        <ScrollView contentContainerStyle={styles.notificationList}>
          {items.length ? items.map(item => <Pressable key={item.id} onPress={() => { haptic(); onClose(); onOpenTab(item.tab); }} style={({pressed}) => [styles.notificationCard, pressed && {opacity:0.75}]}>
            <View style={[styles.notificationIcon, item.tone === "danger" ? styles.notificationIconDanger : item.tone === "warning" ? styles.notificationIconWarning : styles.notificationIconPrimary]}><MaterialIcons name={item.icon} size={20} color={item.tone === "danger" ? COLORS.danger : item.tone === "warning" ? COLORS.warning : COLORS.primaryDeep} /></View>
            <View style={{flex:1}}><Text style={styles.notificationTitle}>{item.title}</Text><Text style={styles.notificationBody}>{item.body}</Text></View><MaterialIcons name="chevron-left" size={20} color={COLORS.muted} />
          </Pressable>) : <View style={styles.notificationEmpty}><MaterialIcons name="notifications-none" size={34} color={COLORS.primary} /><Text style={styles.notificationEmptyTitle}>لا توجد تنبيهات جديدة</Text><Text style={styles.notificationEmptyBody}>سيظهر هنا موعد الحصص والاختبارات والتجديدات والغياب.</Text></View>}
        </ScrollView>
      </View>
    </View>
  </Modal>;
}

function MainApp() {
  const [snapshot, setSnapshot] = useState<DashboardSnapshot | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [modal, setModal] = useState<ModalKind>(null);
  const [selectedSession, setSelectedSession] = useState<LessonSession | null>(null);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<TutoringGroup | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<TimetableSlot | null>(null);
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const reload = async () => {
    setRefreshing(true);
    try {
      const next = await getSnapshot();
      setSnapshot(next);
      void syncSessionReminders(next.sessions).catch(() => undefined);
      void syncAcademicReminders(next.exams, next.subscriptions).catch(() => undefined);
    }
    catch (error) { Alert.alert("تعذر تحميل البيانات", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setRefreshing(false); }
  };

  useEffect(() => {
    const subscription = onNotificationResponse(screen => {
      if (screen && ["home", "students", "sessions", "attendance", "groups", "british", "exams", "progress", "reports", "finance", "settings"].includes(screen)) setActiveTab(screen as Tab);
      setNotificationsOpen(false);
    });
    void (async () => { await initializeStore(); await configureNotifications(true); await reload(); })();
    return () => subscription.remove();
  }, []);

  if (!snapshot) {
    return <SafeAreaView style={styles.loadingScreen}><View style={styles.loadingMark}><Text style={styles.brandMarkText}>ن</Text></View><ActivityIndicator color={COLORS.primary} size="large" /><Text style={styles.loadingText}>يتم فتح بياناتك المحلية...</Text></SafeAreaView>;
  }

  const notificationCount = snapshot ? (snapshot.sessions.filter(s => s.status === "scheduled" && s.sessionDate >= todayDate()).length + snapshot.exams.filter(e => e.examDate >= todayDate()).length + snapshot.subscriptions.filter(s => s.renewalDate && s.status !== "paid" && s.renewalDate >= todayDate()).length + snapshot.attendanceRecords.filter(r => (r.status === "غائب" || r.status === "بعذر") && r.attendanceDate === todayDate()).length) : 0;

  const closeSessionModal = () => { setModal(null); setSelectedSession(null); };
  const deleteWithConfirm = (title: string, body: string, action: () => Promise<void>) => Alert.alert(title, body, [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => void action().then(reload).catch(error => Alert.alert("تعذر الحذف", error instanceof Error ? error.message : "حاولي مرة أخرى.")) }]);
  const shareReport = async (session: LessonSession) => {
    try { await shareSessionReport(session); }
    catch (error) { Alert.alert("تعذر إرسال التقرير", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
  };
  let content: ReactNode;
  if (activeTab === "home") content = <HomeScreen snapshot={snapshot} onOpen={setModal} onQuickComplete={session => { setSelectedSession(session); setModal("complete"); }} />;
  else if (activeTab === "students") content = <StudentsScreen students={snapshot.students} onAdd={() => setModal("student")} onOpen={student => { setSelectedStudent(student); setModal("studentDetail"); }} onDelete={student => deleteWithConfirm("حذف الطالبة", `سيتم حذف ${student.name} من هذا الجهاز فقط.`, () => deleteStudent(student.id))} />;
  else if (activeTab === "attendance") content = <AttendanceScreen students={snapshot.students} groups={snapshot.groups} sessions={snapshot.sessions} records={snapshot.attendanceRecords} onSaved={reload} />;
  else if (activeTab === "sessions") content = <SessionsScreen sessions={snapshot.sessions} timetable={snapshot.timetable} onOpen={setModal} onStart={async session => { try { await startSession(session.id); await reload(); } catch (error) { Alert.alert("تعذر بدء الحصة", error instanceof Error ? error.message : "حاولي مرة أخرى."); } }} onComplete={session => { setSelectedSession(session); setModal("complete"); }} onEdit={session => { setSelectedSession(session); setModal(session.status === "completed" ? "report" : "sessionEdit"); }} onReport={shareReport} onDelete={session => deleteWithConfirm("حذف الحصة", "سيتم حذف الحصة من السجل المحلي.", () => deleteSession(session.id))} onEditSlot={slot => { setSelectedSlot(slot); setModal("timetableEdit"); }} onToggleSlot={slot => void setTimetableSlotActive(slot.id, !slot.active).then(reload).catch(error => Alert.alert("تعذر تعديل الموعد", error instanceof Error ? error.message : "حاولي مرة أخرى."))} onDeleteSlot={slot => deleteWithConfirm("حذف الموعد الأسبوعي", `سيتم حذف موعد ${slot.title} من الجدول.`, () => deleteTimetableSlot(slot.id))} onGenerateSessions={async () => { try { const count = await generateSessionsFromTimetable(14); await reload(); Alert.alert("تم إنشاء الحصص", count ? `تم إنشاء ${count} حصة مجدولة خلال الأسبوعين القادمين.` : "لا توجد حصص جديدة؛ قد تكون الحصص موجودة بالفعل."); } catch (error) { Alert.alert("تعذر إنشاء الحصص", error instanceof Error ? error.message : "حاولي مرة أخرى."); } }} />;
  else if (activeTab === "british") content = <BritishSectionScreen students={snapshot.students} groups={snapshot.groups} onAddStudent={() => setModal("student")} onAddGroup={() => setModal("group")} onOpenStudent={student => { setSelectedStudent(student); setModal("studentDetail"); }} onOpenGroup={group => { setSelectedGroup(group); setModal("groupDetail"); }} />;
  else if (activeTab === "exams") content = <ExamsScreen exams={snapshot.exams} scores={snapshot.examScores} onAdd={() => setModal("exam")} onOpen={exam => { setSelectedExam(exam); setModal("examScores"); }} onDelete={exam => deleteWithConfirm("حذف الاختبار", `سيتم حذف ${exam.title} وجميع درجاته.`, () => deleteExam(exam.id))} />;
  else if (activeTab === "progress") content = <AcademicProgressScreen students={snapshot.students} exams={snapshot.exams} scores={snapshot.examScores} />;
  else if (activeTab === "reports") content = <AcademicReportsScreen students={snapshot.students} exams={snapshot.exams} scores={snapshot.examScores} groups={snapshot.groups} sessions={snapshot.sessions} />;
  else if (activeTab === "groups") content = <GroupsScreen groups={snapshot.groups} onAdd={() => setModal("group")} onOpen={group => { setSelectedGroup(group); setModal("groupDetail"); }} onDelete={group => deleteWithConfirm("حذف المجموعة", `سيتم حذف ${group.name} وحصصها المرتبطة محليًا.`, () => deleteGroup(group.id))} />;
  else if (activeTab === "finance") content = <FinanceScreen transactions={snapshot.transactions} subscriptions={snapshot.subscriptions} onOpen={() => setModal("finance")} onDelete={transaction => deleteWithConfirm("حذف الحركة", "سيتم حذف الحركة من الحساب المحلي.", () => deleteTransaction(transaction.id))} />;
  else content = <SettingsScreen onReload={reload} />;

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right"]}>
      <NativeHeader onReload={reload} onOpenNotifications={() => setNotificationsOpen(true)} notificationCount={notificationCount} />
      <View style={styles.screen}>
        {refreshing && <View style={styles.refreshLine} />}
        {content}
      </View>
      <View style={styles.tabBar}>
        {TABS.map(tab => {
          const selected = activeTab === tab.key;
          return <Pressable key={tab.key} accessibilityRole="tab" accessibilityState={{ selected }} accessibilityLabel={tab.title} onPress={() => { haptic(); setActiveTab(tab.key); }} style={({ pressed }) => [styles.tabItem, pressed && { opacity: 0.7 }]}><View style={[styles.tabIcon, selected && styles.tabIconSelected]}><MaterialIcons name={tab.icon} size={22} color={selected ? COLORS.primaryDeep : COLORS.muted} /></View><Text style={[styles.tabText, selected && styles.tabTextSelected]}>{tab.title}</Text></Pressable>;
        })}
      </View>
      <StudentSheet visible={modal === "student"} onClose={() => setModal(null)} onSaved={reload} subscriptions={snapshot.subscriptions} />
      <StudentDetailSheet student={modal === "studentDetail" ? selectedStudent : null} sessions={snapshot.sessions} exams={snapshot.exams} scores={snapshot.examScores} payments={snapshot.payments} subscriptions={snapshot.subscriptions} onClose={() => { setModal(null); setSelectedStudent(null); }} onSaved={reload} onAddPayment={student => { setSelectedStudent(student); setModal("payment"); }} />
      <GroupSheet visible={modal === "group"} onClose={() => setModal(null)} onSaved={reload} />
      <GroupDetailSheet group={modal === "groupDetail" ? selectedGroup : null} students={snapshot.students} onClose={() => { setModal(null); setSelectedGroup(null); }} onSaved={reload} />
      <SessionSheet visible={modal === "session"} onClose={() => setModal(null)} onSaved={reload} students={snapshot.students} groups={snapshot.groups} />
      <SessionEditSheet session={modal === "sessionEdit" ? selectedSession : null} onClose={closeSessionModal} onSaved={reload} />
      <CompletionSheet session={modal === "complete" ? selectedSession : null} onClose={closeSessionModal} onSaved={reload} />
      <CompletedSessionEditSheet session={modal === "report" ? selectedSession : null} onClose={closeSessionModal} onSaved={reload} onShare={shareReport} />
      <FinanceSheet visible={modal === "finance"} onClose={() => setModal(null)} onSaved={reload} />
      <PaymentSheet student={selectedStudent} visible={modal === "payment"} onClose={() => setModal(null)} onSaved={reload} />
      <TimetableSheet visible={modal === "timetable"} onClose={() => setModal(null)} onSaved={reload} students={snapshot.students} groups={snapshot.groups} />
      <TimetableEditSheet slot={modal === "timetableEdit" ? selectedSlot : null} onClose={() => { setModal(null); setSelectedSlot(null); }} onSaved={reload} />
      <ExamSheet visible={modal === "exam"} onClose={() => setModal(null)} onSaved={reload} groups={snapshot.groups} />
      <ExamScoresSheet exam={modal === "examScores" ? selectedExam : null} students={snapshot.students} scores={snapshot.examScores} onClose={() => { setModal(null); setSelectedExam(null); }} onSaved={reload} />
    <NotificationCenter snapshot={snapshot} visible={notificationsOpen} onClose={() => setNotificationsOpen(false)} onOpenTab={setActiveTab} />
    </SafeAreaView>
  );
}

export default function App() {
  return <SafeAreaProvider><StatusBar style="dark" /><MainApp /></SafeAreaProvider>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  screen: { flex: 1 },
  loadingScreen: { flex: 1, alignItems: "center", justifyContent: "center", gap: 16, backgroundColor: COLORS.background },
  loadingMark: { width: 72, height: 72, borderRadius: 26, backgroundColor: COLORS.lavender, alignItems: "center", justifyContent: "center" },
  loadingText: { color: COLORS.muted, fontSize: 14 },
  appHeader: { height: 76, paddingHorizontal: 18, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", backgroundColor: COLORS.surface, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  headerActions: { flexDirection: "row-reverse", alignItems: "center", gap: 2 }, notificationBadge: { position: "absolute", top: -2, right: -2, minWidth: 17, height: 17, paddingHorizontal: 4, borderRadius: 9, backgroundColor: COLORS.danger, alignItems: "center", justifyContent: "center", borderWidth: 2, borderColor: COLORS.surface }, notificationBadgeText: { color: "#fff", fontSize: 8, fontWeight: "900" },
  notificationBackdrop: { flex: 1, backgroundColor: "rgba(23,63,59,0.22)", justifyContent: "flex-end" }, notificationSheet: { maxHeight: "82%", backgroundColor: COLORS.surface, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingTop: 10, shadowColor: "#000", shadowOpacity: 0.15, shadowOffset: { width: 0, height: -5 }, shadowRadius: 18, elevation: 12 }, notificationHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 10, paddingHorizontal: 18, paddingBottom: 8 }, notificationList: { padding: 14, gap: 9 }, notificationCard: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, borderRadius: 17, padding: 12 }, notificationIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, notificationIconPrimary: { backgroundColor: COLORS.lavender }, notificationIconWarning: { backgroundColor: COLORS.warningSoft }, notificationIconDanger: { backgroundColor: COLORS.dangerSoft }, notificationTitle: { color: COLORS.ink, fontSize: 13, fontWeight: "900", textAlign: "right", writingDirection: "rtl" }, notificationBody: { color: COLORS.muted, fontSize: 11, marginTop: 3, lineHeight: 17, textAlign: "right", writingDirection: "rtl" }, notificationEmpty: { alignItems: "center", padding: 34, gap: 8 }, notificationEmptyTitle: { color: COLORS.ink, fontSize: 15, fontWeight: "900" }, notificationEmptyBody: { color: COLORS.muted, fontSize: 12, textAlign: "center", lineHeight: 19 },
  brandRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  brandLogo: { width: 34, height: 34, borderRadius: 10 }, brandMark: { width: 42, height: 42, alignItems: "center", justifyContent: "center", borderRadius: 15, backgroundColor: COLORS.primaryDeep, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.18, shadowOffset: { width: 0, height: 5 }, shadowRadius: 12, elevation: 4 },
  brandMarkText: { color: "#FFFDF8", fontSize: 24, fontWeight: "800" },
  brandName: { color: COLORS.ink, fontSize: 16, fontWeight: "800", textAlign: "right" },
  brandCaption: { color: COLORS.muted, fontSize: 11, marginTop: 2, textAlign: "right" },
  iconButton: { width: 38, height: 38, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.lavenderSoft, borderRadius: 13 },
  refreshLine: { height: 2, backgroundColor: COLORS.primary, position: "absolute", left: 0, right: 0, top: 0, zIndex: 10 },
  listContent: { padding: 16, paddingBottom: 28, gap: 12, flexGrow: 1 },
  heroCard: { overflow: "hidden", borderRadius: 26, padding: 22, backgroundColor: COLORS.primaryDeep, minHeight: 194, justifyContent: "center", marginBottom: 4 },
  heroGlowOne: { position: "absolute", width: 200, height: 200, borderRadius: 100, backgroundColor: "rgba(221,202,250,0.25)", top: -110, left: -40 },
  heroGlowTwo: { position: "absolute", width: 160, height: 160, borderRadius: 80, backgroundColor: "rgba(247,223,201,0.18)", right: -55, bottom: -75 },
  heroEyebrow: { color: "#DDE9E5", fontSize: 12, fontWeight: "700", textAlign: "right", writingDirection: "rtl" },
  heroTitle: { color: "#FFFDF8", fontSize: 25, lineHeight: 34, fontWeight: "800", marginTop: 6, textAlign: "right", writingDirection: "rtl" },
  heroBody: { color: "#E4E9E4", fontSize: 13, marginTop: 5, textAlign: "right", writingDirection: "rtl" },
  heroActions: { flexDirection: "row-reverse", gap: 8, marginTop: 18 },
  metricsGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 10, marginVertical: 10 },
  metricCard: { width: "48.5%", backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 20, padding: 14 },
  metricIcon: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center", marginBottom: 10, alignSelf: "flex-end" },
  metricValue: { color: COLORS.ink, fontSize: 21, fontWeight: "800", textAlign: "right" },
  metricLabel: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right" },
  insightCard: { flexDirection: "row-reverse", backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 20, padding: 13, gap: 10, marginBottom: 6 },
  insightItem: { flex: 1, flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  insightIcon: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  insightValue: { color: COLORS.ink, fontSize: 15, fontWeight: "800", textAlign: "right" },
  insightLabel: { color: COLORS.muted, fontSize: 10, marginTop: 2, textAlign: "right", writingDirection: "rtl" },
  insightDivider: { width: 1, backgroundColor: COLORS.border },
  sectionHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 12, marginBottom: 2 },
  sectionHeaderText: { flex: 1 }, sectionTitle: { color: COLORS.ink, fontSize: 19, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, sectionSubtitle: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right", writingDirection: "rtl" },
  button: { minHeight: 44, borderRadius: 14, paddingHorizontal: 15, paddingVertical: 10, borderWidth: 1, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7 },
  buttonCompact: { minHeight: 36, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 12 }, buttonText: { fontWeight: "800", fontSize: 14, writingDirection: "rtl" }, buttonTextCompact: { fontSize: 12 },
  emptyState: { borderWidth: 1, borderStyle: "dashed", borderColor: "#D6D0BF", borderRadius: 22, backgroundColor: COLORS.lavenderSoft, padding: 28, alignItems: "center", marginTop: 2 },
  emptyIcon: { width: 58, height: 58, borderRadius: 20, backgroundColor: COLORS.lavender, alignItems: "center", justifyContent: "center", marginBottom: 12 }, emptyTitle: { color: COLORS.ink, fontSize: 16, fontWeight: "800", textAlign: "center" }, emptyBody: { color: COLORS.muted, lineHeight: 21, fontSize: 13, marginTop: 6, textAlign: "center", writingDirection: "rtl" },
  sessionCard: { backgroundColor: COLORS.surface, borderRadius: 21, padding: 15, borderWidth: 1, borderColor: COLORS.border, overflow: "hidden" }, sessionAccent: { position: "absolute", right: 0, top: 0, bottom: 0, width: 4, backgroundColor: COLORS.primary }, sessionTop: { flexDirection: "row-reverse", gap: 12 }, sessionTime: { color: COLORS.primaryDeep, fontSize: 13, fontWeight: "800", textAlign: "right" }, sessionName: { color: COLORS.ink, fontSize: 17, fontWeight: "800", textAlign: "right", marginTop: 3 }, sessionMeta: { color: COLORS.muted, fontSize: 12, textAlign: "right", marginTop: 4, writingDirection: "rtl" }, statusBadge: { borderRadius: 10, alignSelf: "flex-start", paddingHorizontal: 9, paddingVertical: 5 }, statusText: { fontWeight: "800", fontSize: 11 }, sessionActions: { flexDirection: "row-reverse", justifyContent: "flex-start", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: "#F1ECE2", marginTop: 13, paddingTop: 12 }, completedInfo: { flexDirection: "row-reverse", gap: 9, alignItems: "center", borderTopWidth: 1, borderTopColor: "#F1ECE2", marginTop: 13, paddingTop: 12 }, attendanceBadge: { borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5 }, attendanceText: { fontSize: 11, fontWeight: "800" }, completedNotes: { color: COLORS.muted, fontSize: 12, flex: 1, textAlign: "right" },
  followUpRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 16, padding: 12, marginBottom: 8 }, avatar: { width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.lavender }, avatarText: { color: COLORS.primaryDeep, fontSize: 17, fontWeight: "800" }, rowTitle: { color: COLORS.ink, fontSize: 15, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, rowSub: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right", lineHeight: 17, writingDirection: "rtl" }, lowBadge: { backgroundColor: COLORS.warningSoft, borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5 }, lowBadgeText: { color: COLORS.warning, fontSize: 10, fontWeight: "800" }, softNotice: { backgroundColor: COLORS.successSoft, flexDirection: "row-reverse", gap: 8, alignItems: "center", justifyContent: "center", borderRadius: 14, padding: 13 }, softNoticeText: { color: COLORS.success, fontWeight: "700", fontSize: 12, writingDirection: "rtl" },
  searchBox: { flexDirection: "row-reverse", alignItems: "center", gap: 9, paddingHorizontal: 12, minHeight: 46, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 15, marginVertical: 8 },
  searchInput: { flex: 1, color: COLORS.ink, fontSize: 13, writingDirection: "rtl" },
  studentCard: { flexDirection: "row-reverse", gap: 10, alignItems: "center", backgroundColor: COLORS.surface, borderRadius: 20, padding: 13, borderWidth: 1, borderColor: COLORS.border }, studentPressTarget: { flex: 1, flexDirection: "row-reverse", gap: 10, alignItems: "center" }, progressRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, marginTop: 8 }, progressTrack: { height: 6, flex: 1, backgroundColor: "#EEE8DC", borderRadius: 6, overflow: "hidden" }, progressFill: { height: 6, backgroundColor: COLORS.primary, borderRadius: 6 }, progressText: { color: COLORS.primaryDeep, fontSize: 11, fontWeight: "800" }, remainingText: { color: COLORS.primaryDeep, fontSize: 11, fontWeight: "700", marginTop: 4, textAlign: "right", writingDirection: "rtl" },
  profileSummary: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: COLORS.lavender, borderRadius: 18, padding: 14 }, profileAvatar: { width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.primaryDeep }, profileAvatarText: { color: "#FFFDF8", fontSize: 21, fontWeight: "800" }, profileBalance: { color: COLORS.primaryDeep, fontWeight: "800", fontSize: 15, textAlign: "right" }, profileCaption: { color: "#65706A", fontSize: 11, marginTop: 3, textAlign: "right", writingDirection: "rtl" }, inlineFields: { flexDirection: "row-reverse", gap: 9 }, profileSessionRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, borderRadius: 13, padding: 10 }, profileSessionNotes: { color: COLORS.ink, fontSize: 12, marginTop: 3, textAlign: "right", writingDirection: "rtl" },
  segmented: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, backgroundColor: COLORS.lavenderSoft, borderRadius: 15, padding: 7, marginVertical: 8 }, choiceRow: { flexDirection: "row-reverse", gap: 8 }, choiceWrap: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }, choice: { minHeight: 36, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 12, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, justifyContent: "center" }, choiceText: { color: COLORS.muted, fontWeight: "700", fontSize: 12, writingDirection: "rtl" }, inlineHint: { color: COLORS.warning, backgroundColor: COLORS.warningSoft, padding: 10, borderRadius: 10, marginTop: 8, textAlign: "right", writingDirection: "rtl" },
  daysGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }, dayPicker: { width: "31%", minHeight: 42, borderRadius: 13, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 7 }, dayPickerSelected: { backgroundColor: COLORS.lavender, borderColor: COLORS.primaryDeep }, dayPickerText: { color: COLORS.muted, fontSize: 12, fontWeight: "800", writingDirection: "rtl" }, dayPickerTextSelected: { color: COLORS.primaryDeep },
  timeSelectionCard: { backgroundColor: COLORS.lavenderSoft, borderRadius: 16, borderWidth: 1, borderColor: "#E2D6C5", padding: 12, gap: 8 }, timeSelectionHeader: { marginBottom: 2 }, timeSelectionTitle: { color: COLORS.ink, fontSize: 13, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, timeSelectionHint: { color: COLORS.muted, fontSize: 10, marginTop: 3, textAlign: "right", writingDirection: "rtl" }, dayTimeRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 10, backgroundColor: COLORS.surface, borderRadius: 12, padding: 9 }, dayTimeLabel: { flex: 1, color: COLORS.ink, fontSize: 13, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, timePickerButton: { flexDirection: "row-reverse", alignItems: "center", gap: 5, minHeight: 34, borderRadius: 10, backgroundColor: COLORS.lavender, paddingHorizontal: 9 }, timePickerButtonText: { color: COLORS.primaryDeep, fontSize: 13, fontWeight: "800" },
  editTimePickerButton: { minHeight: 47, borderRadius: 13, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, paddingHorizontal: 13, flexDirection: "row-reverse", alignItems: "center", gap: 9 }, editTimePickerText: { flex: 1, color: COLORS.ink, fontSize: 15, fontWeight: "800", textAlign: "right" }, editTimePickerHint: { color: COLORS.primaryDeep, fontSize: 12, fontWeight: "800", writingDirection: "rtl" },
  slotCard: { flexDirection: "row-reverse", alignItems: "center", gap: 11, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 18, padding: 13 }, slotCardPaused: { backgroundColor: "#F5F0E7", borderColor: "#DCCFBE" }, slotIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.lavender, alignItems: "center", justifyContent: "center" }, slotActions: { flexDirection: "row-reverse", gap: 5, flexWrap: "wrap", justifyContent: "flex-end" }, pausedText: { color: COLORS.warning, fontSize: 10, fontWeight: "700", textAlign: "right", marginTop: 4, writingDirection: "rtl" },
  groupCard: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 22, padding: 14, gap: 12 }, groupTop: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, groupPressTarget: { flexDirection: "row-reverse", alignItems: "center", gap: 10, flex: 1 }, groupIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: COLORS.peach, alignItems: "center", justifyContent: "center" }, groupStats: { flexDirection: "row-reverse", justifyContent: "space-around", backgroundColor: COLORS.lavenderSoft, paddingVertical: 11, borderRadius: 14 }, groupStatValue: { color: COLORS.primaryDeep, fontSize: 16, fontWeight: "800", textAlign: "center" }, groupStatLabel: { color: COLORS.muted, fontSize: 10, marginTop: 2, textAlign: "center" }, memberStrip: { flexDirection: "row-reverse", alignItems: "center", gap: 6 }, memberText: { flex: 1, color: COLORS.muted, fontSize: 12, textAlign: "right", writingDirection: "rtl" }, groupCapacityCallout: { backgroundColor: COLORS.lavender, borderRadius: 15, padding: 12, flexDirection: "row-reverse", gap: 8, alignItems: "center" }, groupCapacityTitle: { color: COLORS.primaryDeep, fontWeight: "800", fontSize: 14, textAlign: "right" }, groupCapacityBody: { color: "#65706A", fontSize: 11, marginTop: 3, textAlign: "right", writingDirection: "rtl" }, memberPickerList: { gap: 8, marginBottom: 12 }, memberPickerRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, padding: 10, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface }, memberPickerRowSelected: { borderColor: COLORS.primary, backgroundColor: COLORS.successSoft }, memberPickerCheck: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.lavenderSoft }, memberPickerCheckSelected: { backgroundColor: COLORS.primary },
  profileAcademicCard: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, backgroundColor: COLORS.lavenderSoft, borderRadius: 16, padding: 10 },
  profileAcademicMetric: { flexGrow: 1, minWidth: "22%", backgroundColor: COLORS.surface, borderRadius: 12, padding: 9, alignItems: "center" },
  profileAcademicValue: { color: COLORS.primaryDeep, fontSize: 12, fontWeight: "900", textAlign: "center" },
  profileAcademicLabel: { color: COLORS.muted, fontSize: 9, fontWeight: "700", marginTop: 3 },
  profileExamRow: { flexDirection: "row-reverse", alignItems: "center", gap: 9, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 14, padding: 10, marginBottom: 7 },
  profileExamGrade: { width: 36, height: 36, borderRadius: 12, backgroundColor: COLORS.peach, alignItems: "center", justifyContent: "center" },
  profileExamGradeText: { color: COLORS.primaryDeep, fontWeight: "900", fontSize: 13 },
  profileExamScore: { color: COLORS.ink, fontWeight: "900", fontSize: 12 },
  progressStatus: { fontSize: 12, fontWeight: "800", paddingHorizontal: 9, paddingVertical: 6, borderRadius: 999, overflow: "hidden" },
  progressGood: { backgroundColor: COLORS.successSoft, color: COLORS.success },
  progressAlert: { backgroundColor: COLORS.dangerSoft, color: COLORS.danger },
  progressNeutral: { backgroundColor: COLORS.lavenderSoft, color: COLORS.primaryDeep },
  progressBar: { height: 8, borderRadius: 8, backgroundColor: COLORS.border, overflow: "hidden", marginTop: 10 },
  academicProgressFill: { height: 8, borderRadius: 8, backgroundColor: COLORS.primary },
  reportCard: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: COLORS.surface, borderRadius: 18, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: COLORS.border },
  reportAverage: { color: COLORS.primaryDeep, fontSize: 11, fontWeight: "800", marginTop: 5 }, reportGroupRow: { flexDirection: "row-reverse", alignItems: "center", gap: 9, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 15, padding: 9, marginTop: 8 },
  examCard: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 20, padding: 14, gap: 10 }, examTop: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, examIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: COLORS.peach, alignItems: "center", justifyContent: "center" }, examMeta: { flexDirection: "row-reverse", justifyContent: "space-between", gap: 8, backgroundColor: COLORS.lavenderSoft, borderRadius: 12, padding: 9 }, examMetaText: { color: COLORS.muted, fontSize: 10, fontWeight: "700", textAlign: "right", writingDirection: "rtl" }, examInfoCard: { backgroundColor: COLORS.lavenderSoft, borderRadius: 15, padding: 12 }, scoreRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 15, padding: 10 },
  unifiedFinanceCard: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 18, padding: 12, marginBottom: 12 }, financeSectionTitle: { fontSize: 14, fontWeight: "800", color: COLORS.ink, textAlign: "right", marginBottom: 8 }, subscriptionRow: { flexDirection: "row-reverse", alignItems: "center", borderTopWidth: 1, borderTopColor: COLORS.border, paddingVertical: 9, gap: 10 }, subscriptionBalance: { color: COLORS.danger, fontWeight: "800", fontSize: 13 },
  profileFinanceCard: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 18, padding: 12, marginBottom: 8 },
  financeNetCard: { backgroundColor: COLORS.primaryDeep, padding: 20, borderRadius: 23, marginVertical: 10 }, financeNetLabel: { color: "#DDE9E5", fontSize: 13, fontWeight: "700", textAlign: "right" }, financeNetValue: { color: "#FFFDF8", fontSize: 30, fontWeight: "800", marginTop: 5, textAlign: "right" }, financeNetFoot: { color: "#E4E9E4", fontSize: 11, marginTop: 5, textAlign: "right", writingDirection: "rtl" }, financeMetrics: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }, miniFinance: { width: "48.5%", padding: 12, borderRadius: 15 }, miniFinanceValue: { fontWeight: "800", fontSize: 14, textAlign: "right" }, miniFinanceLabel: { fontWeight: "700", fontSize: 11, marginTop: 4, textAlign: "right" }, transactionRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, borderRadius: 17, padding: 12 }, transactionIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center" }, transactionAmount: { fontSize: 13, fontWeight: "800" }, deleteText: { color: COLORS.danger, fontSize: 11, fontWeight: "800" },
  localPrivacyCard: { backgroundColor: COLORS.lavender, borderRadius: 20, padding: 15, flexDirection: "row-reverse", alignItems: "flex-start", gap: 10, marginVertical: 8 }, localPrivacyTitle: { color: COLORS.primaryDeep, fontSize: 15, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, localPrivacyBody: { color: "#65706A", fontSize: 12, lineHeight: 18, marginTop: 4, textAlign: "right", writingDirection: "rtl" }, settingsRow: { flexDirection: "row-reverse", alignItems: "center", gap: 12, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, borderRadius: 18, padding: 14, marginBottom: 9 }, settingsIcon: { width: 43, height: 43, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.lavenderSoft }, aboutCard: { borderRadius: 18, backgroundColor: COLORS.blush, padding: 15, marginTop: 10 }, aboutTitle: { color: COLORS.ink, fontSize: 14, fontWeight: "800", textAlign: "right" }, aboutText: { color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: 5, textAlign: "right", writingDirection: "rtl" },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(23,32,60,0.35)" }, sheet: { maxHeight: "93%", backgroundColor: COLORS.background, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 18, gap: 10 }, sheetScroll: { gap: 10, paddingBottom: 12 }, sheetHandle: { width: 45, height: 5, backgroundColor: "#CFC8B7", borderRadius: 6, alignSelf: "center", marginBottom: 3 }, sheetTop: { flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 2 }, sheetTitle: { color: COLORS.ink, fontSize: 20, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, sheetSubtitle: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right", writingDirection: "rtl" }, fieldWrap: { gap: 6 }, fieldLabel: { color: COLORS.ink, fontSize: 12, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, input: { minHeight: 44, borderWidth: 1, borderColor: COLORS.border, borderRadius: 13, color: COLORS.ink, backgroundColor: COLORS.surface, paddingHorizontal: 12, fontSize: 14, writingDirection: "rtl" }, inputMultiline: { minHeight: 72, paddingTop: 10, textAlignVertical: "top" },
  tabBar: { flexDirection: "row-reverse", minHeight: 71, paddingHorizontal: 4, paddingTop: 7, paddingBottom: 8, backgroundColor: "#FFFDF8", borderTopWidth: 1, borderTopColor: COLORS.border, justifyContent: "space-around" }, tabItem: { alignItems: "center", justifyContent: "center", flex: 1, minWidth: 40, gap: 3 }, tabIcon: { width: 37, height: 29, borderRadius: 11, alignItems: "center", justifyContent: "center" }, tabIconSelected: { backgroundColor: COLORS.lavender }, tabText: { color: COLORS.muted, fontSize: 8, fontWeight: "700" }, tabTextSelected: { color: COLORS.primaryDeep },
});
