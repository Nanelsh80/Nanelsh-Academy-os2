NANELSH Academy OS — Manus 2.2 Master v15
Timetable-to-Session Engine.

Based on Manus 2.2 Master v14. Adds an optional action in the weekly timetable to generate upcoming scheduled sessions for the next 14 days from active recurring timetable slots. Duplicate sessions are prevented by date/time + student/group. Generated sessions remain editable/deletable and flow through the existing session, attendance, reporting, and group workflows.

No existing data is deleted. This is an additive feature over v14.

Validation note: full TypeScript/Expo validation requires the project's Expo dependencies; the current build environment does not have them installed, so a full native compile was not claimed.
