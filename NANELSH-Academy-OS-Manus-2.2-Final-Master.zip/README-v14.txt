NANELSH Academy OS — Manus 2.2 Master v14
Group Engine: relational group membership + per-student group attendance propagation.

Based on Manus 2.2 Master v13. Preserves existing SQLite data and migrates legacy group memberNames into groupMembers.

Key v14 changes:
- Relational groupMembers table.
- Group detail member picker with student selection.
- Legacy memberNames migration.
- Group session completion creates individual attendance records for every active group member.
- Existing individual attendance editing remains independent.
