import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { Linking, Share } from "react-native";
import { exportBackup, importLegacyBackup, restoreNativeBackup } from "../data/store";
import type { LegacyBackup, LessonSession, NativeBackup, Student } from "../types";

const BACKUP_FILE = "naneice-desk-native-backup.json";

function safeParse(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("الملف المختار ليس نسخة JSON صالحة");
  }
}

function isNativeBackup(value: unknown): value is NativeBackup {
  return Boolean(
    value &&
      typeof value === "object" &&
      (value as NativeBackup).schema === "naneice-desk-native" &&
      ([1, 2, 3, 4, 5, 6, 7] as number[]).includes((value as NativeBackup).version)
  );
}

function isLegacyBackup(value: unknown): value is LegacyBackup {
  return Boolean(value && typeof value === "object" && Array.isArray((value as LegacyBackup).students));
}

export async function shareLocalBackup() {
  const backup = await exportBackup();
  const directory = FileSystem.cacheDirectory;
  if (!directory) throw new Error("لا يمكن الوصول إلى مساحة حفظ الملفات على الجهاز");
  const fileUri = `${directory}${BACKUP_FILE}`;
  await FileSystem.writeAsStringAsync(fileUri, JSON.stringify(backup, null, 2), {
    encoding: FileSystem.EncodingType.UTF8,
  });
  if (!(await Sharing.isAvailableAsync())) {
    throw new Error("المشاركة غير متاحة على هذا الجهاز");
  }
  await Sharing.shareAsync(fileUri, {
    mimeType: "application/json",
    dialogTitle: "حفظ نسخة Naneice Desk Native",
    UTI: "public.json",
  });
  return backup;
}

export async function chooseAndRestoreBackup() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ["application/json", "text/json", "text/plain"],
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (result.canceled || !result.assets[0]) return { canceled: true as const, imported: 0 };

  const raw = await FileSystem.readAsStringAsync(result.assets[0].uri, {
    encoding: FileSystem.EncodingType.UTF8,
  });
  const parsed = safeParse(raw);

  if (isNativeBackup(parsed)) {
    await restoreNativeBackup(parsed);
    return {
      canceled: false as const,
      imported: parsed.students.length,
      source: "native" as const,
    };
  }

  if (isLegacyBackup(parsed)) {
    const imported = await importLegacyBackup(parsed);
    return { canceled: false as const, imported, source: "legacy" as const };
  }

  throw new Error("الملف لا يحتوي على نسخة مدعومة من Naneice Desk");
}

function reportDate(date: string) {
  return new Intl.DateTimeFormat("ar-EG-u-ca-gregory", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${date}T12:00:00`));
}

export function buildSessionReportMessage(session: LessonSession, student?: Pick<Student, "name" | "academy" | "phone">) {
  const studentName = student?.name || session.studentName || "غير محدد";
  const academyName = session.academy || student?.academy || "Dr. Naneice Elshimy";
  return [
    "🌷 تقرير ما بعد الحصة",
    "",
    `اسم الطالب: ${studentName}`,
    `اسم الأكاديمية: ${academyName}`,
    `التاريخ: ${reportDate(session.sessionDate)}`,
    `رقم الحصة: ${session.sessionNumber ? `الحصة ${session.sessionNumber}` : "غير محدد"}`,
    `الواجب: ${session.homework?.trim() || "لا يوجد واجب محدد"}`,
    `ملاحظات: ${session.notes?.trim() || "لا توجد ملاحظات"}`,
    "",
    "مع أطيب التمنيات بالتوفيق والنجاح 💐",
  ].join("\n");
}

function normalizeEgyptianWhatsAppNumber(raw: string) {
  let digits = raw.replace(/\D/g, "");
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("0")) digits = `20${digits.slice(1)}`;
  else if (digits.startsWith("1") && digits.length === 10) digits = `20${digits}`;
  return digits.length >= 8 && digits.length <= 15 ? digits : null;
}

export async function shareSessionReport(session: LessonSession, student?: Pick<Student, "name" | "academy" | "phone">) {
  const message = buildSessionReportMessage(session, student);
  const phone = student?.phone ? normalizeEgyptianWhatsAppNumber(student.phone) : null;
  if (phone) {
    await Linking.openURL(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`);
    return "whatsapp" as const;
  }
  await Share.share({ message, title: "تقرير ما بعد الحصة" }, { dialogTitle: "إرسال تقرير الحصة" });
  return "share-sheet" as const;
}
