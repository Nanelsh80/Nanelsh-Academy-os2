## Version 2.9.0 — Exam Builder

See [PHASE-2.9.0-EXAM-BUILDER.md](./PHASE-2.9.0-EXAM-BUILDER.md) for exam creation, question snapshots, printable HTML export, answer keys, teacher-side score entry, backup schema v5, and limitations.


## NANELSH Academy OS 2.6.0

- Added month navigation and monthly cash-flow reporting for income, expenses, refunds, and discounts.
- Added daily collection and expense summaries.
- Added all-time net cash-flow summary, total outstanding student receivables, and overdue-account count.
- Added a prioritized follow-up list of students with outstanding balances, with overdue accounts shown first and direct access to each student profile.
- Transaction history is filtered to the selected month; student balances remain calculated across the full transaction history.
- Updated Android versionCode to 9.

## NANELSH Academy OS 2.5.0

- Preserved one unified financial account per student, independent of the number of subjects or groups.
- Added multiple partial payments to the same student account; the balance uses all recorded transactions rather than a truncated recent list.
- Linked student discounts to the student account and applied them to the amount due without treating them as cash expenses.
- Added refund validation so a linked refund cannot exceed the student's net recorded payments.
- Added student-account transaction history, overdue indicators, and remaining-balance calculations.
- Kept the existing native backup schema at version 3; no backup-format migration is required for this release.
- Corrected cash-flow reporting so discounts do not reduce cash-on-hand totals.


## NANELSH Academy OS 2.3.1

- Student profiles now support multiple subjects.
- Groups are created for one subject and one grade/class context.
- Group members are linked to real student records through active enrollments.
- A student may join different subject groups, but only one active group per subject.
- Individual sessions and recurring student timetable entries now require a selected subject.
- Group capacity is checked when enrolling students.
- Student and group screens show the normalized subject and enrollment data.
- Existing free-text member names remain preserved for manual review; they are not silently converted into student records.

# NANELSH Academy OS for Android

**Naneice Desk Native** is a real Android application built with React Native and Expo. It does **not** open, embed, or depend on the Naneice Desk website or a WebView.

## What works without the website

The app stores operational data in an on-device SQLite database:

- Student records and subscription balances
- Individual and group sessions
- Start/finish session workflow with attendance, homework, and notes
- Retry-safe session completion: a completed session is not deducted twice
- Groups with shared session balances
- Weekly timetable entries
- Income, expenses, refunds, discounts, student-level partial payments, and cash-flow balance
- Arabic RTL interface with Gregorian dates
- JSON backup export and local restore

## Version 2.1 — Native productivity upgrades

- **Student profile:** search by name, academy, subject, or phone; edit subscriptions, active status, contact data, notes, and inspect recent sessions.
- **Flexible scheduling:** schedule each individual or group session on any Gregorian date; edit a non-completed session’s date, time, and duration.
- **Session reports:** edit an already-completed report without an additional deduction, then share its Arabic report through the phone’s native sharing menu (including WhatsApp when installed).
- **Weekly timetable:** create, edit, pause, reactivate, and delete recurring student or group slots.
- **Groups:** edit members, capacity, shared subscription, and notes; capacity cannot be saved below the entered member count.
- **Insights:** dashboard cards now include recorded attendance rate and the local net result for the current month.

## Version 2.2 — Visual recurring timetable

- Select **multiple weekly days** in one action for a student or group.
- Give **each selected day its own start time** through the Android clock picker.
- Choose days, times, and common lesson duration from visible controls—**no manual day or time typing**.
- Saving creates all selected recurring slots together in one local database transaction, so an incomplete schedule is never partially saved.
- Existing weekly slots now use the same visual native clock selector while editing.

The app opens even when the website is unavailable. A network connection is only used by Android itself for system services; the tutoring data workflow is local.

## Version 2.3 — NANELSH Academy OS foundation

- Added a bilingual local subject catalog: Science, Biology, Chemistry, and Physics.
- Added normalized student/subject relationships so a student can study multiple subjects.
- Added group enrollment history with a database constraint allowing only one active group per student per subject.
- Added per-student attendance records for group sessions.
- Upgraded native backups to schema version 2 and made exports read every row from every backed-up table; dashboard display limits no longer truncate backups.
- Kept version 1 native backup restore compatibility.
- Existing free-text group member names remain untouched and are not auto-matched to student records without review.

This is a data-layer foundation. The multi-subject and structured group-enrollment screens, resource library, exam builder, and gradebook are planned follow-up work and are not represented as completed in this release.

## Moving from the existing website

1. From the existing Naneice Desk site, create its JSON backup using **نسخ احتياطي للبيانات**.
2. Install the Native APK.
3. Open **الإعدادات والبيانات** → **استيراد نسخة احتياطية**.
4. Select the JSON backup. The native app imports the supported student records and avoids duplicate names.
5. Afterwards, create native backups from the same screen whenever you change phones.

> The existing website backup format contains student and academy basics. Advanced website-only history is not silently fabricated; it remains in the old system unless exported through a later dedicated migration.

## Build an installable APK

Prerequisites: Android SDK command-line tools and Java 21.

```bash
npm install
npm run typecheck
npm run android:apk
```

Output:

```text
android/app/build/outputs/apk/release/app-release.apk
```

## Technical design

| Area | Native implementation |
|---|---|
| UI | React Native components — no WebView |
| Persistence | Expo SQLite database in Android app storage |
| Files | Android document picker and native sharing sheet |
| Backups | JSON export/import |
| Application ID | `com.naneice.desk` |
| Minimum Android | API 24 (Android 7.0) |

## Release note

The generated release APK is suitable for direct installation and is signed with the local Android test key. A Google Play release needs a separately managed production keystore and a signed release AAB/APK.


## Version 2.7.0 — Learning Content

See [PHASE-2.7.0-LEARNING-CONTENT.md](./PHASE-2.7.0-LEARNING-CONTENT.md) for the learning library, question bank, backup behavior, limitations and verification notes.


## Phase 2.9.0 — Academic assessment

- Added an academic assessment tab with an individual student gradebook and group exam reports.
- Shows recorded exam results, subject filtering, weighted overall percentage, lesson-level performance, and group exam averages.
- Supports sharing a plain-text academic report from the Android share sheet.
- Performance summaries use recorded exam scores only; ungraded students and exams are not included in averages.
- Lesson percentages are descriptive indicators, not official school grade bands.
- No changes to unified student-level finance or backup schema.

## Phase 3.0.0 — Student Academic File
Each student profile now includes detailed attendance and exam history, teacher-managed homework tracking, and academic notes. Homework and notes are included in backup schema version 6. This remains a teacher-side local workflow; there is no student/parent portal or online homework submission.

## Phase 3.1.0 — WhatsApp post-session reports

Completed sessions now produce a consistent parent-facing report with student name, academy, date, session number, homework, and notes. Individual sessions open the student's saved WhatsApp number with the report prefilled; group sessions let the teacher choose active students one at a time. The teacher must review and tap Send in WhatsApp. Backup schema version 7 stores session numbers while preserving compatibility with earlier backup versions.

## Version 3.2.0 — Smart Weekly Timetable

The weekly timetable now creates today's session records automatically when the app opens or refreshes. Generation is duplicate-safe, weekly slots are displayed in clear Saturday-to-Friday sections, and one-off reschedules/deletions are preserved as date-specific exceptions. Backup schema version 8 includes these schedule links and exceptions while retaining support for older backup versions. See `PHASE-3.2.0-SMART-TIMETABLE.md`.
