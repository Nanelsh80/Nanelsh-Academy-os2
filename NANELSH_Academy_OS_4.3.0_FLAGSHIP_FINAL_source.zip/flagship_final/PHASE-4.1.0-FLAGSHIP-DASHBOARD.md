# NANELSH Academy OS 4.1.0 — Flagship Dashboard Redesign

## Scope
Presentation-only redesign of the home dashboard. SQLite schema, backup/restore, finance logic, timetable logic, students, groups, sessions, and domain types remain untouched.

## UX direction
- Luxury flagship command center
- Warm Ivory / Deep Teal / Champagne Gold
- Compact information hierarchy
- Next Session as the primary operational focus
- Quick actions for session, student, payment, and group
- Four high-signal metrics instead of six equal-weight cards
- Follow-up section prioritizes overdue accounts, ready reports, and low session balances
- Arabic RTL preserved
