# NANELSH Academy OS 4.2.0 — Flagship Dashboard

## UI/UX focus
- Reworked the Home dashboard information hierarchy without changing the data layer.
- Removed repeated dashboard metrics from the main flow.
- Added a compact `TODAY AT A GLANCE` command summary.
- Added a compact financial/attendance insight strip.
- Reframed the daily schedule section as the operational center of the Home screen.
- Reduced bottom navigation to five primary destinations plus a `المزيد` sheet for Content, Assessment, and Settings. All existing destinations remain accessible.
- Preserved RTL, local SQLite persistence, backup/restore, finance, timetable, student, group, content, assessment, and session logic.

## Data safety
No changes to `src/data/store.ts`, `src/lib/backup.ts`, or `src/types.ts` were made for this UI phase.

## Release
- App version: 4.2.0
- Android versionCode: 23
- Light Mode only
- Luxury / Flagship visual language
