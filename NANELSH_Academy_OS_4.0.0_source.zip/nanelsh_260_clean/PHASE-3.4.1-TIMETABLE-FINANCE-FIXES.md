# Phase 3.4.1 — Timetable & Finance Reliability Fixes

## Timetable generation
- Normalize Arabic and English weekday labels and trim whitespace before matching recurring timetable slots.
- Parse the target calendar date in local time with validation.
- Handle nullable/undefined student and group IDs consistently.
- Skip archived groups when generating sessions.
- Regenerate today's sessions at app startup, when returning to the foreground, and when the local date rolls over while the app remains open.
- Preserve the unique `(timetableSlotId, sessionDate)` guard and one-day exceptions to prevent duplicates or resurrection of cancelled/moved sessions.

## Finance date
- Add a native date picker to every financial transaction form, defaulting to today's local date.
- Pass the selected `transactionDate` into the existing transaction writer.
- No database schema change: the existing `transactionDate` column remains the source of truth.
- Existing transactions and unified student subscription balances remain unchanged.

## Release
- App version: 3.4.1
- Android versionCode: 19
