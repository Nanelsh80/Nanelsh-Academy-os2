# NANELSH Academy OS 3.4.0 — Ultra Premium UI

## Approved visual direction
- Style: Luxury Minimal
- Appearance: Light Mode only
- Warm Ivory `#F6F3EC` background
- Deep Teal `#153C3A` primary brand
- Teal `#28766C` interactive accent
- Champagne Gold `#C5A46D` restrained accent
- Soft Sage `#E4EFEB` secondary surfaces
- Charcoal Green `#20302E` primary text

## Scope
- Refine shared visual tokens and common components across all eight primary navigation areas and their detail sheets.
- Preserve Arabic RTL and English LTR behavior.
- Keep status colors distinct for success, warning, and destructive actions.
- Maintain the existing native Android/Expo architecture.

## Data and behavior protection
- No changes to `src/data/store.ts`, SQLite table definitions, indexes, additive migrations, or database filename.
- No changes to `src/lib/backup.ts`, native backup schema, restore behavior, or library file handling.
- No changes to domain types or data-access APIs.
- Release metadata only: app version 3.4.0 and Android versionCode 18.

## Release gates
- Full TypeScript typecheck.
- Android release APK build.
- Install/launch smoke test on Android.
- Visual review of all eight primary sections.
- Regression checks for student/group/session operations, attendance, timetable, exams, content library, finance, WhatsApp reports, and backup/restore.
