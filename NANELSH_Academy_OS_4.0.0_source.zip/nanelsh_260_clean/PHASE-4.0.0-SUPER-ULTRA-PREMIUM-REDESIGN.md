# NANELSH Academy OS 4.0.0 — Super Ultra Premium UI

## Design direction
- Luxury flagship mobile experience.
- Light Mode only.
- Warm Ivory `#F6F3EC` foundation.
- Deep Teal `#153C3A` primary brand.
- Teal `#28766C` interaction accent.
- Champagne Gold `#C5A46D` premium accent.
- Sage `#E4EFEB` supporting surface.
- Charcoal Green `#20302E` primary text.

## UI work in this phase
- Rebuilt the visual hierarchy of the global header.
- Integrated the approved NANELSH luxury icon into the in-app brand header and loading state.
- Introduced premium eyebrow labels, local-status pill, refined spacing, elevated shadows, and stronger card hierarchy.
- Refined dashboard hero, metrics, buttons, cards, and bottom navigation.
- Preserved Arabic RTL behavior and English LTR compatibility.
- Kept all data, business logic, SQLite schema, backup/restore, and domain types untouched.

## Data protection
The following files are intentionally unchanged from 3.4.2:
- `src/data/store.ts`
- `src/lib/backup.ts`
- `src/types.ts`

## Release gates
- TypeScript full check on GitHub Actions.
- Android release APK build.
- Android install/launch smoke test.
- Visual review of all eight primary sections.
- Regression checks for students, groups, sessions, attendance, timetable, exams, content, finance, reports, and backup/restore.
