import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import DateTimePicker from "@react-native-community/datetimepicker";
import * as Haptics from "expo-haptics";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { StatusBar } from "expo-status-bar";
import { type ComponentProps, type ReactNode, useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  AppState,
  Image,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type ListRenderItemInfo,
  Share,
} from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import {
  completeSession,
  createAcademyDocument,
  createAcademyQuestion,
  createAcademyExam,
  deleteAcademyExam,
  listAcademyExams,
  listExamResults,
  listAllExamResults,
  listStudentAttendanceHistory,
  listStudentHistoricalSessions,
  addHistoricalSessionCount,
  addHistoricalSessionDate,
  deleteHistoricalSessionRecord,
  listStudentHomework,
  createStudentHomework,
  updateStudentHomeworkStatus,
  deleteStudentHomework,
  listStudentAcademicNotes,
  createStudentAcademicNote,
  deleteStudentAcademicNote,
  saveExamResult,
  deleteAcademyDocument,
  deleteAcademyQuestion,
  listAcademyDocuments,
  listAcademyQuestions,
  createGroup,
  createSession,
  createStudent,
  createRecurringTimetableSlots,
  createTransaction,
  deleteSession,
  deleteTimetableSlot,
  deleteTransaction,
  getSnapshot,
  generateSessionsFromWeeklyTimetable,
  initializeStore,
  listSubjects,
  listStudentSubjects,
  setStudentSubjects,
  listGroupMembers,
  listGroupSessions,
  enrollStudentInGroup,
  endGroupEnrollment,
  setTimetableSlotActive,
  startSession,
  todayDate,
  updateCompletedSession,
  updateGroup,
  updateScheduledSession,
  updateStudent,
  updateTimetableSlot,
} from "./src/data/store";
import { buildSessionReportMessage, chooseAndRestoreBackup, shareLocalBackup, shareSessionReport } from "./src/lib/backup";
import type {
  AcademySubject,
  AcademyDocument,
  AcademyQuestion,
  AcademyExam,
  ExamResult,
  ExamPerformanceRow,
  StudentHomework,
  StudentAcademicNote,
  StudentAttendanceHistoryRow,
  HistoricalSessionRecord,
  QuestionType,
  DashboardSnapshot,
  FinanceTransaction,
  LessonSession,
  Student,
  TimetableSlot,
  TransactionType,
  TutoringGroup,
} from "./src/types";

const COLORS = {
  // NANELSH Luxury Light palette — presentation-only tokens; data layer is untouched.
  background: "#F6F3EC",
  surface: "#FFFEFB",
  ink: "#20302E",
  muted: "#77817A",
  primary: "#28766C",
  primaryDeep: "#153C3A",
  sage: "#E4EFEB",
  sageSoft: "#F2F6F2",
  champagne: "#C5A46D",
  champagneSoft: "#EBDCC4",
  sandSoft: "#F5E9E0",
  mist: "#E8EFEC",
  border: "#E7E1D6",
  danger: "#B75B55",
  dangerSoft: "#F8EAE7",
  warning: "#9A7136",
  warningSoft: "#F7F0E3",
  success: "#477A68",
  successSoft: "#E7F0EA",
};

type Tab = "home" | "students" | "sessions" | "groups" | "content" | "assessment" | "finance" | "settings";
type ModalKind = "student" | "session" | "complete" | "group" | "finance" | "timetable" | "studentDetail" | "groupDetail" | "sessionEdit" | "report" | "timetableEdit" | null;
type IconName = ComponentProps<typeof MaterialIcons>["name"];
type ReportRecipient = { studentId: number; name: string; phone: string | null };
type GroupAttendanceDraft = { studentId: number; name: string; status: "حاضر" | "غائب" | "متأخر" };

const TABS: Array<{ key: Tab; title: string; icon: IconName }> = [
  { key: "home", title: "الرئيسية", icon: "home-filled" },
  { key: "students", title: "الطلاب", icon: "school" },
  { key: "sessions", title: "الحصص", icon: "calendar-month" },
  { key: "groups", title: "المجموعات", icon: "groups" },
  { key: "content", title: "المحتوى", icon: "menu-book" },
  { key: "assessment", title: "التقييم", icon: "assessment" },
  { key: "finance", title: "المالية", icon: "account-balance-wallet" },
  { key: "settings", title: "إعدادات", icon: "tune" },
];

const DAYS = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];
const WEEKDAY_NAMES = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
const DEFAULT_WEEKLY_TIME = "16:00";

function timeToDate(time: string) {
  const [hours, minutes] = time.split(":").map(Number);
  return new Date(2000, 0, 1, Number.isFinite(hours) ? hours : 16, Number.isFinite(minutes) ? minutes : 0);
}

function dateToTime(date: Date) {
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function formatTime(time: string) {
  return new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit" }).format(timeToDate(time));
}

function haptic() {
  void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

function formatDate(date: string) {
  return new Intl.DateTimeFormat("ar-EG-u-ca-gregory", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${date}T12:00:00`));
}

function formatMoney(amount: number) {
  return new Intl.NumberFormat("ar-EG", {
    style: "currency",
    currency: "EGP",
    maximumFractionDigits: 0,
  }).format(amount);
}

function sessionLabel(session: LessonSession) {
  return session.studentName || session.groupName || "حصة بدون عنوان";
}

function attendanceTone(attendance: LessonSession["attendance"]) {
  if (attendance === "حاضر") return { color: COLORS.success, background: COLORS.successSoft };
  if (attendance === "متأخر") return { color: COLORS.warning, background: COLORS.warningSoft };
  if (attendance === "غائب") return { color: COLORS.danger, background: COLORS.dangerSoft };
  return { color: COLORS.muted, background: COLORS.sageSoft };
}

function statusLabel(status: LessonSession["status"]) {
  if (status === "completed") return "مكتملة";
  if (status === "in_progress") return "قيد التنفيذ";
  return "مجدولة";
}

function statusTone(status: LessonSession["status"]) {
  if (status === "completed") return { color: COLORS.success, background: COLORS.successSoft };
  if (status === "in_progress") return { color: COLORS.primaryDeep, background: COLORS.sage };
  return { color: COLORS.warning, background: COLORS.warningSoft };
}

function AppButton({
  title,
  onPress,
  icon,
  tone = "primary",
  disabled = false,
  compact = false,
}: {
  title: string;
  onPress: () => void;
  icon?: IconName;
  tone?: "primary" | "soft" | "outline" | "danger";
  disabled?: boolean;
  compact?: boolean;
}) {
  const palette =
    tone === "primary"
      ? { backgroundColor: COLORS.primary, text: "#FFFFFF", borderColor: COLORS.primary }
      : tone === "danger"
        ? { backgroundColor: COLORS.dangerSoft, text: COLORS.danger, borderColor: "#EBCBC4" }
        : tone === "soft"
          ? { backgroundColor: COLORS.sage, text: COLORS.primaryDeep, borderColor: COLORS.sage }
          : { backgroundColor: "transparent", text: COLORS.primaryDeep, borderColor: COLORS.border };
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      disabled={disabled}
      onPress={() => {
        haptic();
        onPress();
      }}
      style={({ pressed }) => [
        styles.button,
        compact && styles.buttonCompact,
        {
          backgroundColor: palette.backgroundColor,
          borderColor: palette.borderColor,
          opacity: disabled ? 0.45 : pressed ? 0.82 : 1,
          transform: [{ scale: pressed && !disabled ? 0.98 : 1 }],
        },
      ]}
    >
      {icon ? <MaterialIcons name={icon} size={compact ? 17 : 19} color={palette.text} /> : null}
      <Text style={[styles.buttonText, compact && styles.buttonTextCompact, { color: palette.text }]}>{title}</Text>
    </Pressable>
  );
}

function IconButton({ label, icon, onPress, tone = "default" }: { label: string; icon: IconName; onPress: () => void; tone?: "default" | "danger" }) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={() => {
        haptic();
        onPress();
      }}
      style={({ pressed }) => [
        styles.iconButton,
        tone === "danger" && { backgroundColor: COLORS.dangerSoft },
        pressed && { opacity: 0.7 },
      ]}
    >
      <MaterialIcons name={icon} size={20} color={tone === "danger" ? COLORS.danger : COLORS.primaryDeep} />
    </Pressable>
  );
}

function SectionHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionHeaderText}>
        <Text style={styles.sectionTitle}>{title}</Text>
        {subtitle ? <Text style={styles.sectionSubtitle}>{subtitle}</Text> : null}
      </View>
      {action}
    </View>
  );
}

function Metric({ icon, label, value, tint }: { icon: IconName; label: string; value: string | number; tint: string }) {
  return (
    <View style={styles.metricCard}>
      <View style={[styles.metricIcon, { backgroundColor: tint }]}>
        <MaterialIcons name={icon} size={20} color={COLORS.primaryDeep} />
      </View>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function EmptyState({ icon, title, body, action }: { icon: IconName; title: string; body: string; action?: React.ReactNode }) {
  return (
    <View style={styles.emptyState}>
      <View style={styles.emptyIcon}><MaterialIcons name={icon} size={30} color={COLORS.primary} /></View>
      <Text style={styles.emptyTitle}>{title}</Text>
      <Text style={styles.emptyBody}>{body}</Text>
      {action ? <View style={{ marginTop: 14 }}>{action}</View> : null}
    </View>
  );
}

function InputField({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType,
  multiline = false,
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  keyboardType?: "default" | "numeric" | "decimal-pad" | "phone-pad";
  multiline?: boolean;
}) {
  return (
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#929A92"
        keyboardType={keyboardType}
        textAlign="right"
        multiline={multiline}
        style={[styles.input, multiline && styles.inputMultiline]}
      />
    </View>
  );
}

function Choice({ label, selected, onPress, tone = "primary" }: { label: string; selected: boolean; onPress: () => void; tone?: "primary" | "danger" | "warning" }) {
  const selectedColor = tone === "danger" ? COLORS.danger : tone === "warning" ? COLORS.warning : COLORS.primaryDeep;
  const selectedBackground = tone === "danger" ? COLORS.dangerSoft : tone === "warning" ? COLORS.warningSoft : COLORS.sage;
  return (
    <Pressable
      accessibilityRole="radio"
      accessibilityState={{ selected }}
      onPress={() => { haptic(); onPress(); }}
      style={({ pressed }) => [
        styles.choice,
        selected && { backgroundColor: selectedBackground, borderColor: selectedColor },
        pressed && { opacity: 0.72 },
      ]}
    >
      <Text style={[styles.choiceText, selected && { color: selectedColor }]}>{label}</Text>
    </Pressable>
  );
}

function Sheet({ visible, title, subtitle, onClose, children }: { visible: boolean; title: string; subtitle?: string; onClose: () => void; children: ReactNode }) {
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.modalBackdrop} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        <View style={styles.sheet}>
          <View style={styles.sheetHandle} />
          <View style={styles.sheetTop}>
            <View style={{ flex: 1 }}>
              <Text style={styles.sheetTitle}>{title}</Text>
              {subtitle ? <Text style={styles.sheetSubtitle}>{subtitle}</Text> : null}
            </View>
            <IconButton label="إغلاق" icon="close" onPress={onClose} />
          </View>
          <ScrollView contentContainerStyle={styles.sheetScroll} keyboardShouldPersistTaps="handled">
            {children}
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

function NativeHeader({ onReload }: { onReload: () => void }) {
  return (
    <View style={styles.appHeader}>
      <View style={styles.headerHairline} />
      <View style={styles.brandRow}>
        <View style={styles.brandMarkFrame}>
          <Image source={require("./assets/icon.png")} style={styles.brandMarkImage} resizeMode="cover" />
        </View>
        <View style={styles.brandCopy}>
          <Text style={styles.brandEyebrow}>NANELSH · LUXURY ACADEMY OS</Text>
          <Text style={styles.brandName}>NANELSH Academy</Text>
          <Text style={styles.brandCaption}>مركزك الذكي لإدارة الأكاديمية</Text>
        </View>
      </View>
      <View style={styles.headerActions}>
        <View style={styles.livePill}><View style={styles.liveDot} /><Text style={styles.livePillText}>محلي</Text></View>
        <IconButton label="تحديث البيانات المحلية" icon="refresh" onPress={onReload} />
      </View>
    </View>
  );
}

function HomeScreen({ snapshot, onOpen, onQuickComplete }: { snapshot: DashboardSnapshot; onOpen: (kind: ModalKind) => void; onQuickComplete: (session: LessonSession) => void }) {
  const today = todayDate();
  const todaySessions = snapshot.sessions.filter(session => session.sessionDate === today).sort((a, b) => a.startTime.localeCompare(b.startTime));
  const completed = todaySessions.filter(session => session.status === "completed");
  const upcoming = todaySessions.filter(session => session.status !== "completed");
  const nextSession = upcoming[0] ?? null;
  const activeStudents = snapshot.students.filter(student => student.active);
  const lowSessions = activeStudents.filter(student => student.remainingSessions <= 3);
  const readyReports = completed.length;
  const outstanding = activeStudents.reduce((sum, student) => {
    const entries = snapshot.transactions.filter(transaction => transaction.studentId === student.id);
    const paid = entries.reduce((value, transaction) => value + (transaction.type === "income" ? transaction.amount : transaction.type === "refund" ? -transaction.amount : 0), 0);
    const discounts = entries.filter(transaction => transaction.type === "discount").reduce((value, transaction) => value + transaction.amount, 0);
    return sum + Math.max(0, (student.subscriptionAmount ?? 0) - paid - discounts);
  }, 0);
  const overdueCount = activeStudents.filter(student => {
    const entries = snapshot.transactions.filter(transaction => transaction.studentId === student.id);
    const paid = entries.reduce((value, transaction) => value + (transaction.type === "income" ? transaction.amount : transaction.type === "refund" ? -transaction.amount : 0), 0);
    const discounts = entries.filter(transaction => transaction.type === "discount").reduce((value, transaction) => value + transaction.amount, 0);
    return Math.max(0, (student.subscriptionAmount ?? 0) - paid - discounts) > 0 && Boolean(student.subscriptionDueDate) && student.subscriptionDueDate! < today;
  }).length;
  const completedSessions = snapshot.sessions.filter(session => session.status === "completed");
  const attendanceRate = completedSessions.length
    ? Math.round((completedSessions.filter(session => session.attendance === "حاضر" || session.attendance === "متأخر").length / completedSessions.length) * 100)
    : 0;
  const monthlyPrefix = today.slice(0, 7);
  const cashImpact = (transaction: FinanceTransaction) => transaction.type === "income" ? transaction.amount : transaction.type === "expense" || transaction.type === "refund" ? -transaction.amount : 0;
  const monthlyNet = snapshot.transactions
    .filter(transaction => transaction.transactionDate.startsWith(monthlyPrefix))
    .reduce((sum, transaction) => sum + cashImpact(transaction), 0);

  const quickActions = [
    { label: "حصة", icon: "add-circle-outline" as IconName, action: () => onOpen("session") },
    { label: "طالبة", icon: "person-add-alt-1" as IconName, action: () => onOpen("student") },
    { label: "دفعة", icon: "payments" as IconName, action: () => onOpen("finance") },
    { label: "مجموعة", icon: "groups" as IconName, action: () => onOpen("group") },
  ];

  return (
    <FlatList
      data={upcoming}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <>
          <View style={styles.commandCenter}>
            <View style={styles.commandOrbOne} />
            <View style={styles.commandOrbTwo} />
            <View style={styles.commandTopRow}>
              <View style={styles.commandLive}><View style={styles.commandLiveDot} /><Text style={styles.commandLiveText}>اليوم</Text></View>
              <Text style={styles.commandEyebrow}>NANELSH · COMMAND CENTER</Text>
            </View>
            <Text style={styles.commandGreeting}>صباح الخير، د. نانيس</Text>
            <Text style={styles.commandDate}>{formatDate(today)}</Text>
            <View style={styles.commandSummaryRow}>
              <View style={styles.commandSummary}><Text style={styles.commandSummaryValue}>{todaySessions.length}</Text><Text style={styles.commandSummaryLabel}>حصص اليوم</Text></View>
              <View style={styles.commandSummaryDivider} />
              <View style={styles.commandSummary}><Text style={styles.commandSummaryValue}>{activeStudents.length}</Text><Text style={styles.commandSummaryLabel}>طلاب نشطون</Text></View>
              <View style={styles.commandSummaryDivider} />
              <View style={styles.commandSummary}><Text style={styles.commandSummaryValue}>{overdueCount}</Text><Text style={styles.commandSummaryLabel}>متأخر</Text></View>
            </View>
          </View>

          <View style={styles.nextSessionCard}>
            <View style={styles.nextSessionAccent} />
            <View style={styles.nextSessionIcon}><MaterialIcons name="schedule" size={22} color={COLORS.primaryDeep} /></View>
            <View style={styles.nextSessionCopy}>
              <Text style={styles.nextSessionEyebrow}>NEXT SESSION</Text>
              {nextSession ? (
                <>
                  <Text numberOfLines={1} style={styles.nextSessionTitle}>{sessionLabel(nextSession)}</Text>
                  <Text numberOfLines={1} style={styles.nextSessionMeta}>{nextSession.startTime} · {nextSession.durationMinutes} دقيقة · {nextSession.subject || "حصة"}</Text>
                </>
              ) : (
                <>
                  <Text style={styles.nextSessionTitle}>انتهت حصص اليوم</Text>
                  <Text style={styles.nextSessionMeta}>يمكنك مراجعة التقارير أو إضافة حصة جديدة.</Text>
                </>
              )}
            </View>
            {nextSession ? <AppButton title="ابدئي" icon="play-arrow" onPress={() => { if (nextSession.status === "scheduled") { onQuickComplete(nextSession); } else { onQuickComplete(nextSession); } }} tone="primary" compact /> : null}
          </View>

          <View style={styles.quickActionsCard}>
            <Text style={styles.quickActionsTitle}>إجراءات سريعة</Text>
            <View style={styles.quickActionsGrid}>
              {quickActions.map(item => (
                <Pressable key={item.label} accessibilityRole="button" accessibilityLabel={`إضافة ${item.label}`} onPress={() => { haptic(); item.action(); }} style={({ pressed }) => [styles.quickAction, pressed && { opacity: 0.72, transform: [{ scale: 0.98 }] }]}>
                  <View style={styles.quickActionIcon}><MaterialIcons name={item.icon} size={21} color={COLORS.primaryDeep} /></View>
                  <Text style={styles.quickActionText}>إضافة {item.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.todayAtGlance}>
            <View style={styles.todayAtGlanceTop}>
              <View><Text style={styles.todayAtGlanceEyebrow}>TODAY AT A GLANCE</Text><Text style={styles.todayAtGlanceTitle}>ملخص يومك</Text></View>
              <View style={styles.todayAtGlanceBadge}><MaterialIcons name="auto-awesome" size={15} color={COLORS.champagne} /><Text style={styles.todayAtGlanceBadgeText}>ذكي</Text></View>
            </View>
            <View style={styles.todayAtGlanceRow}>
              <View style={styles.todayAtGlanceItem}><Text style={styles.todayAtGlanceValue}>{todaySessions.length}</Text><Text style={styles.todayAtGlanceLabel}>حصص اليوم</Text></View>
              <View style={styles.todayAtGlanceDivider} />
              <View style={styles.todayAtGlanceItem}><Text style={styles.todayAtGlanceValue}>{activeStudents.length}</Text><Text style={styles.todayAtGlanceLabel}>طلاب نشطون</Text></View>
              <View style={styles.todayAtGlanceDivider} />
              <View style={styles.todayAtGlanceItem}><Text style={[styles.todayAtGlanceValue, overdueCount > 0 && { color: COLORS.warning }]}>{overdueCount}</Text><Text style={styles.todayAtGlanceLabel}>متأخر</Text></View>
            </View>
          </View>

          <View style={styles.insightStrip}>
            <View style={styles.insightStripItem}><MaterialIcons name="account-balance-wallet" size={18} color={COLORS.primaryDeep} /><View><Text style={styles.insightStripValue}>{formatMoney(outstanding)}</Text><Text style={styles.insightStripLabel}>المستحقات</Text></View></View>
            <View style={styles.insightStripDivider} />
            <View style={styles.insightStripItem}><MaterialIcons name="fact-check" size={18} color={COLORS.success} /><View><Text style={styles.insightStripValue}>{attendanceRate}%</Text><Text style={styles.insightStripLabel}>معدل الحضور</Text></View></View>
            <View style={styles.insightStripDivider} />
            <View style={styles.insightStripItem}><MaterialIcons name="trending-up" size={18} color={COLORS.champagne} /><View><Text style={styles.insightStripValue}>{formatMoney(monthlyNet)}</Text><Text style={styles.insightStripLabel}>صافي الشهر</Text></View></View>
          </View>

          <SectionHeader title="جدول اليوم" subtitle={upcoming.length ? "الحصص القادمة مرتبة حسب وقت البدء" : "لا توجد حصص مجدولة متبقية اليوم"} />
        </>
      }
      ListEmptyComponent={
        <EmptyState
          icon="event-available"
          title="لا توجد حصص متبقية اليوم"
          body="يمكنك إضافة حصة جديدة أو مراجعة التقارير المنجزة."
          action={<AppButton title="جدولة حصة" icon="add" onPress={() => onOpen("session")} compact />}
        />
      }
      renderItem={({ item }) => <SessionCard session={item} onComplete={() => onQuickComplete(item)} />}
      ListFooterComponent={
        <>
          <SectionHeader title="تحتاج متابعة" subtitle="أهم العناصر التي تحتاج انتباهك" />
          {overdueCount > 0 ? <View style={styles.softNotice}><MaterialIcons name="warning-amber" size={18} color={COLORS.warning} /><Text style={styles.softNoticeText}>يوجد {overdueCount} حساب مستحق يحتاج مراجعة.</Text></View> : null}
          {readyReports > 0 ? <View style={styles.softNotice}><MaterialIcons name="mark-email-read" size={18} color={COLORS.primaryDeep} /><Text style={styles.softNoticeText}>لديك {readyReports} تقرير حصة جاهز للمراجعة والمشاركة.</Text></View> : null}
          {lowSessions.length ? (
            lowSessions.slice(0, 4).map(student => (
              <View key={student.id} style={styles.followUpRow}>
                <View style={styles.avatar}><Text style={styles.avatarText}>{student.name.slice(0, 1)}</Text></View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.rowTitle}>{student.name}</Text>
                  <Text style={styles.rowSub}>متبقي {student.remainingSessions} حصة</Text>
                </View>
                <View style={styles.lowBadge}><Text style={styles.lowBadgeText}>اشتراك</Text></View>
              </View>
            ))
          ) : (
            <View style={styles.softNotice}><MaterialIcons name="verified" size={18} color={COLORS.success} /><Text style={styles.softNoticeText}>لا توجد اشتراكات منخفضة حاليًا.</Text></View>
          )}
        </>
      }
    />
  );
}

function SessionCard({ session, onStart, onComplete, onEdit, onReport, onDelete }: { session: LessonSession; onStart?: () => void; onComplete?: () => void; onEdit?: () => void; onReport?: () => void; onDelete?: () => void }) {
  const status = statusTone(session.status);
  return (
    <View style={styles.sessionCard}>
      <View style={styles.sessionAccent} />
      <View style={styles.sessionTop}>
        <View style={{ flex: 1 }}>
          <Text style={styles.sessionTime}>{session.startTime}</Text>
          <Text style={styles.sessionName}>{sessionLabel(session)}</Text>
          <Text style={styles.sessionMeta}>{[session.academy, session.subject, `${session.durationMinutes} دقيقة`].filter(Boolean).join(" · ")}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: status.background }]}><Text style={[styles.statusText, { color: status.color }]}>{statusLabel(session.status)}</Text></View>
      </View>
      {session.status === "completed" ? (
        <View style={styles.completedInfo}>
          <View style={[styles.attendanceBadge, { backgroundColor: attendanceTone(session.attendance).background }]}> 
            <Text style={[styles.attendanceText, { color: attendanceTone(session.attendance).color }]}>{session.attendance || "غير مسجل"}</Text>
          </View>
          <Text numberOfLines={1} style={styles.completedNotes}>{session.notes || session.homework || "تم حفظ تقرير الحصة محليًا"}</Text>
          {onReport ? <IconButton label="إرسال تقرير الحصة" icon="share" onPress={onReport} /> : null}
          {onEdit ? <IconButton label="تعديل تقرير الحصة" icon="edit" onPress={onEdit} /> : null}
          {onDelete ? <IconButton label="حذف الحصة" icon="delete-outline" onPress={onDelete} tone="danger" /> : null}
        </View>
      ) : (
        <View style={styles.sessionActions}>
          {session.status === "scheduled" && onStart ? <AppButton title="ابدئي الحصة" icon="play-arrow" onPress={onStart} compact /> : null}
          {onComplete ? <AppButton title="إنهاء الحصة" icon="check-circle-outline" onPress={onComplete} tone={session.status === "scheduled" ? "outline" : "primary"} compact /> : null}
          {onEdit ? <IconButton label="تعديل موعد الحصة" icon="edit-calendar" onPress={onEdit} /> : null}
          {onDelete ? <IconButton label="حذف الحصة" icon="delete-outline" onPress={onDelete} tone="danger" /> : null}
        </View>
      )}
    </View>
  );
}

function StudentsScreen({ students, onAdd, onOpen, onDelete }: { students: Student[]; onAdd: () => void; onOpen: (student: Student) => void; onDelete: (student: Student) => void }) {
  const [query, setQuery] = useState("");
  const normalizedQuery = query.trim().toLocaleLowerCase("ar-EG");
  const filteredStudents = normalizedQuery
    ? students.filter(student => [student.name, student.academy, student.subjectNames, student.subject, student.phone].some(value => value?.toLocaleLowerCase("ar-EG").includes(normalizedQuery)))
    : students;
  return (
    <FlatList
      data={filteredStudents}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={<><SectionHeader title="الطلاب" subtitle={`النشطات: ${students.filter(student => student.active).length} · الموقوفات: ${students.filter(student => !student.active).length}`} action={<AppButton title="إضافة" icon="person-add-alt-1" onPress={onAdd} compact />} /><View style={styles.searchBox}><MaterialIcons name="search" size={20} color={COLORS.muted} /><TextInput value={query} onChangeText={setQuery} placeholder="ابحثي بالاسم أو الأكاديمية أو المادة" placeholderTextColor="#929A92" textAlign="right" style={styles.searchInput} /></View></>}
      ListEmptyComponent={<EmptyState icon="school" title={students.length ? "لا توجد نتائج مطابقة" : "لا يوجد طلاب بعد"} body={students.length ? "جرّبي كلمة بحث مختلفة." : "أضيفي أول طالبة لبدء متابعة الحصص والاشتراكات."} action={!students.length ? <AppButton title="إضافة طالبة" icon="add" onPress={onAdd} compact /> : undefined} />}
      renderItem={({ item }) => (
        <View style={styles.studentCard}>
          <Pressable accessibilityRole="button" accessibilityLabel={`فتح ملف ${item.name}`} onPress={() => onOpen(item)} style={({ pressed }) => [styles.studentPressTarget, pressed && { opacity: 0.7 }]}>
            <View style={styles.avatar}><Text style={styles.avatarText}>{item.name.slice(0, 1)}</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>{item.name}</Text>
              <Text style={styles.rowSub}>{[item.academy, item.subjectNames || item.subject, item.active ? null : "مؤرشفة / موقوفة"].filter(Boolean).join(" · ") || "لم تُحدّد الأكاديمية أو المادة"}</Text>
              <View style={styles.progressRow}>
                <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.min(100, item.totalSessions ? (item.completedSessions / item.totalSessions) * 100 : 0)}%` }]} /></View>
                <Text style={styles.progressText}>{item.completedSessions}/{item.totalSessions}</Text>
              </View>
              <Text style={styles.remainingText}>المتبقي: {item.remainingSessions} حصة</Text>
            </View>
          </Pressable>
          <IconButton label={item.active ? `أرشفة ${item.name}` : `إعادة تفعيل ${item.name}`} icon={item.active ? "archive" : "unarchive"} onPress={() => onDelete(item)} tone={item.active ? "danger" : "default"} />
        </View>
      )}
    />
  );
}

function StudentDetailSheet({ student, sessions, transactions, subjectOptions, groups, onClose, onSaved }: {
  student: Student | null;
  sessions: LessonSession[];
  transactions: FinanceTransaction[];
  subjectOptions: AcademySubject[];
  groups: TutoringGroup[];
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const [name, setName] = useState("");
  const [academy, setAcademy] = useState("");
  const [subjectIds, setSubjectIds] = useState<string[]>([]);
  const [phone, setPhone] = useState("");
  const [total, setTotal] = useState("0");
  const [remaining, setRemaining] = useState("0");
  const [notes, setNotes] = useState("");
  const [active, setActive] = useState(1);
  const [subscriptionAmount, setSubscriptionAmount] = useState("0");
  const [subscriptionDueDate, setSubscriptionDueDate] = useState("");
  const [saving, setSaving] = useState(false);
  const [attendanceHistory, setAttendanceHistory] = useState<StudentAttendanceHistoryRow[]>([]);
  const [historicalSessions, setHistoricalSessions] = useState<HistoricalSessionRecord[]>([]);
  const [historicalMode, setHistoricalMode] = useState<"count" | "dated">("count");
  const [historicalGroupId, setHistoricalGroupId] = useState<number | null>(null);
  const [historicalSubject, setHistoricalSubject] = useState("");
  const [historicalCount, setHistoricalCount] = useState("1");
  const [historicalDate, setHistoricalDate] = useState(todayDate());
  const [historicalAttendance, setHistoricalAttendance] = useState<"حاضر" | "غائب" | "معذور" | "متأخر">("حاضر");
  const [historicalHomework, setHistoricalHomework] = useState("");
  const [historicalNotes, setHistoricalNotes] = useState("");
  const [examHistory, setExamHistory] = useState<ExamPerformanceRow[]>([]);
  const [homeworkItems, setHomeworkItems] = useState<StudentHomework[]>([]);
  const [academicNotes, setAcademicNotes] = useState<StudentAcademicNote[]>([]);
  const [homeworkSubject, setHomeworkSubject] = useState("");
  const [homeworkLesson, setHomeworkLesson] = useState("");
  const [homeworkDescription, setHomeworkDescription] = useState("");
  const [homeworkDueDate, setHomeworkDueDate] = useState("");
  const [noteSubject, setNoteSubject] = useState("");
  const [noteTitle, setNoteTitle] = useState("");
  const [noteBody, setNoteBody] = useState("");
  const [profileBusy, setProfileBusy] = useState(false);

  async function refreshAcademicProfile(studentId: number) {
    const [attendanceRows, resultRows, homeworkRows, noteRows, historicalRows] = await Promise.all([
      listStudentAttendanceHistory(studentId),
      listAllExamResults(),
      listStudentHomework(studentId),
      listStudentAcademicNotes(studentId),
      listStudentHistoricalSessions(studentId),
    ]);
    setAttendanceHistory(attendanceRows);
    setHistoricalSessions(historicalRows);
    setExamHistory(resultRows.filter(row => row.studentId === studentId));
    setHomeworkItems(homeworkRows);
    setAcademicNotes(noteRows);
  }

  useEffect(() => {
    if (!student) return;
    setName(student.name);
    setAcademy(student.academy || "");
    setSubjectIds([]);
    setPhone(student.phone || "");
    setTotal(String(student.totalSessions));
    setRemaining(String(student.remainingSessions));
    setNotes(student.lastNotes || "");
    setActive(student.active);
    setSubscriptionAmount(String(student.subscriptionAmount ?? 0));
    setSubscriptionDueDate(student.subscriptionDueDate || "");
    setHistoricalSubject(subjectOptions[0]?.nameAr || "العلوم");
    setHistoricalGroupId(null);
    void listStudentSubjects(student.id).then(subjects => {
      setSubjectIds(subjects.map(subject => subject.id));
      if (subjects.length) setHistoricalSubject(subjects[0].nameAr);
    }).catch(error => Alert.alert("تعذر تحميل المواد", error instanceof Error ? error.message : "حاولي مرة أخرى."));
    void refreshAcademicProfile(student.id).catch(error => Alert.alert("تعذر تحميل الملف الأكاديمي", error instanceof Error ? error.message : "حاولي مرة أخرى."));
  }, [student?.id]);

  const history = student ? sessions.filter(session => session.studentId === student.id).slice(0, 4) : [];
  const studentTransactions = student ? transactions.filter(transaction => transaction.studentId === student.id) : [];
  const paidAmount = studentTransactions.reduce((sum, transaction) => sum + (transaction.type === "income" ? transaction.amount : transaction.type === "refund" ? -transaction.amount : 0), 0);
  const discountAmount = studentTransactions.filter(transaction => transaction.type === "discount").reduce((sum, transaction) => sum + transaction.amount, 0);
  const adjustedSubscription = Math.max(0, (Number(subscriptionAmount) || 0) - discountAmount);
  const outstandingAmount = Math.max(0, adjustedSubscription - paidAmount);
  const financeHistory = studentTransactions.slice(0, 8);
  const datedHistoricalSessions = historicalSessions.filter(row => row.entryType === "dated");
  const attendanceCounted = attendanceHistory.length + datedHistoricalSessions.length;
  const attendancePresent = attendanceHistory.filter(row => row.status === "حاضر" || row.status === "متأخر").length
    + datedHistoricalSessions.filter(row => row.attendance === "حاضر" || row.attendance === "متأخر").length;
  const attendancePercent = attendanceCounted ? Math.round(attendancePresent / attendanceCounted * 100) : 0;
  const examEarned = examHistory.reduce((sum, row) => sum + Number(row.score || 0), 0);
  const examPossible = examHistory.reduce((sum, row) => sum + Number(row.examTotalMarks || 0), 0);
  const examPercent = examPossible ? Math.round(examEarned / examPossible * 100) : 0;
  const homeworkDone = homeworkItems.filter(item => item.status === "done").length;
  function toggleSubject(subjectId: string) {
    setSubjectIds(current => current.includes(subjectId)
      ? current.filter(id => id !== subjectId)
      : [...current, subjectId]);
  }

  async function syncStudentSessionCounters() {
    if (!student) return;
    await onSaved();
    const refreshed = await getSnapshot();
    const current = refreshed.students.find(item => item.id === student.id);
    if (current) {
      setTotal(String(current.totalSessions));
      setRemaining(String(current.remainingSessions));
    }
  }

  async function addHistoricalSession() {
    if (!student) return;
    const chosenGroup = groups.find(group => group.id === historicalGroupId);
    const subject = historicalSubject.trim() || chosenGroup?.subject || "";
    if (!subject) return Alert.alert("المادة مطلوبة", "اختاري المادة المرتبطة بالحصص السابقة.");
    try {
      setProfileBusy(true);
      const shared = { studentId: student.id, groupId: chosenGroup?.id ?? null, groupName: chosenGroup?.name ?? "فردي", subject };
      if (historicalMode === "count") {
        await addHistoricalSessionCount({ ...shared, count: Number(historicalCount) });
        setHistoricalCount("1");
        Alert.alert("تمت الإضافة", `تم تسجيل ${Number(historicalCount)} حصة سابقة دون إضافة تواريخ وهمية.`);
      } else {
        await addHistoricalSessionDate({ ...shared, sessionDate: historicalDate, attendance: historicalAttendance, homework: historicalHomework, notes: historicalNotes });
        setHistoricalDate(todayDate()); setHistoricalHomework(""); setHistoricalNotes("");
        Alert.alert("تم الحفظ", "تمت إضافة الحصة السابقة بتاريخها وحالة الحضور.");
      }
      await refreshAcademicProfile(student.id);
      await syncStudentSessionCounters();
    } catch (error) {
      Alert.alert("تعذر حفظ الحصة السابقة", error instanceof Error ? error.message : "راجعي البيانات وحاولي مرة أخرى.");
    } finally { setProfileBusy(false); }
  }

  async function addHomework() {
    if (!student || !homeworkSubject.trim() || !homeworkLesson.trim() || !homeworkDescription.trim()) {
      return Alert.alert("بيانات ناقصة", "أدخلي المادة والدرس ووصف الواجب.");
    }
    try {
      setProfileBusy(true);
      await createStudentHomework({ studentId: student.id, subject: homeworkSubject, lesson: homeworkLesson, description: homeworkDescription, dueDate: homeworkDueDate || null });
      setHomeworkDescription(""); setHomeworkDueDate("");
      await refreshAcademicProfile(student.id);
      Alert.alert("تم الحفظ", "تمت إضافة الواجب إلى ملف الطالب.");
    } catch (error) { Alert.alert("تعذر حفظ الواجب", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setProfileBusy(false); }
  }

  async function addAcademicNote() {
    if (!student || !noteTitle.trim() || !noteBody.trim()) return Alert.alert("بيانات ناقصة", "أدخلي عنوان الملاحظة ومحتواها.");
    try {
      setProfileBusy(true);
      await createStudentAcademicNote({ studentId: student.id, subject: noteSubject || null, title: noteTitle, body: noteBody });
      setNoteTitle(""); setNoteBody("");
      await refreshAcademicProfile(student.id);
    } catch (error) { Alert.alert("تعذر حفظ الملاحظة", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setProfileBusy(false); }
  }

  async function changeHomeworkStatus(item: StudentHomework, status: StudentHomework["status"]) {
    if (!student) return;
    try { await updateStudentHomeworkStatus(item.id, status); await refreshAcademicProfile(student.id); }
    catch (error) { Alert.alert("تعذر تحديث الواجب", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
  }

  async function save() {
    if (!student || !name.trim()) return Alert.alert("الاسم مطلوب", "اكتبي اسم الطالب أولًا.");
    if (!subjectIds.length) return Alert.alert("اختاري المادة", "يجب أن يكون للطالب مادة واحدة على الأقل.");
    const activeSubject = subjectOptions.find(item => item.id === subjectIds[0]);
    try {
      setSaving(true);
      await setStudentSubjects(student.id, subjectIds);
      await updateStudent(student.id, {
        name, academy, subject: activeSubject?.nameAr ?? null, phone,
        totalSessions: Math.max(0, Number(total) || 0),
        remainingSessions: Math.max(0, Number(remaining) || 0),
        lastNotes: notes, active,
        subscriptionAmount: Math.max(0, Number(subscriptionAmount) || 0),
        subscriptionDueDate: subscriptionDueDate.trim() || null
      });
      await onSaved();
      Alert.alert("تم الحفظ", "تم تحديث ملف الطالب ومواده الدراسية.");
    } catch (error) {
      Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى.");
    } finally { setSaving(false); }
  }

  return (
    <Sheet visible={Boolean(student)} title={student ? `ملف ${student.name}` : "ملف الطالب"} subtitle="تعديل البيانات والمواد والاشتراك" onClose={onClose}>
      <View style={styles.profileSummary}>
        <View style={styles.profileAvatar}><Text style={styles.profileAvatarText}>{student?.name.slice(0, 1)}</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.profileBalance}>{student?.remainingSessions ?? 0} حصة متبقية</Text>
          <Text style={styles.profileCaption}>{student?.completedSessions ?? 0} من {student?.totalSessions ?? 0} حصة منجزة</Text>
        </View>
      </View>
      <InputField label="الاسم" value={name} onChangeText={setName} />
      <InputField label="الصف الدراسي" value={academy} onChangeText={setAcademy} />
      <SubjectPicker options={subjectOptions} selectedIds={subjectIds} onToggle={toggleSubject} />
      <InputField label="رقم الهاتف" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
      <View style={styles.inlineFields}>
        <View style={{ flex: 1 }}><InputField label="إجمالي الحصص" value={total} onChangeText={setTotal} keyboardType="numeric" /></View>
        <View style={{ flex: 1 }}><InputField label="المتبقي" value={remaining} onChangeText={setRemaining} keyboardType="numeric" /></View>
      </View>
      <SectionHeader title="الحساب المالي الموحد" subtitle="حساب واحد للطالب مهما تعددت المواد والمجموعات" />
      <InputField label="قيمة الاشتراك الإجمالي بالجنيه" value={subscriptionAmount} onChangeText={setSubscriptionAmount} keyboardType="numeric" placeholder="0" />
      <InputField label="تاريخ الاستحقاق (اختياري)" value={subscriptionDueDate} onChangeText={setSubscriptionDueDate} placeholder="YYYY-MM-DD" />
      <View style={styles.financeMetrics}>
        <MiniFinance label="قيمة الاشتراك" value={Number(subscriptionAmount) || 0} color={COLORS.primaryDeep} background={COLORS.sage} />
        <MiniFinance label="الخصومات" value={discountAmount} color={COLORS.primaryDeep} background={COLORS.sageSoft} />
        <MiniFinance label="صافي المدفوع" value={paidAmount} color={COLORS.success} background={COLORS.successSoft} />
        <MiniFinance label="المتبقي" value={outstandingAmount} color={outstandingAmount ? COLORS.danger : COLORS.success} background={outstandingAmount ? COLORS.dangerSoft : COLORS.successSoft} />
      </View>
      <Text style={styles.inlineHint}>المتبقي = الاشتراك − الخصومات − صافي الدفعات. الحساب واحد للطالب ولا يُقسَّم حسب المادة.</Text>
      <SectionHeader title="سجل حساب الطالب" subtitle={financeHistory.length ? "آخر الحركات المالية المرتبطة بهذا الطالب" : "لا توجد حركات مالية مرتبطة بعد"} />
      {financeHistory.map(transaction => {
        const label = transaction.type === "income" ? "دفعة" : transaction.type === "refund" ? "استرداد" : transaction.type === "discount" ? "خصم" : "مصروف";
        return <View key={transaction.id} style={styles.profileSessionRow}><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{transaction.description || label}</Text><Text style={styles.rowSub}>{label} · {formatDate(transaction.transactionDate)}</Text></View><Text style={[styles.transactionAmount, { color: transaction.type === "income" ? COLORS.success : transaction.type === "discount" ? COLORS.primaryDeep : COLORS.danger }]}>{formatMoney(transaction.amount)}</Text></View>;
      })}
      <Text style={styles.fieldLabel}>حالة الملف</Text>
      <View style={styles.choiceRow}>
        <Choice label="نشط" selected={active === 1} onPress={() => setActive(1)} />
        <Choice label="موقوف" selected={active === 0} onPress={() => setActive(0)} tone="warning" />
      </View>
      <InputField label="آخر ملاحظة" value={notes} onChangeText={setNotes} placeholder="ملاحظة متابعة أو تفضيل مهم" multiline />
      <SectionHeader title="آخر الحصص" subtitle={history.length ? "سجل محفوظ محليًا" : "لا توجد حصص مسجلة بعد"} />
      {history.length ? history.map(session => (
        <View key={session.id} style={styles.profileSessionRow}>
          <View style={[styles.attendanceBadge, { backgroundColor: attendanceTone(session.attendance).background }]}>
            <Text style={[styles.attendanceText, { color: attendanceTone(session.attendance).color }]}>{session.attendance || statusLabel(session.status)}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.rowSub}>{formatDate(session.sessionDate)} · {session.startTime}</Text>
            <Text numberOfLines={1} style={styles.profileSessionNotes}>{session.notes || session.homework || "لا توجد ملاحظات"}</Text>
          </View>
        </View>
      )) : <Text style={styles.inlineHint}>أضيفي حصة من تبويب الحصص لتظهر في هذا السجل.</Text>}
      <SectionHeader title="ملخص الحضور" subtitle={`${attendancePresent} حضور/تأخير من ${attendanceCounted} سجل · معدل الحضور ${attendancePercent}%`} />
      {attendanceHistory.slice(0, 8).map(row => <View key={row.id} style={styles.profileSessionRow}><View style={[styles.attendanceBadge, { backgroundColor: attendanceTone(row.status).background }]}><Text style={[styles.attendanceText, { color: attendanceTone(row.status).color }]}>{row.status}</Text></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{row.subject || "حصة"} · {row.groupName || "فردي"}</Text><Text style={styles.rowSub}>{formatDate(row.sessionDate)}</Text></View></View>)}
      {!attendanceHistory.length ? <Text style={styles.inlineHint}>لا توجد سجلات حضور تفصيلية لهذا الطالب حتى الآن.</Text> : null}

      <SectionHeader title="الحصص السابقة" subtitle="أضيفي عددًا إجماليًا دون تواريخ، أو سجّلي كل حصة بتاريخها وحضورها" />
      <View style={styles.choiceWrap}>
        <Choice label="إضافة بالعدد" selected={historicalMode === "count"} onPress={() => setHistoricalMode("count")} />
        <Choice label="تسجيل تفصيلي بالتاريخ" selected={historicalMode === "dated"} onPress={() => setHistoricalMode("dated")} />
      </View>
      <Text style={styles.fieldLabel}>المادة</Text>
      <View style={styles.choiceWrap}>
        {subjectOptions.map(subject => <Choice key={subject.id} label={subject.nameAr} selected={historicalSubject === subject.nameAr} onPress={() => setHistoricalSubject(subject.nameAr)} />)}
      </View>
      <Text style={styles.fieldLabel}>المجموعة المرتبطة (اختياري للحصص الفردية)</Text>
      <View style={styles.choiceWrap}>
        <Choice label="فردي" selected={historicalGroupId === null} onPress={() => setHistoricalGroupId(null)} />
        {groups.map(group => <Choice key={group.id} label={group.name} selected={historicalGroupId === group.id} onPress={() => { setHistoricalGroupId(group.id); if (group.subject) setHistoricalSubject(group.subject); }} />)}
      </View>
      {historicalMode === "count" ? (
        <>
          <InputField label="عدد الحصص السابقة" value={historicalCount} onChangeText={setHistoricalCount} keyboardType="numeric" placeholder="مثال: 12" />
          <Text style={styles.inlineHint}>سيُحفظ العدد كرصيد حصص سابق غير مؤرخ، ولن تُنشأ تواريخ افتراضية أو سجلات حضور مزيفة.</Text>
        </>
      ) : (
        <>
          <InputField label="تاريخ الحصة" value={historicalDate} onChangeText={setHistoricalDate} placeholder="YYYY-MM-DD" />
          <Text style={styles.fieldLabel}>حالة الحضور</Text>
          <View style={styles.choiceWrap}>
            {(["حاضر", "غائب", "معذور", "متأخر"] as const).map(status => <Choice key={status} label={status} selected={historicalAttendance === status} onPress={() => setHistoricalAttendance(status)} />)}
          </View>
          <InputField label="الواجب (اختياري)" value={historicalHomework} onChangeText={setHistoricalHomework} placeholder="الواجب المرتبط بالحصة" />
          <InputField label="ملاحظات (اختياري)" value={historicalNotes} onChangeText={setHistoricalNotes} placeholder="أي تفاصيل عن الحصة" multiline />
        </>
      )}
      <AppButton title={profileBusy ? "جارٍ الحفظ..." : historicalMode === "count" ? "إضافة عدد الحصص السابقة" : "حفظ الحصة بتاريخها"} icon="history" onPress={() => void addHistoricalSession()} disabled={profileBusy} tone="soft" />
      <Text style={styles.inlineHint}>إجمالي الحصص السابقة المسجلة: {historicalSessions.reduce((sum, row) => sum + row.sessionCount, 0)} حصة.</Text>
      {historicalSessions.map(row => <View key={row.id} style={styles.profileSessionRow}><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{row.subject} · {row.groupName || "فردي"}</Text><Text style={styles.rowSub}>{row.entryType === "count" ? `${row.sessionCount} حصة سابقة دون تواريخ` : `${row.sessionDate} · ${row.attendance || "الحضور غير محدد"}`}</Text>{row.homework ? <Text style={styles.profileSessionNotes}>الواجب: {row.homework}</Text> : null}{row.notes ? <Text style={styles.profileSessionNotes}>{row.notes}</Text> : null}</View><IconButton label="حذف سجل الحصة السابقة" icon="delete-outline" tone="danger" onPress={() => Alert.alert("حذف سجل الحصة السابقة", "سيتم خصم هذا السجل من عدد الحصص المنجزة وإعادة حصصه إلى الرصيد المتبقي. هل تريدين المتابعة؟", [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => { void deleteHistoricalSessionRecord(row.id).then(async () => { await refreshAcademicProfile(student!.id); await syncStudentSessionCounters(); }).catch(error => Alert.alert("تعذر الحذف", error instanceof Error ? error.message : "حاولي مرة أخرى.")); } }])} /></View>)}
      {!historicalSessions.length ? <Text style={styles.inlineHint}>لم تتم إضافة حصص سابقة لهذا الطالب بعد.</Text> : null}

      <SectionHeader title="سجل الاختبارات والدرجات" subtitle={`${examHistory.length} نتيجة مسجلة · المتوسط الموزون ${examPercent}% (${examEarned}/${examPossible})`} />
      {examHistory.slice(0, 10).map(row => <View key={row.id} style={styles.profileSessionRow}><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{row.examTitle}</Text><Text style={styles.rowSub}>{row.subject} · {row.lesson} · {row.examDate ? formatDate(row.examDate) : formatDate(row.gradedAt.slice(0, 10))}</Text>{row.feedback ? <Text style={styles.profileSessionNotes}>{row.feedback}</Text> : null}</View><Text style={styles.profileBalance}>{row.score}/{row.examTotalMarks}</Text></View>)}
      {!examHistory.length ? <Text style={styles.inlineHint}>ستظهر نتائج الاختبارات هنا بعد تسجيل الدرجات.</Text> : null}

      <SectionHeader title="الواجبات والمتابعة" subtitle={`${homeworkDone} من ${homeworkItems.length} واجب مكتمل · سجل مستقل للطالب`} />
      <InputField label="المادة" value={homeworkSubject} onChangeText={setHomeworkSubject} placeholder="مثال: Biology" />
      <InputField label="الدرس" value={homeworkLesson} onChangeText={setHomeworkLesson} placeholder="اسم الدرس" />
      <InputField label="الواجب" value={homeworkDescription} onChangeText={setHomeworkDescription} placeholder="تفاصيل المطلوب" multiline />
      <InputField label="موعد التسليم (اختياري)" value={homeworkDueDate} onChangeText={setHomeworkDueDate} placeholder="YYYY-MM-DD" />
      <AppButton title={profileBusy ? "جارٍ الحفظ..." : "إضافة الواجب"} icon="add-task" onPress={() => void addHomework()} disabled={profileBusy} tone="soft" />
      {homeworkItems.map(item => <View key={item.id} style={styles.card}><Text style={styles.rowTitle}>{item.subject} · {item.lesson}</Text><Text style={styles.profileSessionNotes}>{item.description}</Text><Text style={styles.rowSub}>التسليم: {item.dueDate || "غير محدد"} · {item.status === "done" ? "تم" : item.status === "late" ? "متأخر" : "قيد التنفيذ"}</Text><View style={styles.choiceWrap}><Choice label="قيد التنفيذ" selected={item.status === "pending"} onPress={() => void changeHomeworkStatus(item, "pending")} /><Choice label="تم" selected={item.status === "done"} onPress={() => void changeHomeworkStatus(item, "done")} /><Choice label="متأخر" selected={item.status === "late"} onPress={() => void changeHomeworkStatus(item, "late")} tone="warning" /><Choice label="حذف" selected={false} onPress={() => Alert.alert("حذف الواجب", "هل تريدين حذف هذا الواجب؟", [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => { void deleteStudentHomework(item.id).then(() => student && refreshAcademicProfile(student.id)); } }])} tone="danger" /></View></View>)}
      {!homeworkItems.length ? <Text style={styles.inlineHint}>لم تتم إضافة واجبات لهذا الطالب بعد.</Text> : null}

      <SectionHeader title="ملاحظات المعلمة" subtitle="ملاحظات تعليمية وسلوكية خاصة بالمتابعة" />
      <InputField label="المادة (اختياري)" value={noteSubject} onChangeText={setNoteSubject} placeholder="المادة المرتبطة بالملاحظة" />
      <InputField label="عنوان الملاحظة" value={noteTitle} onChangeText={setNoteTitle} placeholder="مثال: يحتاج إلى مراجعة أساسيات الوراثة" />
      <InputField label="تفاصيل الملاحظة" value={noteBody} onChangeText={setNoteBody} placeholder="اكتبي الملاحظة أو خطة التحسين" multiline />
      <AppButton title="حفظ الملاحظة" icon="note-add" onPress={() => void addAcademicNote()} disabled={profileBusy} tone="soft" />
      {academicNotes.map(item => <View key={item.id} style={styles.profileSessionRow}><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.rowSub}>{item.subject || "عام"} · {formatDate(item.createdAt.slice(0, 10))}</Text><Text style={styles.profileSessionNotes}>{item.body}</Text></View><Pressable onPress={() => Alert.alert("حذف الملاحظة", "هل تريدين حذف هذه الملاحظة؟", [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => { void deleteStudentAcademicNote(item.id).then(() => student && refreshAcademicProfile(student.id)); } }])}><MaterialIcons name="delete-outline" size={21} color={COLORS.danger} /></Pressable></View>)}
      {!academicNotes.length ? <Text style={styles.inlineHint}>لا توجد ملاحظات أكاديمية مسجلة بعد.</Text> : null}

      <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ التعديلات"} icon="save" onPress={save} disabled={saving} />
    </Sheet>
  );
}

function SessionsScreen({ sessions, timetable, onOpen, onStart, onComplete, onEdit, onReport, onDelete, onEditSlot, onToggleSlot, onDeleteSlot }: { sessions: LessonSession[]; timetable: TimetableSlot[]; onOpen: (kind: "session" | "timetable") => void; onStart: (session: LessonSession) => void; onComplete: (session: LessonSession) => void; onEdit: (session: LessonSession) => void; onReport: (session: LessonSession) => void; onDelete: (session: LessonSession) => void; onEditSlot: (slot: TimetableSlot) => void; onToggleSlot: (slot: TimetableSlot) => void; onDeleteSlot: (slot: TimetableSlot) => void }) {
  const [mode, setMode] = useState<"today" | "history" | "timetable">("today");
  const today = todayDate();
  const todaySessions = sessions.filter(session => session.sessionDate === today).sort((a, b) => a.startTime.localeCompare(b.startTime));
  const filtered = mode === "today" ? todaySessions : sessions;
  const todayName = WEEKDAY_NAMES[new Date(`${today}T12:00:00`).getDay()];
  const listData: Array<LessonSession | string> = mode === "timetable" ? DAYS : filtered;
  return (
    <FlatList
      data={listData}
      keyExtractor={item => typeof item === "string" ? item : String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <>
          <SectionHeader title="الحصص والجدول" subtitle="جدول أسبوعي واضح، وحصص اليوم تُنشأ تلقائيًا" action={<AppButton title={mode === "timetable" ? "موعد أسبوعي" : "حصة"} icon="add" onPress={() => onOpen(mode === "timetable" ? "timetable" : "session")} compact />} />
          <View style={styles.segmented}>
            <Choice label="اليوم" selected={mode === "today"} onPress={() => setMode("today")} />
            <Choice label="السجل" selected={mode === "history"} onPress={() => setMode("history")} />
            <Choice label="الجدول الأسبوعي" selected={mode === "timetable"} onPress={() => setMode("timetable")} />
          </View>
          {mode === "timetable" ? <View style={styles.timetableHint}><MaterialIcons name="autorenew" size={18} color={COLORS.primaryDeep} /><Text style={styles.timetableHintText}>كل موعد نشط يتكرر تلقائيًا في يومه، وتُضاف حصة اليوم مرة واحدة فقط.</Text></View> : null}
          {mode === "today" ? <Text style={styles.todaySectionLabel}>{todayName} · {formatDate(today)}</Text> : null}
        </>
      }
      ListEmptyComponent={<EmptyState icon="event-note" title="لا توجد حصص هنا" body={mode === "today" ? "أضيفي مواعيد أسبوعية من تبويب الجدول الأسبوعي لتظهر حصص اليوم تلقائيًا." : "لا توجد حصص مسجلة في السجل بعد."} />}
      ItemSeparatorComponent={() => <View style={{ height: 9 }} />}
      renderItem={(info: ListRenderItemInfo<LessonSession | string>) => {
        if (mode === "timetable") {
          const day = info.item as string;
          const daySlots = timetable.filter(slot => slot.dayOfWeek === day).sort((a, b) => a.startTime.localeCompare(b.startTime));
          const isToday = day === todayName;
          return (
            <View style={[styles.timetableDayCard, isToday && styles.timetableDayCardToday]}>
              <View style={styles.timetableDayHeader}>
                <View style={[styles.timetableDayDot, isToday && styles.timetableDayDotToday]} />
                <Text style={styles.timetableDayTitle}>{day}</Text>
                {isToday ? <Text style={styles.timetableTodayBadge}>اليوم</Text> : null}
                <Text style={styles.timetableDayCount}>{daySlots.filter(slot => slot.active).length} مواعيد نشطة</Text>
              </View>
              {daySlots.length ? daySlots.map(slot => (
                <View key={slot.id} style={[styles.slotCard, !slot.active && styles.slotCardPaused]}>
                  <View style={styles.slotIcon}><MaterialIcons name={slot.active ? "event-repeat" : "pause-circle-outline"} size={20} color={slot.active ? COLORS.primaryDeep : COLORS.muted} /></View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.rowTitle}>{slot.title}</Text>
                    <Text style={styles.rowSub}>{formatTime(slot.startTime)} · {slot.durationMinutes} دقيقة · {slot.groupId ? "مجموعة" : "حصة فردية"}</Text>
                    {slot.subject ? <Text style={styles.remainingText}>{slot.subject}</Text> : null}
                    {!slot.active ? <Text style={styles.pausedText}>موقوف — لن تُنشأ منه حصص تلقائية</Text> : null}
                  </View>
                  <View style={styles.slotActions}>
                    <IconButton label="تعديل الموعد الأسبوعي" icon="edit" onPress={() => onEditSlot(slot)} />
                    <IconButton label={slot.active ? "إيقاف الموعد" : "تفعيل الموعد"} icon={slot.active ? "pause" : "play-arrow"} onPress={() => onToggleSlot(slot)} />
                    <IconButton label="حذف الموعد الأسبوعي" icon="delete-outline" onPress={() => onDeleteSlot(slot)} tone="danger" />
                  </View>
                </View>
              )) : <Text style={styles.timetableDayEmpty}>لا توجد حصص مجدولة في هذا اليوم.</Text>}
            </View>
          );
        }
        const session = info.item as LessonSession;
        return <SessionCard session={session} onStart={() => onStart(session)} onComplete={() => onComplete(session)} onEdit={() => onEdit(session)} onReport={session.status === "completed" ? () => onReport(session) : undefined} onDelete={() => onDelete(session)} />;
      }}
    />
  );
}

function GroupsScreen({ groups, onAdd, onOpen, onDelete }: { groups: TutoringGroup[]; onAdd: () => void; onOpen: (group: TutoringGroup) => void; onDelete: (group: TutoringGroup) => void }) {
  return (
    <FlatList
      data={groups}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={<SectionHeader title="المجموعات" subtitle={`النشطة: ${groups.filter(group => group.active !== 0).length} · المؤرشفة: ${groups.filter(group => group.active === 0).length}`} action={<AppButton title="مجموعة" icon="group-add" onPress={onAdd} compact />} />}
      ListEmptyComponent={<EmptyState icon="groups" title="لا توجد مجموعات" body="أنشئي مجموعة وحددي السعة والاشتراك والحصص." action={<AppButton title="إنشاء مجموعة" icon="add" onPress={onAdd} compact />} />}
      renderItem={({ item }) => (
        <View style={styles.groupCard}>
          <View style={styles.groupTop}><Pressable accessibilityRole="button" accessibilityLabel={`فتح تفاصيل ${item.name}`} onPress={() => onOpen(item)} style={({ pressed }) => [styles.groupPressTarget, pressed && { opacity: 0.7 }]}><View style={styles.groupIcon}><MaterialIcons name="groups" size={22} color={COLORS.primaryDeep} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.name}</Text><Text style={styles.rowSub}>{[item.academy, item.subject, item.active === 0 ? "مؤرشفة" : null].filter(Boolean).join(" · ") || "تفاصيل المادة غير محددة"}</Text></View></Pressable><IconButton label={item.active === 0 ? `إعادة تفعيل ${item.name}` : `أرشفة ${item.name}`} icon={item.active === 0 ? "unarchive" : "archive"} onPress={() => onDelete(item)} tone={item.active === 0 ? "default" : "danger"} /></View>
          <View style={styles.groupStats}><View><Text style={styles.groupStatValue}>{item.totalSessions}</Text><Text style={styles.groupStatLabel}>الإجمالي</Text></View><View><Text style={styles.groupStatValue}>{item.completedSessions}</Text><Text style={styles.groupStatLabel}>المنجزة</Text></View><View><Text style={styles.groupStatValue}>{item.remainingSessions}</Text><Text style={styles.groupStatLabel}>المتبقي</Text></View><View><Text style={styles.groupStatValue}>{item.capacity}</Text><Text style={styles.groupStatLabel}>السعة</Text></View></View>
          <View style={styles.memberStrip}><MaterialIcons name="people-alt" size={16} color={COLORS.muted} /><Text style={styles.memberText}>{item.memberCount ?? 0} طالب مسجل فعليًا{item.memberNames ? " · توجد أسماء قديمة تحتاج مراجعة داخل المجموعة" : ""}</Text></View>
        </View>
      )}
    />
  );
}

function FinanceScreen({ transactions, students, onOpen, onOpenStudent, onDelete }: { transactions: FinanceTransaction[]; students: Student[]; onOpen: () => void; onOpenStudent: (student: Student) => void; onDelete: (transaction: FinanceTransaction) => void }) {
  const [monthOffset, setMonthOffset] = useState(0);
  const monthDate = useMemo(() => { const date = new Date(); date.setDate(1); date.setMonth(date.getMonth() + monthOffset); return date; }, [monthOffset]);
  const monthKey = `${monthDate.getFullYear()}-${String(monthDate.getMonth() + 1).padStart(2, "0")}`;
  const monthLabel = new Intl.DateTimeFormat("ar-EG-u-ca-gregory", { month: "long", year: "numeric" }).format(monthDate);
  const monthTransactions = useMemo(() => transactions.filter(transaction => transaction.transactionDate?.startsWith(monthKey)), [transactions, monthKey]);
  const todayTransactions = useMemo(() => transactions.filter(transaction => transaction.transactionDate === todayDate()), [transactions]);
  const dailyIncome = todayTransactions.filter(transaction => transaction.type === "income").reduce((sum, transaction) => sum + transaction.amount, 0);
  const dailyExpense = todayTransactions.filter(transaction => transaction.type === "expense").reduce((sum, transaction) => sum + transaction.amount, 0);
  const lifetimeNet = transactions.reduce((sum, transaction) => sum + (transaction.type === "income" ? transaction.amount : transaction.type === "expense" || transaction.type === "refund" ? -transaction.amount : 0), 0);
  const summary = useMemo(() => {
    const values = { income: 0, expense: 0, refund: 0, discount: 0 };
    monthTransactions.forEach(transaction => { values[transaction.type] += transaction.amount; });
    return { ...values, net: values.income - values.expense - values.refund };
  }, [monthTransactions]);
  const studentAccounts = useMemo(() => students.map(student => {
    const entries = transactions.filter(transaction => transaction.studentId === student.id);
    const paid = entries.reduce((sum, transaction) => sum + (transaction.type === "income" ? transaction.amount : transaction.type === "refund" ? -transaction.amount : 0), 0);
    const discount = entries.filter(transaction => transaction.type === "discount").reduce((sum, transaction) => sum + transaction.amount, 0);
    const outstanding = Math.max(0, (student.subscriptionAmount ?? 0) - discount - paid);
    const overdue = outstanding > 0 && Boolean(student.subscriptionDueDate) && student.subscriptionDueDate! < todayDate();
    return { student, paid, discount, outstanding, overdue };
  }).filter(account => (account.student.subscriptionAmount ?? 0) > 0 || account.paid > 0 || account.discount > 0), [students, transactions]);
  const receivables = studentAccounts.reduce((sum, account) => sum + account.outstanding, 0);
  const overdueAccounts = studentAccounts.filter(account => account.overdue);
  return (
    <FlatList
      data={monthTransactions}
      keyExtractor={item => String(item.id)}
      contentContainerStyle={styles.listContent}
      ListHeaderComponent={
        <>
          <SectionHeader title="المالية" subtitle="تقارير التحصيل والتدفق النقدي والحساب الموحد لكل طالب" action={<AppButton title="حركة" icon="add-card" onPress={onOpen} compact />} />
          <View style={styles.financeNetCard}><Text style={styles.financeNetLabel}>صافي التدفق النقدي · {monthLabel}</Text><Text style={styles.financeNetValue}>{formatMoney(summary.net)}</Text><Text style={styles.financeNetFoot}>الإيرادات − المصروفات − الاستردادات · الخصومات ليست تدفقًا نقديًا</Text></View>
          <View style={styles.monthPickerRow}>
            <Pressable accessibilityRole="button" accessibilityLabel="الشهر التالي" onPress={() => setMonthOffset(value => value + 1)} style={styles.monthArrow}><MaterialIcons name="chevron-right" size={25} color={COLORS.primaryDeep} /></Pressable>
            <Text style={styles.monthPickerLabel}>{monthLabel}</Text>
            <Pressable accessibilityRole="button" accessibilityLabel="الشهر السابق" onPress={() => setMonthOffset(value => value - 1)} style={styles.monthArrow}><MaterialIcons name="chevron-left" size={25} color={COLORS.primaryDeep} /></Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel="الشهر الحالي" onPress={() => setMonthOffset(0)} style={styles.monthToday}><Text style={styles.monthTodayText}>هذا الشهر</Text></Pressable>
          </View>
          <View style={styles.financeMetrics}><MiniFinance label="إيرادات الشهر" value={summary.income} color={COLORS.success} background={COLORS.successSoft} /><MiniFinance label="مصروفات الشهر" value={summary.expense} color={COLORS.warning} background={COLORS.warningSoft} /><MiniFinance label="استردادات الشهر" value={summary.refund} color={COLORS.danger} background={COLORS.dangerSoft} /><MiniFinance label="خصومات الشهر" value={summary.discount} color={COLORS.primaryDeep} background={COLORS.sage} /></View>
          <SectionHeader title="ملخص اليوم" subtitle={`${todayTransactions.length} حركة مسجلة اليوم`} />
          <View style={styles.financeMetrics}><MiniFinance label="تحصيل اليوم" value={dailyIncome} color={COLORS.success} background={COLORS.successSoft} /><MiniFinance label="مصروفات اليوم" value={dailyExpense} color={COLORS.warning} background={COLORS.warningSoft} /></View>
          <SectionHeader title="ملخص التحصيل" subtitle="الأرقام محسوبة من حسابات الطلاب والحركات المرتبطة بهم" />
          <View style={styles.financeMetrics}><MiniFinance label="إجمالي المستحقات المتبقية" value={receivables} color={COLORS.danger} background={COLORS.dangerSoft} /><MiniFinance label="حسابات متأخرة" value={overdueAccounts.length} color={COLORS.warning} background={COLORS.warningSoft} /><MiniFinance label="صافي التدفق منذ البداية" value={lifetimeNet} color={COLORS.primaryDeep} background={COLORS.sage} /></View>
          <SectionHeader title="الطلاب المطلوب متابعتهم" subtitle="مرتبة بحيث تظهر الحسابات المتأخرة أولًا" />
          {studentAccounts.filter(account => account.outstanding > 0).sort((a, b) => Number(b.overdue) - Number(a.overdue) || b.outstanding - a.outstanding).map(({ student, paid, discount, outstanding, overdue }) =>
            <Pressable key={student.id} onPress={() => onOpenStudent(student)} style={({ pressed }) => [styles.followUpRow, pressed && { opacity: 0.75 }]}>
              <View style={styles.avatar}><Text style={styles.avatarText}>{student.name.slice(0, 1)}</Text></View>
              <View style={{ flex: 1 }}><Text style={styles.rowTitle}>{student.name}</Text><Text style={styles.rowSub}>المستحق: {formatMoney(student.subscriptionAmount ?? 0)} · الخصم: {formatMoney(discount)}</Text><Text style={styles.rowSub}>صافي المدفوع: {formatMoney(paid)}</Text>{student.subscriptionDueDate ? <Text style={[styles.rowSub, overdue && { color: COLORS.danger, fontWeight: "800" }]}>{overdue ? "متأخر عن السداد · " : "الاستحقاق: "}{student.subscriptionDueDate}</Text> : null}</View>
              <View style={{ alignItems: "flex-end" }}><Text style={[styles.transactionAmount, { color: overdue ? COLORS.danger : COLORS.warning }]}>{formatMoney(outstanding)}</Text><Text style={styles.deleteText}>{overdue ? "متأخر" : "متبقي"}</Text></View>
            </Pressable>
          )}
          <SectionHeader title={`حركات ${monthLabel}`} subtitle={`${monthTransactions.length} حركة مسجلة خلال الشهر`} />
        </>
      }
      ListEmptyComponent={<EmptyState icon="receipt-long" title="لا توجد حركات في هذا الشهر" body="يمكنك الانتقال لشهر آخر أو تسجيل حركة مالية جديدة." />}
      renderItem={({ item }) => <TransactionRow transaction={item} onDelete={() => onDelete(item)} />}
    />
  );
}

function MiniFinance({ label, value, color, background }: { label: string; value: number; color: string; background: string }) {
  return <View style={[styles.miniFinance, { backgroundColor: background }]}><Text style={[styles.miniFinanceValue, { color }]}>{formatMoney(value)}</Text><Text style={[styles.miniFinanceLabel, { color }]}>{label}</Text></View>;
}

function TransactionRow({ transaction, onDelete }: { transaction: FinanceTransaction; onDelete: () => void }) {
  const details: Record<TransactionType, { label: string; icon: IconName; color: string; background: string }> = {
    income: { label: "إيراد", icon: "south-west", color: COLORS.success, background: COLORS.successSoft },
    expense: { label: "مصروف", icon: "north-east", color: COLORS.warning, background: COLORS.warningSoft },
    refund: { label: "استرداد", icon: "undo", color: COLORS.danger, background: COLORS.dangerSoft },
    discount: { label: "خصم", icon: "sell", color: COLORS.primaryDeep, background: COLORS.sage },
  };
  const detail = details[transaction.type];
  return <View style={styles.transactionRow}><View style={[styles.transactionIcon, { backgroundColor: detail.background }]}><MaterialIcons name={detail.icon} size={19} color={detail.color} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{transaction.description || detail.label}</Text><Text style={styles.rowSub}>{detail.label} · {formatDate(transaction.transactionDate)}{transaction.studentName ? ` · ${transaction.studentName}` : ""}</Text></View><View style={{ alignItems: "flex-end", gap: 8 }}><Text style={[styles.transactionAmount, { color: detail.color }]}>{formatMoney(transaction.amount)}</Text><Pressable accessibilityRole="button" accessibilityLabel="حذف الحركة" onPress={onDelete}><Text style={styles.deleteText}>حذف</Text></Pressable></View></View>;
}

function SettingsScreen({ onReload }: { onReload: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  async function backup() {
    try {
      setBusy(true);
      await shareLocalBackup();
      Alert.alert("تم إنشاء النسخة", "احفظي ملف JSON في مكان آمن على هاتفك.");
    } catch (error) {
      Alert.alert("تعذر إنشاء النسخة", error instanceof Error ? error.message : "حدث خطأ غير متوقع");
    } finally { setBusy(false); }
  }
  async function restore() {
    try {
      setBusy(true);
      const result = await chooseAndRestoreBackup();
      if (!result.canceled) {
        await onReload();
        Alert.alert("تم الاستيراد", result.source === "legacy" ? `تمت إضافة ${result.imported} طالبة من نسخة الموقع القديمة.` : `تمت استعادة ${result.imported} طالبة وبيانات التطبيق والملفات التعليمية.`);
      }
    } catch (error) {
      Alert.alert("تعذر الاستيراد", error instanceof Error ? error.message : "حدث خطأ غير متوقع");
    } finally { setBusy(false); }
  }
  const items = [
    { title: "تصدير نسخة احتياطية كاملة", body: "تشمل الطلاب والحصص والمالية والملفات التعليمية الفعلية.", icon: "upload-file" as IconName, action: backup },
    { title: "استيراد نسخة احتياطية", body: "يحفظ نسخة أمان تلقائية قبل الاستعادة، ويدعم النسخ القديمة.", icon: "download" as IconName, action: restore },
  ];
  return <FlatList data={items} keyExtractor={item => item.title} contentContainerStyle={styles.listContent} ListHeaderComponent={<><SectionHeader title="الإعدادات والبيانات" subtitle="لا يتم فتح الموقع أو تضمينه داخل التطبيق." /><View style={styles.localPrivacyCard}><MaterialIcons name="phonelink-lock" size={25} color={COLORS.primaryDeep} /><View style={{ flex: 1 }}><Text style={styles.localPrivacyTitle}>بياناتك على جهازك</Text><Text style={styles.localPrivacyBody}>الطلاب والحصص والمالية محفوظة في قاعدة بيانات محلية داخل Android. استخدمي النسخ الاحتياطي عند تغيير الهاتف.</Text></View></View><SectionHeader title="النسخ والنقل" /></>} renderItem={({ item }) => <Pressable accessibilityRole="button" accessibilityLabel={item.title} disabled={busy} onPress={item.action} style={({ pressed }) => [styles.settingsRow, pressed && { opacity: 0.75 }, busy && { opacity: 0.45 }]}><View style={styles.settingsIcon}><MaterialIcons name={item.icon} size={22} color={COLORS.primaryDeep} /></View><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.rowSub}>{item.body}</Text></View><MaterialIcons name="chevron-left" size={22} color={COLORS.muted} /></Pressable>} ListFooterComponent={<View style={styles.aboutCard}><Text style={styles.aboutTitle}>Naneice Desk Native</Text><Text style={styles.aboutText}>إصدار Android محلي أولًا. لا يعتمد على WebView ولا يفتح واجهة الموقع.</Text><Text style={styles.aboutText}>التاريخ ظاهر بالتقويم الميلادي العربي.</Text></View>} />;
}

function SubjectPicker({ options, selectedIds, onToggle, multiple = true }: {
  options: AcademySubject[];
  selectedIds: string[];
  onToggle: (subjectId: string) => void;
  multiple?: boolean;
}) {
  return (
    <View style={{ gap: 8 }}>
      <Text style={styles.fieldLabel}>{multiple ? "المواد الدراسية" : "مادة المجموعة"}</Text>
      <View style={styles.choiceWrap}>
        {options.map(subject => (
          <Choice
            key={subject.id}
            label={`${subject.nameAr} · ${subject.nameEn}`}
            selected={selectedIds.includes(subject.id)}
            onPress={() => onToggle(subject.id)}
          />
        ))}
      </View>
      {multiple ? <Text style={styles.inlineHint}>يمكن اختيار أكثر من مادة للطالب.</Text> : null}
    </View>
  );
}

function StudentSheet({ visible, onClose, onSaved, subjectOptions }: {
  visible: boolean;
  onClose: () => void;
  onSaved: () => Promise<void>;
  subjectOptions: AcademySubject[];
}) {
  const [name, setName] = useState("");
  const [academy, setAcademy] = useState("");
  const [subjectIds, setSubjectIds] = useState<string[]>([]);
  const [phone, setPhone] = useState("");
  const [total, setTotal] = useState("0");
  const [subscriptionAmount, setSubscriptionAmount] = useState("0");
  const [subscriptionDueDate, setSubscriptionDueDate] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (visible) {
      setName(""); setAcademy(""); setSubjectIds([]); setPhone(""); setTotal("0"); setSubscriptionAmount("0"); setSubscriptionDueDate("");
    }
  }, [visible]);

  function toggleSubject(subjectId: string) {
    setSubjectIds(current => current.includes(subjectId)
      ? current.filter(id => id !== subjectId)
      : [...current, subjectId]);
  }

  async function save() {
    if (!name.trim()) return Alert.alert("الاسم مطلوب", "اكتبي اسم الطالب أولًا.");
    if (!subjectIds.length) return Alert.alert("اختاري المادة", "اختاري مادة واحدة على الأقل للطالب.");
    const firstSubject = subjectOptions.find(item => item.id === subjectIds[0]);
    try {
      setSaving(true);
      await createStudent({
        name, academy, subject: firstSubject?.nameAr ?? null, subjectIds, phone,
        totalSessions: Number(total) || 0, remainingSessions: Number(total) || 0,
        subscriptionAmount: Math.max(0, Number(subscriptionAmount) || 0), subscriptionDueDate: subscriptionDueDate.trim() || null
      });
      await onSaved();
      onClose();
    } catch (error) {
      Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى.");
    } finally { setSaving(false); }
  }

  return (
    <Sheet visible={visible} title="إضافة طالب" subtitle="بيانات الطالب والمواد التي يدرسها" onClose={onClose}>
      <InputField label="اسم الطالب *" value={name} onChangeText={setName} placeholder="مثال: محمد أحمد" />
      <InputField label="الصف أو الأكاديمية" value={academy} onChangeText={setAcademy} placeholder="مثال: الصف الثاني الثانوي" />
      <SubjectPicker options={subjectOptions} selectedIds={subjectIds} onToggle={toggleSubject} />
      <InputField label="رقم الهاتف" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="01..." />
      <SectionHeader title="الحساب المالي الموحد" subtitle="قيمة واحدة للطالب مهما تعددت المواد" />
      <InputField label="قيمة الاشتراك الإجمالي بالجنيه" value={subscriptionAmount} onChangeText={setSubscriptionAmount} keyboardType="numeric" placeholder="0" />
      <InputField label="تاريخ الاستحقاق (اختياري)" value={subscriptionDueDate} onChangeText={setSubscriptionDueDate} placeholder="YYYY-MM-DD" />
      <InputField label="عدد حصص الاشتراك (للتسجيل القديم)" value={total} onChangeText={setTotal} keyboardType="numeric" />
      <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ الطالب"} icon="check" onPress={save} disabled={saving} />
    </Sheet>
  );
}

function GroupSheet({ visible, onClose, onSaved, subjectOptions }: {
  visible: boolean;
  onClose: () => void;
  onSaved: () => Promise<void>;
  subjectOptions: AcademySubject[];
}) {
  const [name, setName] = useState("");
  const [academy, setAcademy] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [capacity, setCapacity] = useState("12");
  const [total, setTotal] = useState("0");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (visible) {
      setName(""); setAcademy(""); setSubjectId(subjectOptions[0]?.id ?? ""); setCapacity("12"); setTotal("0");
    }
  }, [visible, subjectOptions]);

  async function save() {
    if (!name.trim()) return Alert.alert("اسم المجموعة مطلوب", "اكتبي اسم المجموعة أولًا.");
    const subject = subjectOptions.find(item => item.id === subjectId);
    if (!subject) return Alert.alert("المادة مطلوبة", "اختاري المادة التي ستدرسها هذه المجموعة.");
    try {
      setSaving(true);
      await createGroup({
        name, academy, subject: subject.nameAr, capacity: Math.max(1, Number(capacity) || 1),
        totalSessions: Number(total) || 0, remainingSessions: Number(total) || 0,
        memberNames: null
      });
      await onSaved();
      onClose();
    } catch (error) {
      Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى.");
    } finally { setSaving(false); }
  }

  return (
    <Sheet visible={visible} title="إنشاء مجموعة" subtitle="كل مجموعة مخصصة لمادة واحدة" onClose={onClose}>
      <InputField label="اسم المجموعة *" value={name} onChangeText={setName} placeholder="مثال: أحياء الصف الثاني الثانوي A" />
      <InputField label="الصف الدراسي" value={academy} onChangeText={setAcademy} placeholder="مثال: الصف الثاني الثانوي" />
      <SubjectPicker options={subjectOptions} selectedIds={subjectId ? [subjectId] : []} onToggle={setSubjectId} multiple={false} />
      <InputField label="السعة القصوى للطلاب" value={capacity} onChangeText={setCapacity} keyboardType="numeric" />
      <InputField label="إجمالي حصص المجموعة" value={total} onChangeText={setTotal} keyboardType="numeric" />
      <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ المجموعة"} icon="check" onPress={save} disabled={saving} />
    </Sheet>
  );
}

function GroupDetailSheet({ group, students, subjectOptions, onClose, onSaved, onShareReport, onShareStudentReport }: {
  group: TutoringGroup | null;
  students: Student[];
  subjectOptions: AcademySubject[];
  onClose: () => void;
  onSaved: () => Promise<void>;
  onShareReport: (session: LessonSession) => Promise<void>;
  onShareStudentReport: (session: LessonSession, recipient: { studentId: number; name: string; phone: string | null }) => void;
}) {
  const [name, setName] = useState("");
  const [academy, setAcademy] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [capacity, setCapacity] = useState("12");
  const [total, setTotal] = useState("0");
  const [remaining, setRemaining] = useState("0");
  const [notes, setNotes] = useState("");
  const [members, setMembers] = useState<Array<{ enrollmentId: number; studentId: number; name: string; phone: string | null; subjectId: string; startDate: string }>>([]);
  const [groupSessions, setGroupSessions] = useState<LessonSession[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const selectedSubject = subjectOptions.find(item => item.id === subjectId);
  const originalSubjectId = group ? subjectOptions.find(item => item.nameAr === group.subject || item.nameEn === group.subject)?.id ?? "" : "";
  const subjectChangedWithMembers = members.length > 0 && originalSubjectId !== subjectId;

  async function loadMembers(groupId: number) {
    setMembers(await listGroupMembers(groupId));
  }

  async function loadGroupReports(groupId: number) {
    setGroupSessions(await listGroupSessions(groupId));
  }

  useEffect(() => {
    if (!group) return;
    setName(group.name);
    setAcademy(group.academy || "");
    setSubjectId(subjectOptions.find(item => item.nameAr === group.subject || item.nameEn === group.subject)?.id ?? "");
    setCapacity(String(group.capacity));
    setTotal(String(group.totalSessions));
    setRemaining(String(group.remainingSessions));
    setNotes(group.notes || "");
    setSelectedStudentId(null);
    void Promise.all([loadMembers(group.id), loadGroupReports(group.id)]);
  }, [group?.id]);

  const eligibleStudents = students.filter(student =>
    student.active && !members.some(member => member.studentId === student.id)
  );
  const completedGroupSessions = groupSessions.filter(session => session.status === "completed");

  async function addMember() {
    if (!group || !selectedStudentId) return Alert.alert("اختاري الطالب", "حددي الطالب الذي تريدين إضافته.");
    try {
      await enrollStudentInGroup(selectedStudentId, group.id);
      await loadMembers(group.id);
      await onSaved();
      setSelectedStudentId(null);
      Alert.alert("تمت الإضافة", "تم تسجيل الطالب في المجموعة لهذه المادة.");
    } catch (error) {
      Alert.alert("تعذر تسجيل الطالب", error instanceof Error ? error.message : "حاولي مرة أخرى.");
    }
  }

  async function removeMember(enrollmentId: number) {
    if (!group) return;
    Alert.alert("إنهاء تسجيل الطالب", "سيتم إنهاء عضوية الطالب في هذه المجموعة مع الاحتفاظ بسجل التسجيل.", [
      { text: "إلغاء", style: "cancel" },
      { text: "إنهاء التسجيل", style: "destructive", onPress: () => {
        void endGroupEnrollment(enrollmentId).then(async () => {
          await loadMembers(group.id);
          await onSaved();
        }).catch(error => Alert.alert("تعذر إنهاء التسجيل", error instanceof Error ? error.message : "حاولي مرة أخرى."));
      }}
    ]);
  }

  async function save() {
    if (!group || !name.trim()) return Alert.alert("اسم المجموعة مطلوب", "اكتبي اسم المجموعة أولًا.");
    if (!selectedSubject) return Alert.alert("المادة مطلوبة", "اختاري مادة صحيحة للمجموعة.");
    if (subjectChangedWithMembers) return Alert.alert("لا يمكن تغيير المادة", "أنهي تسجيل الطلاب الحاليين أولًا قبل تغيير مادة المجموعة.");
    const numericCapacity = Math.max(1, Number(capacity) || 1);
    if (numericCapacity < members.length) return Alert.alert("السعة غير كافية", `يوجد ${members.length} طلاب مسجلين. ارفعي السعة أولًا.`);
    try {
      setSaving(true);
      await updateGroup(group.id, {
        name, academy, subject: selectedSubject.nameAr, capacity: numericCapacity,
        totalSessions: Math.max(0, Number(total) || 0),
        remainingSessions: Math.max(0, Number(remaining) || 0), notes
      });
      await onSaved();
      Alert.alert("تم الحفظ", "تم تحديث بيانات المجموعة.");
    } catch (error) { Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }

  return (
    <Sheet visible={Boolean(group)} title={group ? `مجموعة ${group.name}` : "المجموعة"} subtitle="إدارة بيانات المجموعة وطلابها" onClose={onClose}>
      <View style={styles.groupCapacityCallout}>
        <MaterialIcons name="groups" size={22} color={COLORS.primaryDeep} />
        <View style={{ flex: 1 }}>
          <Text style={styles.groupCapacityTitle}>{members.length}/{capacity || "0"} طلاب</Text>
          <Text style={styles.groupCapacityBody}>السعة لا يمكن أن تقل عن عدد الطلاب المسجلين فعليًا.</Text>
        </View>
      </View>
      <InputField label="اسم المجموعة" value={name} onChangeText={setName} />
      <InputField label="الصف الدراسي" value={academy} onChangeText={setAcademy} />
      <SubjectPicker options={subjectOptions} selectedIds={subjectId ? [subjectId] : []} onToggle={setSubjectId} multiple={false} />
      {subjectChangedWithMembers ? <Text style={styles.inlineHint}>لا يمكن تغيير المادة قبل إنهاء تسجيل الطلاب الحاليين.</Text> : null}
      <View style={styles.inlineFields}>
        <View style={{ flex: 1 }}><InputField label="السعة" value={capacity} onChangeText={setCapacity} keyboardType="numeric" /></View>
        <View style={{ flex: 1 }}><InputField label="إجمالي الحصص" value={total} onChangeText={setTotal} keyboardType="numeric" /></View>
      </View>
      <InputField label="الحصص المتبقية" value={remaining} onChangeText={setRemaining} keyboardType="numeric" />
      <InputField label="ملاحظات المجموعة" value={notes} onChangeText={setNotes} multiline />
      <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ بيانات المجموعة"} icon="save" onPress={save} disabled={saving} />
      <SectionHeader title="طلاب المجموعة" subtitle={`${members.length} تسجيلات نشطة`} />
      {members.length ? members.map(member => (
        <View key={member.enrollmentId} style={styles.profileSessionRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.rowTitle}>{member.name}</Text>
            <Text style={styles.rowSub}>{member.phone || "لا يوجد رقم هاتف"} · منذ {member.startDate}</Text>
          </View>
          <IconButton label={`إنهاء تسجيل ${member.name}`} icon="person-remove" onPress={() => removeMember(member.enrollmentId)} tone="danger" />
        </View>
      )) : <Text style={styles.inlineHint}>لم يتم تسجيل طلاب في هذه المجموعة بعد.</Text>}
      {group?.active === 0 ? <Text style={styles.inlineHint}>هذه المجموعة مؤرشفة. أعيدي تفعيلها من قائمة المجموعات قبل إضافة طلاب أو إنشاء مواعيد جديدة.</Text> : <>
        <Text style={styles.fieldLabel}>إضافة طالب للمجموعة</Text>
        <View style={styles.choiceWrap}>
          {eligibleStudents.slice(0, 30).map(student => (
            <Choice key={student.id} label={student.name} selected={selectedStudentId === student.id} onPress={() => setSelectedStudentId(student.id)} />
          ))}
        </View>
        {eligibleStudents.length === 0 ? <Text style={styles.inlineHint}>لا يوجد طلاب متاحون للإضافة، أو اكتملت السعة.</Text> : null}
        <AppButton title="إضافة الطالب المحدد" icon="person-add" onPress={addMember} disabled={!selectedStudentId || members.length >= Math.max(1, Number(capacity) || 1)} />
      </>}
      {group?.memberNames ? <Text style={styles.inlineHint}>أسماء قديمة محفوظة من الإصدار السابق: {group.memberNames}. راجعيها وسجلي الطلاب من القائمة أعلاه لربطهم بسجلاتهم.</Text> : null}
      <SectionHeader title="تقارير المجموعة" subtitle={`${completedGroupSessions.length} حصة مكتملة محفوظة`} />
      {completedGroupSessions.length ? completedGroupSessions.map(session => (
        <View key={session.id} style={styles.card}>
          <SectionHeader title={`تقرير ${formatDate(session.sessionDate)}`} subtitle={`${session.startTime} · ${session.sessionNumber ? `الحصة ${session.sessionNumber}` : "رقم الحصة غير محدد"}`} />
          <Text style={styles.rowSub}>الواجب: {session.homework?.trim() || "لا يوجد واجب محدد"}</Text>
          <Text style={styles.rowSub}>ملاحظات: {session.notes?.trim() || "لا توجد ملاحظات"}</Text>
          <AppButton title="إرسال تقارير الطلاب عبر واتساب" icon="share" onPress={() => void onShareReport(session)} compact />
          <Text style={styles.inlineHint}>نسخ التقرير: اضغطي مطولًا على نص التقرير الخاص بالطالب، ثم اختاري «نسخ» من قائمة Android.</Text>
          {members.length ? members.map(member => (
            <View key={`${session.id}-${member.studentId}`} style={{ borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 10, marginTop: 8, gap: 5 }}>
              <Text style={styles.rowTitle}>{member.name}</Text>
              <Text selectable style={[styles.rowSub, { lineHeight: 22 }]}>{buildSessionReportMessage(session, { name: member.name, academy: session.academy, phone: member.phone })}</Text>
              <View style={styles.choiceWrap}>
                <AppButton title="نسخ أو مشاركة التقرير" icon="content-copy" tone="outline" compact onPress={() => { void Share.share({ message: buildSessionReportMessage(session, { name: member.name, academy: session.academy, phone: member.phone }) }); }} />
                <AppButton title="واتساب لهذا الطالب" icon="chat" tone="soft" compact onPress={() => onShareStudentReport(session, member)} />
              </View>
            </View>
          )) : <Text style={styles.inlineHint}>لا يوجد طلاب نشطون حاليًا لعرض تقاريرهم.</Text>}
        </View>
      )) : <EmptyState icon="description" title="لا توجد تقارير محفوظة بعد" body="بعد إنهاء أي حصة للمجموعة وحفظ الواجب والملاحظات، سيظهر تقريرها هنا تلقائيًا." />}
    </Sheet>
  );
}

function SessionSheet({ visible, onClose, onSaved, students, groups }: {
  visible: boolean;
  onClose: () => void;
  onSaved: () => Promise<void>;
  students: Student[];
  groups: TutoringGroup[];
}) {
  const [kind, setKind] = useState<"student" | "group">("student");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState("");
  const [studentSubjects, setStudentSubjectsState] = useState<AcademySubject[]>([]);
  const [date, setDate] = useState(todayDate());
  const [time, setTime] = useState("16:00");
  const [duration, setDuration] = useState("60");
  const [saving, setSaving] = useState(false);
  const sources = kind === "student" ? students.filter(student => student.active) : groups.filter(group => group.active !== 0);
  const selectedSource = sources.find(entry => entry.id === selectedId);

  useEffect(() => {
    if (sources.length && !sources.some(source => source.id === selectedId)) setSelectedId(sources[0].id);
    if (!sources.length) setSelectedId(null);
  }, [kind, sources, selectedId]);

  useEffect(() => { if (visible) setDate(todayDate()); }, [visible]);

  useEffect(() => {
    let cancelled = false;
    if (kind === "student" && selectedId !== null) {
      void listStudentSubjects(selectedId).then(subjects => {
        if (!cancelled) {
          setStudentSubjectsState(subjects);
          setSelectedSubjectId(current => subjects.some(subject => subject.id === current) ? current : (subjects[0]?.id ?? ""));
        }
      }).catch(error => Alert.alert("تعذر تحميل مواد الطالب", error instanceof Error ? error.message : "حاولي مرة أخرى."));
    } else {
      setStudentSubjectsState([]);
      setSelectedSubjectId("");
    }
    return () => { cancelled = true; };
  }, [kind, selectedId]);

  async function save() {
    const source = sources.find(entry => entry.id === selectedId);
    if (!source) return Alert.alert("اختاري الاسم", kind === "student" ? "اختاري الطالب للحصة." : "اختاري مجموعة للحصة.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return Alert.alert("التاريخ غير صحيح", "اكتبي التاريخ بصيغة 2026-10-01.");
    try {
      setSaving(true);
      if (kind === "student") {
        const subject = studentSubjects.find(item => item.id === selectedSubjectId);
        if (!subject) return Alert.alert("اختاري المادة", "اختاري المادة التي ستكون عليها الحصة الفردية.");
        const student = source as Student;
        await createSession({ studentId: student.id, studentName: student.name, academy: student.academy, subject: subject.nameAr, sessionDate: date, startTime: time, durationMinutes: Number(duration) || 60 });
      } else {
        const group = source as TutoringGroup;
        await createSession({ groupId: group.id, groupName: group.name, academy: group.academy, subject: group.subject, sessionDate: date, startTime: time, durationMinutes: Number(duration) || 60 });
      }
      await onSaved();
      onClose();
    } catch (error) {
      Alert.alert("تعذر الجدولة", error instanceof Error ? error.message : "تحققي من البيانات ثم حاولي مرة أخرى.");
    } finally { setSaving(false); }
  }

  return (
    <Sheet visible={visible} title="جدولة حصة" subtitle="اختاري الطالب أو المجموعة والمادة والموعد" onClose={onClose}>
      <Text style={styles.fieldLabel}>نوع الحصة</Text>
      <View style={styles.choiceRow}>
        <Choice label="فردية" selected={kind === "student"} onPress={() => setKind("student")} />
        <Choice label="مجموعة" selected={kind === "group"} onPress={() => setKind("group")} />
      </View>
      <Text style={[styles.fieldLabel, { marginTop: 12 }]}>{kind === "student" ? "الطالب" : "المجموعة"}</Text>
      <View style={styles.choiceWrap}>{sources.map(source => <Choice key={source.id} label={source.name} selected={selectedId === source.id} onPress={() => setSelectedId(source.id)} />)}</View>
      {sources.length === 0 ? <Text style={styles.inlineHint}>{kind === "student" ? "أضيفي طالبًا نشطًا أولًا." : "أنشئي مجموعة أولًا."}</Text> : null}
      {kind === "student" && selectedSource ? (
        <SubjectPicker options={studentSubjects} selectedIds={selectedSubjectId ? [selectedSubjectId] : []} onToggle={setSelectedSubjectId} multiple={false} />
      ) : null}
      {kind === "group" && selectedSource ? <Text style={styles.inlineHint}>المادة: {(selectedSource as TutoringGroup).subject || "غير محددة"}</Text> : null}
      <InputField label="تاريخ الحصة (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="2026-10-01" />
      <InputField label="وقت البداية" value={time} onChangeText={setTime} placeholder="16:00" />
      <InputField label="مدة الحصة بالدقائق" value={duration} onChangeText={setDuration} keyboardType="numeric" />
      <AppButton title={saving ? "جارٍ الجدولة..." : "حفظ الحصة"} icon="event-available" onPress={save} disabled={saving || sources.length === 0} />
    </Sheet>
  );
}

function SessionEditSheet({ session, onClose, onSaved }: { session: LessonSession | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const [date, setDate] = useState(todayDate());
  const [time, setTime] = useState("16:00");
  const [duration, setDuration] = useState("60");
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (session) { setDate(session.sessionDate); setTime(session.startTime); setDuration(String(session.durationMinutes)); } }, [session?.id]);
  async function save() {
    if (!session) return;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return Alert.alert("التاريخ غير صحيح", "اكتبي التاريخ بصيغة 2026-10-01.");
    try {
      setSaving(true);
      await updateScheduledSession({ id: session.id, sessionDate: date, startTime: time, durationMinutes: Number(duration) || 60 });
      await onSaved();
      onClose();
      Alert.alert("تم التعديل", "تم تحديث موعد الحصة محليًا.");
    } catch (error) { Alert.alert("تعذر التعديل", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(session) && session?.status !== "completed"} title="تعديل موعد الحصة" subtitle={session ? sessionLabel(session) : undefined} onClose={onClose}>
    <InputField label="تاريخ الحصة (YYYY-MM-DD)" value={date} onChangeText={setDate} />
    <InputField label="وقت البداية" value={time} onChangeText={setTime} />
    <InputField label="مدة الحصة بالدقائق" value={duration} onChangeText={setDuration} keyboardType="numeric" />
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ الموعد"} icon="save" onPress={save} disabled={saving} />
  </Sheet>;
}

function CompletedSessionEditSheet({ session, onClose, onSaved, onShare }: { session: LessonSession | null; onClose: () => void; onSaved: () => Promise<void>; onShare: (session: LessonSession) => Promise<void> }) {
  const [attendance, setAttendance] = useState<"حاضر" | "غائب" | "متأخر">("حاضر");
  const [homework, setHomework] = useState("");
  const [previous, setPrevious] = useState<0 | 1 | null>(null);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (!session) return;
    setAttendance(session.attendance || "حاضر");
    setHomework(session.homework || "");
    setPrevious(session.previousHomeworkDone === 1 ? 1 : session.previousHomeworkDone === 0 ? 0 : null);
    setNotes(session.notes || "");
  }, [session?.id]);
  async function save() {
    if (!session) return;
    try {
      setSaving(true);
      await updateCompletedSession({ id: session.id, attendance, homework, previousHomeworkDone: previous, notes });
      await onSaved();
      Alert.alert("تم حفظ التقرير", "تم تعديل بيانات الحصة دون خصم اشتراك إضافي.");
    } catch (error) { Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(session) && session?.status === "completed"} title="تعديل تقرير الحصة" subtitle={session ? `${sessionLabel(session)} · ${formatDate(session.sessionDate)}` : undefined} onClose={onClose}>
    <Text style={styles.fieldLabel}>الحضور</Text><View style={styles.choiceRow}><Choice label="حاضر" selected={attendance === "حاضر"} onPress={() => setAttendance("حاضر")} /><Choice label="غائب" selected={attendance === "غائب"} onPress={() => setAttendance("غائب")} tone="danger" /><Choice label="متأخر" selected={attendance === "متأخر"} onPress={() => setAttendance("متأخر")} tone="warning" /></View>
    <Text style={[styles.fieldLabel, { marginTop: 12 }]}>الواجب السابق</Text><View style={styles.choiceRow}><Choice label="تم" selected={previous === 1} onPress={() => setPrevious(1)} /><Choice label="لم يتم" selected={previous === 0} onPress={() => setPrevious(0)} tone="danger" /></View>
    <InputField label="الواجب الجديد" value={homework} onChangeText={setHomework} multiline />
    <InputField label="الملاحظات" value={notes} onChangeText={setNotes} multiline />
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ التعديلات"} icon="save" onPress={save} disabled={saving} />
    {session ? <AppButton title="إرسال التقرير" icon="share" onPress={() => void onShare({ ...session, attendance, homework, previousHomeworkDone: previous, notes })} tone="soft" /> : null}
  </Sheet>;
}

function CompletionSheet({ session, onClose, onSaved }: { session: LessonSession | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const [attendance, setAttendance] = useState<"حاضر" | "غائب" | "متأخر">("حاضر");
  const [groupAttendance, setGroupAttendance] = useState<GroupAttendanceDraft[]>([]);
  const [groupAttendanceLoading, setGroupAttendanceLoading] = useState(false);
  const [groupAttendanceError, setGroupAttendanceError] = useState(false);
  const [homework, setHomework] = useState("");
  const [previous, setPrevious] = useState<0 | 1 | null>(null);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    setAttendance("حاضر"); setHomework(""); setPrevious(null); setNotes(""); setGroupAttendance([]); setGroupAttendanceError(false);
    let active = true;
    if (session?.groupId) {
      setGroupAttendanceLoading(true);
      void listGroupMembers(session.groupId).then(members => {
        if (active) setGroupAttendance(members.map(member => ({ studentId: member.studentId, name: member.name, status: "حاضر" as const })));
      }).catch(error => {
        if (active) setGroupAttendanceError(true);
        Alert.alert("تعذر تحميل طلاب المجموعة", error instanceof Error ? error.message : "أغلقي النافذة وأعيدي المحاولة قبل إنهاء الحصة.");
      }).finally(() => { if (active) setGroupAttendanceLoading(false); });
    } else setGroupAttendanceLoading(false);
    return () => { active = false; };
  }, [session?.id, session?.groupId]);
  function setMemberAttendance(studentId: number, status: GroupAttendanceDraft["status"]) {
    setGroupAttendance(current => current.map(member => member.studentId === studentId ? { ...member, status } : member));
  }
  async function save() {
    if (!session) return;
    try {
      setSaving(true);
      await completeSession({ id: session.id, attendance, groupAttendance: session.groupId ? groupAttendance.map(({ studentId, status }) => ({ studentId, status })) : undefined, homework, previousHomeworkDone: previous, notes });
      await onSaved(); onClose();
    } catch (error) { Alert.alert("تعذر إنهاء الحصة", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(session)} title="إنهاء الحصة" subtitle={session ? `${sessionLabel(session)} · ${session.startTime}` : undefined} onClose={onClose}>
    {session?.groupId ? <>
      <Text style={styles.fieldLabel}>حضور كل طالب في المجموعة</Text>
      <Text style={styles.inlineHint}>سيُسجّل لكل طالب حضوره وتُحدّث حصصه المنجزة بصورة مستقلة.</Text>
      {groupAttendanceError ? <Text style={styles.inlineHint}>تعذر تحميل قائمة الطلاب؛ لن نسمح بإنهاء الحصة حتى لا تُسجّل حالة حضور افتراضية بالخطأ. أغلقي النافذة وأعيدي المحاولة.</Text> : groupAttendance.length ? groupAttendance.map(member => <View key={member.studentId} style={[styles.card, { gap: 8 }]}>
        <Text style={styles.rowTitle}>{member.name}</Text>
        <View style={styles.choiceRow}>
          <Choice label="حاضر" selected={member.status === "حاضر"} onPress={() => setMemberAttendance(member.studentId, "حاضر")} />
          <Choice label="غائب" selected={member.status === "غائب"} onPress={() => setMemberAttendance(member.studentId, "غائب")} tone="danger" />
          <Choice label="متأخر" selected={member.status === "متأخر"} onPress={() => setMemberAttendance(member.studentId, "متأخر")} tone="warning" />
        </View>
      </View>) : <Text style={styles.inlineHint}>لا يوجد طلاب نشطون مسجلون في هذه المجموعة. لن تُضاف حصص إلى ملفات الطلاب.</Text>}
    </> : <><Text style={styles.fieldLabel}>الحضور</Text><View style={styles.choiceRow}><Choice label="حاضر" selected={attendance === "حاضر"} onPress={() => setAttendance("حاضر")} /><Choice label="غائب" selected={attendance === "غائب"} onPress={() => setAttendance("غائب")} tone="danger" /><Choice label="متأخر" selected={attendance === "متأخر"} onPress={() => setAttendance("متأخر")} tone="warning" /></View></>}
    <Text style={[styles.fieldLabel, { marginTop: 12 }]}>الواجب السابق</Text><View style={styles.choiceRow}><Choice label="تم" selected={previous === 1} onPress={() => setPrevious(1)} /><Choice label="لم يتم" selected={previous === 0} onPress={() => setPrevious(0)} tone="danger" /></View>
    <InputField label="واجب جديد" value={homework} onChangeText={setHomework} placeholder="اكتبي الواجب المطلوب" multiline />
    <InputField label="ملاحظات" value={notes} onChangeText={setNotes} placeholder="ملخص الحصة أو ملاحظة لولي الأمر" multiline />
    <AppButton title={saving ? "جارٍ الحفظ..." : "إنهاء وحفظ التقرير"} icon="check-circle" onPress={save} disabled={saving || groupAttendanceLoading || groupAttendanceError} />
  </Sheet>;
}

function ReportRecipientSheet({ visible, recipients, onClose, onSelect }: { visible: boolean; recipients: ReportRecipient[]; onClose: () => void; onSelect: (recipient: ReportRecipient) => void }) {
  return <Sheet visible={visible} title="اختاري الطالب لإرسال تقريره" subtitle="سيُفتح واتساب برسالة مستقلة لكل طالب" onClose={onClose}>
    {recipients.length ? recipients.map(recipient => <Pressable key={recipient.studentId} onPress={() => onSelect(recipient)} style={styles.card}>
      <View style={{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }}><Text style={styles.rowTitle}>{recipient.name}</Text><MaterialIcons name="chat" size={20} color={COLORS.primary} /></View>
      <Text style={styles.rowSub}>{recipient.phone || "لا يوجد رقم واتساب مسجل — ستظهر قائمة المشاركة"}</Text>
    </Pressable>) : <EmptyState icon="groups" title="لا يوجد طلاب نشطون" body="أضيفي الطلاب إلى المجموعة أولًا." />}
  </Sheet>;
}

function FinanceSheet({ visible, onClose, onSaved, students }: { visible: boolean; onClose: () => void; onSaved: () => Promise<void>; students: Student[] }) {
  const [type, setType] = useState<TransactionType>("income"); const [amount, setAmount] = useState(""); const [description, setDescription] = useState(""); const [saving, setSaving] = useState(false);
  const [studentId, setStudentId] = useState<number | null>(null);
  const [transactionDate, setTransactionDate] = useState(todayDate());
  const [showDatePicker, setShowDatePicker] = useState(false);
  useEffect(() => { if (visible) { setType("income"); setAmount(""); setDescription(""); setStudentId(null); setTransactionDate(todayDate()); setShowDatePicker(false); } }, [visible]);
  const options: Array<{ type: TransactionType; label: string; tone: "primary" | "warning" | "danger" }> = [{ type: "income", label: "إيراد", tone: "primary" }, { type: "expense", label: "مصروف", tone: "warning" }, { type: "refund", label: "استرداد", tone: "danger" }, { type: "discount", label: "خصم", tone: "warning" }];
  async function save() { const numeric = Number(amount); if (!numeric || numeric <= 0) return Alert.alert("المبلغ غير صحيح", "اكتبي مبلغًا أكبر من صفر."); if (type === "discount" && studentId === null) return Alert.alert("اختاري الطالب", "يجب ربط الخصم بحساب طالب حتى يُخصم من مستحقاته."); try { setSaving(true); await createTransaction({ type, amount: numeric, description, transactionDate, studentId: type === "income" || type === "refund" || type === "discount" ? studentId : null }); await onSaved(); onClose(); } catch (error) { Alert.alert("تعذر الحفظ", error instanceof Error ? error.message : "حاولي مرة أخرى."); } finally { setSaving(false); } }
  return <Sheet visible={visible} title="حركة مالية" subtitle="الخصم يخفض مستحق الطالب ولا يُعد مصروفًا نقديًا" onClose={onClose}><Text style={styles.fieldLabel}>نوع الحركة</Text><View style={styles.choiceWrap}>{options.map(option => <Choice key={option.type} label={option.label} selected={type === option.type} onPress={() => setType(option.type)} tone={option.tone} />)}</View>{type === "income" || type === "refund" || type === "discount" ? <><Text style={styles.fieldLabel}>{type === "discount" ? "اختاري الطالب (إلزامي)" : "ربط الحركة بحساب طالب (اختياري)"}</Text><View style={styles.choiceWrap}>{type !== "discount" ? <Choice label="حركة عامة" selected={studentId === null} onPress={() => setStudentId(null)} /> : null}{students.map(student => <Choice key={student.id} label={student.name} selected={studentId === student.id} onPress={() => setStudentId(student.id)} />)}</View></> : null}<InputField label="المبلغ بالجنيه" value={amount} onChangeText={setAmount} keyboardType="numeric" placeholder="0" /><InputField label="الوصف" value={description} onChangeText={setDescription} placeholder={type === "income" ? "مثال: دفعة من اشتراك الطالب" : type === "discount" ? "مثال: خصم تفوق أو خصم خاص" : "اكتبي وصف الحركة"} />
    <View style={styles.fieldWrap}>
      <Text style={styles.fieldLabel}>تاريخ الحركة / الدفع</Text>
      <Pressable accessibilityRole="button" accessibilityLabel="اختيار تاريخ الحركة" onPress={() => setShowDatePicker(true)} style={({ pressed }) => [styles.timePickerButton, { alignSelf: "flex-end", minHeight: 44, paddingHorizontal: 14 }, pressed && { opacity: 0.75 }]}>
        <MaterialIcons name="calendar-today" size={18} color={COLORS.primaryDeep} />
        <Text style={styles.timePickerButtonText}>{formatDate(transactionDate)}</Text>
      </Pressable>
      {showDatePicker ? <DateTimePicker value={new Date(`${transactionDate}T12:00:00`)} mode="date" display={Platform.OS === "ios" ? "spinner" : "default"} onChange={(event, date) => { setShowDatePicker(Platform.OS === "ios"); if (event.type === "set" && date) setTransactionDate(`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`); }} /> : null}
    </View>
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ الحركة"} icon="check" onPress={save} disabled={saving} /></Sheet>;
}

function TimetableSheet({ visible, onClose, onSaved, students, groups }: {
  visible: boolean;
  onClose: () => void;
  onSaved: () => Promise<void>;
  students: Student[];
  groups: TutoringGroup[];
}) {
  const [kind, setKind] = useState<"student" | "group">("student");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState("");
  const [studentSubjects, setStudentSubjectsState] = useState<AcademySubject[]>([]);
  const [weeklyTimes, setWeeklyTimes] = useState<Record<string, string>>({});
  const [duration, setDuration] = useState(60);
  const [timePickerDay, setTimePickerDay] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const sources = kind === "student" ? students.filter(student => student.active) : groups.filter(group => group.active !== 0);
  const selectedDays = DAYS.filter(day => Boolean(weeklyTimes[day]));
  const selectedSource = sources.find(entry => entry.id === selectedId);

  useEffect(() => {
    if (sources.length && !sources.some(source => source.id === selectedId)) setSelectedId(sources[0].id);
    if (!sources.length) setSelectedId(null);
  }, [kind, sources, selectedId]);

  useEffect(() => {
    if (visible) { setWeeklyTimes({}); setDuration(60); setTimePickerDay(null); }
  }, [visible]);

  useEffect(() => {
    let cancelled = false;
    if (kind === "student" && selectedId !== null) {
      void listStudentSubjects(selectedId).then(subjects => {
        if (!cancelled) {
          setStudentSubjectsState(subjects);
          setSelectedSubjectId(current => subjects.some(subject => subject.id === current) ? current : (subjects[0]?.id ?? ""));
        }
      }).catch(error => Alert.alert("تعذر تحميل مواد الطالب", error instanceof Error ? error.message : "حاولي مرة أخرى."));
    } else {
      setStudentSubjectsState([]);
      setSelectedSubjectId("");
    }
    return () => { cancelled = true; };
  }, [kind, selectedId]);

  function toggleDay(day: string) {
    setWeeklyTimes(current => {
      if (current[day]) {
        const { [day]: _removed, ...remaining } = current;
        return remaining;
      }
      return { ...current, [day]: DEFAULT_WEEKLY_TIME };
    });
  }

  async function save() {
    const source = sources.find(entry => entry.id === selectedId);
    if (!source) return Alert.alert("اختاري الاسم", "اختاري طالبًا أو مجموعة.");
    if (!selectedDays.length) return Alert.alert("اختاري الأيام", "اختاري يومًا واحدًا على الأقل للجدول المتكرر.");
    let selectedSubjectName: string | null = null;
    if (kind === "student") {
      const subject = studentSubjects.find(item => item.id === selectedSubjectId);
      if (!subject) return Alert.alert("اختاري المادة", "اختاري المادة التي سيكون عليها الجدول الفردي.");
      selectedSubjectName = subject.nameAr;
    } else {
      selectedSubjectName = (source as TutoringGroup).subject;
    }
    try {
      setSaving(true);
      const inserted = await createRecurringTimetableSlots(selectedDays.map(day => ({
        studentId: kind === "student" ? source.id : null,
        groupId: kind === "group" ? source.id : null,
        title: source.name,
        dayOfWeek: day,
        startTime: weeklyTimes[day],
        durationMinutes: duration,
        subject: selectedSubjectName,
      })));
      await onSaved();
      onClose();
      Alert.alert("تم حفظ الجدول", `تمت إضافة ${inserted} مواعيد أسبوعية متكررة.`);
    } catch (error) {
      Alert.alert("تعذر حفظ الجدول", error instanceof Error ? error.message : "حاولي مرة أخرى.");
    } finally { setSaving(false); }
  }

  function renderSubjectSelector() {
    if (kind === "student" && selectedSource) {
      return <SubjectPicker options={studentSubjects} selectedIds={selectedSubjectId ? [selectedSubjectId] : []} onToggle={setSelectedSubjectId} multiple={false} />;
    }
    if (kind === "group" && selectedSource) {
      return <Text style={styles.inlineHint}>المادة: {(selectedSource as TutoringGroup).subject || "غير محددة"}</Text>;
    }
    return null;
  }

  return (
    <Sheet visible={visible} title="جدول أسبوعي متكرر" subtitle="اختاري عدة أيام وحددي وقتًا خاصًا لكل يوم" onClose={() => { setTimePickerDay(null); onClose(); }}>
      <Text style={styles.fieldLabel}>نوع الجدول</Text>
      <View style={styles.choiceRow}>
        <Choice label="طالب" selected={kind === "student"} onPress={() => setKind("student")} />
        <Choice label="مجموعة" selected={kind === "group"} onPress={() => setKind("group")} />
      </View>
      <Text style={[styles.fieldLabel, { marginTop: 12 }]}>{kind === "student" ? "الطالب" : "المجموعة"}</Text>
      <View style={styles.choiceWrap}>{sources.map(source => <Choice key={source.id} label={source.name} selected={selectedId === source.id} onPress={() => setSelectedId(source.id)} />)}</View>
      {sources.length === 0 ? <Text style={styles.inlineHint}>{kind === "student" ? "أضيفي طالبًا نشطًا أولًا." : "أنشئي مجموعة أولًا."}</Text> : null}
      {renderSubjectSelector()}
      <Text style={[styles.fieldLabel, { marginTop: 12 }]}>الأيام المتكررة</Text>
      <View style={styles.daysGrid}>
        {DAYS.map(day => {
          const selected = Boolean(weeklyTimes[day]);
          return (
            <Pressable key={day} accessibilityRole="checkbox" accessibilityLabel={`تكرار يوم ${day}`} accessibilityState={{ checked: selected }} onPress={() => toggleDay(day)} style={({ pressed }) => [styles.dayPicker, selected && styles.dayPickerSelected, pressed && { opacity: 0.72 }]}>
              <MaterialIcons name={selected ? "check-circle" : "radio-button-unchecked"} size={18} color={selected ? COLORS.primaryDeep : COLORS.muted} />
              <Text style={[styles.dayPickerText, selected && styles.dayPickerTextSelected]}>{day}</Text>
            </Pressable>
          );
        })}
      </View>
      {selectedDays.length ? (
        <View style={styles.timeSelectionCard}>
          <View style={styles.timeSelectionHeader}>
            <Text style={styles.timeSelectionTitle}>وقت البداية لكل يوم</Text>
            <Text style={styles.timeSelectionHint}>اضغطي الساعة لفتح اختيار الوقت</Text>
          </View>
          {selectedDays.map(day => (
            <View key={day} style={styles.dayTimeRow}>
              <Text style={styles.dayTimeLabel}>{day}</Text>
              <Pressable accessibilityRole="button" accessibilityLabel={`تعديل وقت ${day}`} onPress={() => setTimePickerDay(day)} style={({ pressed }) => [styles.timePickerButton, pressed && { opacity: 0.75 }]}>
                <MaterialIcons name="schedule" size={18} color={COLORS.primaryDeep} />
                <Text style={styles.timePickerButtonText}>{formatTime(weeklyTimes[day])}</Text>
                <MaterialIcons name="expand-more" size={18} color={COLORS.muted} />
              </Pressable>
            </View>
          ))}
        </View>
      ) : <Text style={styles.inlineHint}>اختاري الأيام أولًا، ثم حددي ساعة كل يوم من زر الساعة.</Text>}
      {timePickerDay ? <DateTimePicker value={timeToDate(weeklyTimes[timePickerDay] ?? DEFAULT_WEEKLY_TIME)} mode="time" display={Platform.OS === "ios" ? "spinner" : "clock"} is24Hour={false} onChange={(event, date) => { if (Platform.OS === "android") setTimePickerDay(null); if (event.type === "set" && date) setWeeklyTimes(current => ({ ...current, [timePickerDay]: dateToTime(date) })); }} /> : null}
      <Text style={[styles.fieldLabel, { marginTop: 4 }]}>مدة الحصة</Text>
      <View style={styles.choiceWrap}>{[30, 45, 60, 90, 120].map(minutes => <Choice key={minutes} label={`${minutes} دقيقة`} selected={duration === minutes} onPress={() => setDuration(minutes)} />)}</View>
      <AppButton title={saving ? "جارٍ حفظ الجدول..." : selectedDays.length ? `حفظ ${selectedDays.length} مواعيد متكررة` : "حفظ المواعيد المتكررة"} icon="repeat" onPress={save} disabled={saving || sources.length === 0} />
    </Sheet>
  );
}

function TimetableEditSheet({ slot, onClose, onSaved }: { slot: TimetableSlot | null; onClose: () => void; onSaved: () => Promise<void> }) {
  const [day, setDay] = useState(DAYS[0]);
  const [time, setTime] = useState("16:00");
  const [duration, setDuration] = useState(60);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (slot) { setDay(slot.dayOfWeek); setTime(slot.startTime); setDuration(slot.durationMinutes); setShowTimePicker(false); } }, [slot?.id]);
  async function save() {
    if (!slot) return;
    try {
      setSaving(true);
      await updateTimetableSlot({ id: slot.id, dayOfWeek: day, startTime: time, durationMinutes: duration });
      await onSaved();
      onClose();
      Alert.alert("تم التعديل", "تم تحديث الموعد الأسبوعي.");
    } catch (error) { Alert.alert("تعذر التعديل", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  return <Sheet visible={Boolean(slot)} title="تعديل الموعد الأسبوعي" subtitle={slot?.title} onClose={onClose}>
    <Text style={styles.fieldLabel}>اليوم</Text><View style={styles.choiceWrap}>{DAYS.map(item => <Choice key={item} label={item} selected={day === item} onPress={() => setDay(item)} />)}</View>
    <Text style={[styles.fieldLabel, { marginTop: 8 }]}>وقت البداية</Text><Pressable accessibilityRole="button" accessibilityLabel="اختيار وقت البداية" onPress={() => setShowTimePicker(true)} style={({ pressed }) => [styles.editTimePickerButton, pressed && { opacity: 0.75 }]}><MaterialIcons name="schedule" size={20} color={COLORS.primaryDeep} /><Text style={styles.editTimePickerText}>{formatTime(time)}</Text><Text style={styles.editTimePickerHint}>تغيير</Text></Pressable>
    {showTimePicker ? <DateTimePicker value={timeToDate(time)} mode="time" display={Platform.OS === "ios" ? "spinner" : "clock"} is24Hour={false} onChange={(event, date) => { if (Platform.OS === "android") setShowTimePicker(false); if (event.type === "set" && date) setTime(dateToTime(date)); }} /> : null}
    <Text style={[styles.fieldLabel, { marginTop: 8 }]}>مدة الحصة</Text><View style={styles.choiceWrap}>{[30, 45, 60, 90, 120].map(minutes => <Choice key={minutes} label={`${minutes} دقيقة`} selected={duration === minutes} onPress={() => setDuration(minutes)} />)}</View>
    <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ التعديلات"} icon="save" onPress={save} disabled={saving} />
  </Sheet>;
}

function AssessmentScreen({ students, groups, subjects }: { students: Student[]; groups: TutoringGroup[]; subjects: AcademySubject[] }) {
  const [mode, setMode] = useState<"student" | "group">("student");
  const [records, setRecords] = useState<ExamPerformanceRow[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(students[0]?.id ?? null);
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(groups[0]?.id ?? null);
  const [subjectFilter, setSubjectFilter] = useState("الكل");
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    setLoading(true);
    try { setRecords(await listAllExamResults()); }
    catch (error) { Alert.alert("تعذر تحميل سجل الدرجات", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setLoading(false); }
  };
  useEffect(() => { void refresh(); }, []);
  useEffect(() => { if (!students.some(item => item.id === selectedStudentId)) setSelectedStudentId(students[0]?.id ?? null); }, [students, selectedStudentId]);
  useEffect(() => { if (!groups.some(item => item.id === selectedGroupId)) setSelectedGroupId(groups[0]?.id ?? null); }, [groups, selectedGroupId]);

  const scopedRecords = records.filter(row => mode === "student"
    ? row.studentId === selectedStudentId
    : row.targetType === "group" && row.targetId === selectedGroupId);
  const filteredRecords = scopedRecords.filter(row => subjectFilter === "الكل" || row.subject === subjectFilter);
  const totalMarks = filteredRecords.reduce((sum, row) => sum + Number(row.examTotalMarks || 0), 0);
  const totalScore = filteredRecords.reduce((sum, row) => sum + Number(row.score || 0), 0);
  const average = totalMarks > 0 ? Math.round((totalScore / totalMarks) * 100) : 0;
  const lessonStats = Object.values(filteredRecords.reduce<Record<string, { lesson: string; subject: string; score: number; max: number; count: number }>>((acc, row) => {
    const key = `${row.subject}::${row.lesson}`;
    if (!acc[key]) acc[key] = { lesson: row.lesson, subject: row.subject, score: 0, max: 0, count: 0 };
    acc[key].score += Number(row.score || 0); acc[key].max += Number(row.examTotalMarks || 0); acc[key].count += 1;
    return acc;
  }, {})).map(item => ({ ...item, percent: item.max ? Math.round(item.score / item.max * 100) : 0 })).sort((a, b) => a.percent - b.percent);

  const groupExamStats = Object.values(filteredRecords.reduce<Record<string, { examId: number; examTitle: string; subject: string; lesson: string; max: number; scores: number[]; students: Set<number> }>>((acc, row) => {
    if (!acc[row.examId]) acc[row.examId] = { examId: row.examId, examTitle: row.examTitle, subject: row.subject, lesson: row.lesson, max: Number(row.examTotalMarks || 0), scores: [], students: new Set<number>() };
    acc[row.examId].scores.push(Number(row.score || 0)); acc[row.examId].students.add(row.studentId);
    return acc;
  }, {})).map(item => ({ ...item, averageScore: item.scores.length ? item.scores.reduce((a, b) => a + b, 0) / item.scores.length : 0, averagePercent: item.max ? Math.round(item.scores.reduce((a, b) => a + b, 0) / item.scores.length / item.max * 100) : 0 })).sort((a, b) => b.examId - a.examId);

  async function shareReport() {
    const directory = FileSystem.cacheDirectory;
    if (!directory) return Alert.alert("تعذر إنشاء التقرير", "مساحة حفظ الملفات غير متاحة على الجهاز.");
    const subjectName = subjectFilter === "الكل" ? "كل المواد" : subjectFilter;
    const owner = mode === "student" ? students.find(item => item.id === selectedStudentId)?.name : groups.find(item => item.id === selectedGroupId)?.name;
    const lines = ["NANELSH Academy OS — تقرير التقييم الأكاديمي", `الاسم: ${owner ?? "غير محدد"}`, `النطاق: ${mode === "student" ? "ملف طالب" : "تقرير مجموعة"}`, `المادة: ${subjectName}`, `عدد النتائج: ${filteredRecords.length}`, `المتوسط العام: ${average}%`, "", "نتائج الاختبارات:", ...filteredRecords.map(row => `${row.examTitle} | ${row.subject} | ${row.lesson} | ${row.studentName}: ${row.score}/${row.examTotalMarks} (${row.examTotalMarks ? Math.round(row.score / row.examTotalMarks * 100) : 0}%)`), "", "تحليل الدروس:", ...lessonStats.map(item => `${item.subject} — ${item.lesson}: ${item.percent}% (${item.count} اختبار/اختبارات)`)];
    try {
      const fileUri = `${directory}academic-report-${Date.now()}.txt`;
      await FileSystem.writeAsStringAsync(fileUri, lines.join("\n"), { encoding: FileSystem.EncodingType.UTF8 });
      if (!(await Sharing.isAvailableAsync())) throw new Error("المشاركة غير متاحة على هذا الجهاز");
      await Sharing.shareAsync(fileUri, { mimeType: "text/plain", dialogTitle: "مشاركة تقرير التقييم" });
    } catch (error) { Alert.alert("تعذر مشاركة التقرير", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
  }

  return <ScrollView contentContainerStyle={styles.listContent}>
    <SectionHeader title="سجل الدرجات والتقييم" subtitle="متابعة الأداء الأكاديمي حسب الطالب أو المجموعة" action={<IconButton label="تحديث النتائج" icon="refresh" onPress={() => void refresh()} />} />
    <View style={styles.segmented}><Choice label="ملف طالب" selected={mode === "student"} onPress={() => { setMode("student"); setSubjectFilter("الكل"); }} /><Choice label="تقارير المجموعات" selected={mode === "group"} onPress={() => { setMode("group"); setSubjectFilter("الكل"); }} /></View>
    <SectionHeader title={mode === "student" ? "اختاري الطالب" : "اختاري المجموعة"} />
    <View style={styles.choiceWrap}>{(mode === "student" ? students.map(item => ({ id: item.id, name: item.name })) : groups.map(item => ({ id: item.id, name: item.name }))).map(item => <Choice key={item.id} label={item.name} selected={(mode === "student" ? selectedStudentId : selectedGroupId) === item.id} onPress={() => mode === "student" ? setSelectedStudentId(item.id) : setSelectedGroupId(item.id)} />)}</View>
    <SectionHeader title="تصفية حسب المادة" />
    <View style={styles.choiceWrap}><Choice label="الكل" selected={subjectFilter === "الكل"} onPress={() => setSubjectFilter("الكل")} />{subjects.map(item => <Choice key={item.id} label={item.nameAr} selected={subjectFilter === item.nameAr} onPress={() => setSubjectFilter(item.nameAr)} />)}</View>
    {loading ? <ActivityIndicator color={COLORS.primary} /> : <>
      <View style={styles.metricsGrid}>
        <Metric label="عدد النتائج" value={String(filteredRecords.length)} icon="fact-check" tint={COLORS.sage} />
        <Metric label="المتوسط" value={`${average}%`} icon="trending-up" tint={COLORS.mist} />
        <Metric label="الدرجات المحصلة" value={`${totalScore}/${totalMarks}`} icon="grade" tint={COLORS.champagneSoft} />
      </View>
      {filteredRecords.length ? <AppButton title="مشاركة التقرير" icon="share" onPress={() => void shareReport()} /> : null}
      {mode === "student" ? <>
        <SectionHeader title="نتائج الاختبارات" subtitle="كل نتيجة مرتبطة بمادتها ودرسها" />
        {filteredRecords.map(row => { const percent = row.examTotalMarks ? Math.round(row.score / row.examTotalMarks * 100) : 0; return <View key={row.id} style={styles.card}><Text style={styles.rowTitle}>{row.examTitle}</Text><Text style={styles.rowSub}>{row.subject} · {row.lesson}{row.examDate ? ` · ${row.examDate}` : ""}</Text><View style={styles.progressRow}><View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.max(0, Math.min(100, percent))}%` }]} /></View><Text style={styles.progressText}>{percent}%</Text></View><Text style={styles.rowSub}>الدرجة: {row.score} من {row.examTotalMarks}</Text></View>; })}
        <SectionHeader title="تحليل مستوى الدروس" subtitle="الترتيب من الأقل إلى الأعلى في نسبة الأداء" />
        {lessonStats.map(item => <View key={`${item.subject}-${item.lesson}`} style={styles.transactionRow}><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.lesson}</Text><Text style={styles.rowSub}>{item.subject} · {item.count} اختبار/اختبارات</Text></View><Text style={styles.progressText}>{item.percent}%</Text></View>)}
      </> : <>
        <SectionHeader title="ملخص أداء المجموعة" subtitle="متوسط نتائج الطلاب المسجلة لكل اختبار" />
        {groupExamStats.map(item => <View key={item.examId} style={styles.card}><Text style={styles.rowTitle}>{item.examTitle}</Text><Text style={styles.rowSub}>{item.subject} · {item.lesson}</Text><View style={styles.progressRow}><View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${item.averagePercent}%` }]} /></View><Text style={styles.progressText}>{item.averagePercent}%</Text></View><Text style={styles.rowSub}>متوسط الدرجات: {item.averageScore.toFixed(1)} من {item.max} · عدد الطلاب المسجلين: {item.students.size}</Text></View>)}
        <SectionHeader title="نتائج الطلاب" />
        {filteredRecords.map(row => <View key={row.id} style={styles.transactionRow}><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{row.studentName}</Text><Text style={styles.rowSub}>{row.examTitle} · {row.lesson}</Text></View><Text style={styles.progressText}>{row.score}/{row.examTotalMarks}</Text></View>)}
      </>}
      {!filteredRecords.length ? <EmptyState icon="assessment" title="لا توجد درجات مسجلة بعد" body="سجّلي نتائج الطلاب من شاشة الاختبارات، وستظهر هنا تلقائيًا في السجل الفردي وتقارير المجموعات." /> : null}
      {lessonStats.length ? <Text style={styles.inlineHint}>تظهر الدروس مرتبة من أقل نسبة أداء إلى أعلاها؛ استخدميها لتحديد الموضوعات التي تستحق المراجعة. النسب وصفية وليست تقديرات مدرسية رسمية.</Text> : null}
    </>}
  </ScrollView>;
}

function LearningContentScreen({ students, groups, subjects }: { students: Student[]; groups: TutoringGroup[]; subjects: AcademySubject[] }) {
  const [mode, setMode] = useState<"library" | "questions" | "exams">("library");
  const [exams, setExams] = useState<AcademyExam[]>([]);
  const [examTitle, setExamTitle] = useState("");
  const [examGrade, setExamGrade] = useState("");
  const [examLesson, setExamLesson] = useState("");
  const [examDuration, setExamDuration] = useState("45");
  const [examDate, setExamDate] = useState("");
  const [examTargetType, setExamTargetType] = useState<"group" | "student">("group");
  const [examTargetId, setExamTargetId] = useState<number | null>(null);
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<number[]>([]);
  const [gradingExam, setGradingExam] = useState<AcademyExam | null>(null);
  const [gradingStudentId, setGradingStudentId] = useState<number | null>(null);
  const [gradingCandidates, setGradingCandidates] = useState<Student[]>([]);
  const [gradingResults, setGradingResults] = useState<ExamResult[]>([]);
  const [gradingScore, setGradingScore] = useState("");
  const [documents, setDocuments] = useState<AcademyDocument[]>([]);
  const [questions, setQuestions] = useState<AcademyQuestion[]>([]);
  const [grade, setGrade] = useState("");
  const [subject, setSubject] = useState(subjects[0]?.nameAr ?? "");
  const [lesson, setLesson] = useState("");
  const [title, setTitle] = useState("");
  const [accessType, setAccessType] = useState<"all" | "student" | "group">("all");
  const [accessId, setAccessId] = useState<number | null>(null);
  const [questionType, setQuestionType] = useState<QuestionType>("mcq");
  const [prompt, setPrompt] = useState("");
  const [options, setOptions] = useState("");
  const [answer, setAnswer] = useState("");
  const [explanation, setExplanation] = useState("");
  const [marks, setMarks] = useState("1");
  const [pickedFile, setPickedFile] = useState<DocumentPicker.DocumentPickerAsset | null>(null);
  const [saving, setSaving] = useState(false);
  const refresh = async () => {
    const [docs, qs, examList] = await Promise.all([listAcademyDocuments(), listAcademyQuestions(), listAcademyExams()]);
    setDocuments(docs); setQuestions(qs); setExams(examList);
  };
  useEffect(() => { void refresh().catch(error => Alert.alert("تعذر تحميل المحتوى", error instanceof Error ? error.message : "حاولي مرة أخرى.")); }, []);
  useEffect(() => { if (!subjects.some(item => item.nameAr === subject) && subjects[0]) setSubject(subjects[0].nameAr); }, [subjects]);
  useEffect(() => {
    let active = true;
    async function loadCandidates() {
      if (!gradingExam) { setGradingCandidates([]); setGradingResults([]); return; }
      try {
        const [results, targetIds] = await Promise.all([
          listExamResults(gradingExam.id),
          Promise.resolve(JSON.parse(gradingExam.targetStudentIdsJson) as number[]),
        ]);
        if (active) {
          setGradingResults(results);
          setGradingCandidates(students.filter(item => targetIds.includes(item.id)));
        }
      } catch (error) { if (active) Alert.alert("تعذر تحميل سجل الاختبار", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    }
    void loadCandidates();
    return () => { active = false; };
  }, [gradingExam, students]);

  async function chooseFile() {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "image/*"], copyToCacheDirectory: true, multiple: false });
      if (!result.canceled && result.assets[0]) { setPickedFile(result.assets[0]); if (!title.trim()) setTitle(result.assets[0].name.replace(/\.[^.]+$/, "")); }
    } catch (error) { Alert.alert("تعذر اختيار الملف", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
  }
  async function saveDocument() {
    if (!pickedFile) return Alert.alert("اختاري ملفًا", "حددي ملف PDF أو Word أو PowerPoint أو صورة أولًا.");
    if (!title.trim() || !grade.trim() || !subject.trim() || !lesson.trim()) return Alert.alert("بيانات ناقصة", "أدخلي عنوان الملف والصف والمادة والدرس.");
    if (accessType !== "all" && accessId === null) return Alert.alert("حددي المستفيد", "اختاري الطالب أو المجموعة المسموح لها بالوصول.");
    const directory = FileSystem.documentDirectory;
    if (!directory) return Alert.alert("تعذر الحفظ", "مساحة الملفات الداخلية غير متاحة على الجهاز.");
    try {
      setSaving(true);
      const folder = `${directory}academy-library/`;
      const info = await FileSystem.getInfoAsync(folder);
      if (!info.exists) await FileSystem.makeDirectoryAsync(folder, { intermediates: true });
      const safeName = pickedFile.name.replace(/[^\w.\-\u0600-\u06FF]/g, "_");
      const destination = `${folder}${Date.now()}_${safeName}`;
      await FileSystem.copyAsync({ from: pickedFile.uri, to: destination });
      await createAcademyDocument({ title: title.trim(), fileName: pickedFile.name, fileUri: destination, mimeType: pickedFile.mimeType ?? null, sizeBytes: pickedFile.size ?? null, grade: grade.trim(), subject, lesson: lesson.trim(), accessType, accessId });
      setPickedFile(null); setTitle(""); setLesson(""); await refresh();
      Alert.alert("تمت الإضافة", "تم حفظ الملف داخل مكتبة الأكاديمية على هذا الجهاز.");
    } catch (error) { Alert.alert("تعذر حفظ الملف", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  async function openDocument(item: AcademyDocument) {
    try {
      if (!(await Sharing.isAvailableAsync())) throw new Error("مشاركة الملفات غير متاحة على هذا الجهاز");
      await Sharing.shareAsync(item.fileUri, { mimeType: item.mimeType ?? undefined, dialogTitle: item.title });
    } catch (error) { Alert.alert("تعذر فتح الملف", error instanceof Error ? error.message : "تأكدي أن الملف ما زال موجودًا."); }
  }
  function removeDocument(item: AcademyDocument) {
    Alert.alert("حذف الملف", `هل تريدين حذف «${item.title}» من المكتبة؟`, [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => void (async () => { const uri = await deleteAcademyDocument(item.id); if (uri) await FileSystem.deleteAsync(uri, { idempotent: true }); await refresh(); })().catch(error => Alert.alert("تعذر الحذف", error instanceof Error ? error.message : "حاولي مرة أخرى.")) }]);
  }
  async function saveQuestion() {
    if (!grade.trim() || !subject.trim() || !lesson.trim() || !prompt.trim()) return Alert.alert("بيانات ناقصة", "أدخلي الصف والمادة والدرس ونص السؤال.");
    if ((questionType === "mcq" || questionType === "true_false") && !answer.trim()) return Alert.alert("الإجابة الصحيحة مطلوبة", "حددي الإجابة الصحيحة للسؤال الموضوعي.");
    const optionList = options.split("\n").map(item => item.trim()).filter(Boolean);
    if (questionType === "mcq" && optionList.length < 2) return Alert.alert("الاختيارات غير كافية", "أدخلي اختيارين على الأقل، كل اختيار في سطر.");
    try {
      setSaving(true);
      await createAcademyQuestion({ grade: grade.trim(), subject, lesson: lesson.trim(), questionType, prompt: prompt.trim(), optionsJson: optionList.length ? JSON.stringify(optionList) : null, correctAnswer: answer.trim() || null, explanation: explanation.trim() || null, marks: Math.max(0.5, Number(marks) || 1) });
      setPrompt(""); setOptions(""); setAnswer(""); setExplanation(""); setMarks("1"); await refresh();
      Alert.alert("تم حفظ السؤال", "أُضيف السؤال إلى بنك الأسئلة ويمكن إعادة استخدامه لاحقًا في الامتحانات.");
    } catch (error) { Alert.alert("تعذر حفظ السؤال", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  const questionTypeLabel = (type: QuestionType) => ({ mcq: "اختيار من متعدد", true_false: "صح أو خطأ", short_answer: "إجابة قصيرة", essay: "مقالي" })[type];
  const examQuestions = questions.filter(item => (!examGrade.trim() || item.grade.trim() === examGrade.trim()) && item.subject === subject && (!examLesson.trim() || item.lesson.trim() === examLesson.trim()));
  const chosenQuestions = examQuestions.filter(item => selectedQuestionIds.includes(item.id));
  const examTotalMarks = chosenQuestions.reduce((sum, item) => sum + Number(item.marks || 0), 0);
  async function saveExam() {
    if (!examTitle.trim() || !examGrade.trim() || !subject.trim() || !examLesson.trim()) return Alert.alert("بيانات ناقصة", "أدخلي اسم الاختبار والصف والمادة والدرس.");
    if (examTargetId === null) return Alert.alert("حددي المستهدف", "اختاري المجموعة أو الطالب الذي سيؤدي الاختبار.");
    if (examDate.trim() && !/^\d{4}-\d{2}-\d{2}$/.test(examDate.trim())) return Alert.alert("صيغة التاريخ غير صحيحة", "استخدمي الصيغة YYYY-MM-DD.");
    if (!chosenQuestions.length) return Alert.alert("لم تختاري أسئلة", "حددي سؤالًا واحدًا على الأقل من بنك الأسئلة.");
    const invalid = chosenQuestions.find(item => (item.questionType === "mcq" || item.questionType === "true_false") && !item.correctAnswer);
    if (invalid) return Alert.alert("إجابة ناقصة", "يوجد سؤال موضوعي بلا إجابة نموذجية محفوظة.");
    try {
      setSaving(true);
      const targetStudentIds = examTargetType === "student"
        ? [examTargetId]
        : (await listGroupMembers(examTargetId)).map(member => member.studentId);
      if (!targetStudentIds.length) throw new Error("لا توجد طالبات مسجلات حاليًا في المجموعة المختارة.");
      await createAcademyExam({ title: examTitle.trim(), grade: examGrade.trim(), subject, lesson: examLesson.trim(), targetType: examTargetType, targetId: examTargetId, targetStudentIdsJson: JSON.stringify(targetStudentIds), durationMinutes: Math.max(5, Number(examDuration) || 45), examDate: examDate.trim() || null, totalMarks: examTotalMarks, questionsJson: JSON.stringify(chosenQuestions) });
      setExamTitle(""); setExamLesson(""); setExamDate(""); setSelectedQuestionIds([]); await refresh();
      Alert.alert("تم إنشاء الاختبار", "تم حفظ نسخة ثابتة من الأسئلة داخل الاختبار؛ أي تعديل لاحق في بنك الأسئلة لن يغيّر هذا الاختبار.");
    } catch (error) { Alert.alert("تعذر إنشاء الاختبار", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setSaving(false); }
  }
  async function shareExam(exam: AcademyExam, answerKey = false) {
    try {
      const items = JSON.parse(exam.questionsJson) as AcademyQuestion[];
      const escapeHtml = (value: string) => {
        const entities: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" };
        return value.replace(/[&<>"']/g, character => entities[character] ?? character);
      };
      const questionMarkup = items.map((item, index) => {
        const optionsList = item.optionsJson ? JSON.parse(item.optionsJson) as string[] : item.questionType === "true_false" ? ["صح", "خطأ"] : [];
        return `<section class="question"><div class="prompt"><b>${index + 1}.</b> ${escapeHtml(item.prompt)} <span>(${item.marks} درجة)</span></div>${optionsList.length ? `<ol type="A">${optionsList.map(option => `<li>${escapeHtml(option)}</li>`).join("")}</ol>` : ""}${answerKey ? `<div class="answer"><b>الإجابة النموذجية:</b> ${escapeHtml(item.correctAnswer || "تُصحح يدويًا")}${item.explanation ? `<br><b>ملاحظات:</b> ${escapeHtml(item.explanation)}` : ""}</div>` : `<div class="blank">الإجابة: ....................................................................................</div>`}</section>`;
      }).join("");
      const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(exam.title)}</title><style>body{font-family:Arial,sans-serif;margin:28px;color:#20302E;line-height:1.8}.head{text-align:center;border-bottom:2px solid #153C3A;padding-bottom:14px;margin-bottom:20px}.meta{display:flex;justify-content:space-between;flex-wrap:wrap}.question{margin:18px 0;break-inside:avoid}.prompt{font-size:17px}.prompt span{font-size:13px;color:#153C3A}.blank{margin:18px 0 28px;border-bottom:1px dotted #999;padding:10px 0}.answer{background:#F2F6F2;padding:10px;border-radius:8px;margin-top:10px}@media print{body{margin:15mm}}</style></head><body><header class="head"><h1>NANELSH Academy</h1><h2>${escapeHtml(exam.title)}</h2><div class="meta"><span>${escapeHtml(exam.grade)} · ${escapeHtml(exam.subject)} · ${escapeHtml(exam.lesson)}</span><span>المدة: ${exam.durationMinutes} دقيقة</span><span>الدرجة النهائية: ${exam.totalMarks}</span></div>${exam.examDate ? `<p>التاريخ: ${escapeHtml(exam.examDate)}</p>` : ""}</header>${!answerKey ? `<p>اسم الطالب: ..............................................</p>` : ""}${questionMarkup}</body></html>`;
      const directory = FileSystem.cacheDirectory;
      if (!directory) throw new Error("مساحة حفظ الملفات غير متاحة");
      const fileUri = `${directory}exam-${exam.id}-${answerKey ? "answer-key" : "paper"}.html`;
      await FileSystem.writeAsStringAsync(fileUri, html, { encoding: FileSystem.EncodingType.UTF8 });
      if (!(await Sharing.isAvailableAsync())) throw new Error("المشاركة غير متاحة على هذا الجهاز");
      await Sharing.shareAsync(fileUri, { mimeType: "text/html", dialogTitle: answerKey ? "مشاركة نموذج الإجابة" : "مشاركة ورقة الاختبار" });
    } catch (error) { Alert.alert("تعذر تجهيز الاختبار", error instanceof Error ? error.message : "تأكدي من بيانات الاختبار."); }
  }
  async function recordExamScore() {
    if (!gradingExam || gradingStudentId === null || !gradingScore.trim()) return Alert.alert("بيانات ناقصة", "اختاري الطالب وأدخلي الدرجة.");
    const score = Number(gradingScore);
    if (!Number.isFinite(score) || score < 0 || score > gradingExam.totalMarks) return Alert.alert("درجة غير صحيحة", `يجب أن تكون الدرجة من 0 إلى ${gradingExam.totalMarks}.`);
    try {
      await saveExamResult({ examId: gradingExam.id, studentId: gradingStudentId, score });
      setGradingResults(await listExamResults(gradingExam.id));
      setGradingScore("");
      Alert.alert("تم تسجيل الدرجة", "حُفظت الدرجة في سجل الاختبار.");
    } catch (error) { Alert.alert("تعذر حفظ الدرجة", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
  }
  return <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16, paddingBottom: 28, gap: 12 }} keyboardShouldPersistTaps="handled">
    <SectionHeader title="المكتبة التعليمية" subtitle="ملفاتك وأسئلتك في مكان واحد على الهاتف" />
    <View style={styles.segmented}><Choice label="مكتبة الملفات" selected={mode === "library"} onPress={() => setMode("library")} /><Choice label="بنك الأسئلة" selected={mode === "questions"} onPress={() => setMode("questions")} /><Choice label="الاختبارات" selected={mode === "exams"} onPress={() => setMode("exams")} /></View>
    {mode === "library" ? <>
      <View style={styles.card}>
        <SectionHeader title="إضافة ملف جديد" subtitle="PDF · Word · PowerPoint · صور" />
        <AppButton title={pickedFile ? "تغيير الملف المختار" : "اختيار ملف من الهاتف"} icon="attach-file" onPress={() => void chooseFile()} />
        {pickedFile ? <Text style={styles.inlineHint}>الملف المختار: {pickedFile.name}</Text> : null}
        <InputField label="عنوان الملف" value={title} onChangeText={setTitle} placeholder="مثال: ملخص الجهاز الهضمي" />
        <InputField label="الصف الدراسي" value={grade} onChangeText={setGrade} placeholder="مثال: الصف الثاني الإعدادي" />
        <Text style={styles.fieldLabel}>المادة</Text><View style={styles.choiceWrap}>{subjects.map(item => <Choice key={item.id} label={item.nameAr} selected={subject === item.nameAr} onPress={() => setSubject(item.nameAr)} />)}</View>
        <InputField label="الوحدة / الدرس" value={lesson} onChangeText={setLesson} placeholder="مثال: الوحدة الأولى - الخلية" />
        <Text style={styles.fieldLabel}>تخصيص الملف</Text><View style={styles.choiceWrap}><Choice label="جميع الطلاب" selected={accessType === "all"} onPress={() => { setAccessType("all"); setAccessId(null); }} /><Choice label="طالب محدد" selected={accessType === "student"} onPress={() => { setAccessType("student"); setAccessId(null); }} /><Choice label="مجموعة محددة" selected={accessType === "group"} onPress={() => { setAccessType("group"); setAccessId(null); }} /></View>
        {accessType === "student" ? <View style={styles.choiceWrap}>{students.map(item => <Choice key={item.id} label={item.name} selected={accessId === item.id} onPress={() => setAccessId(item.id)} />)}</View> : null}
        {accessType === "group" ? <View style={styles.choiceWrap}>{groups.map(item => <Choice key={item.id} label={item.name} selected={accessId === item.id} onPress={() => setAccessId(item.id)} />)}</View> : null}
        <Text style={styles.inlineHint}>تحديد الطالب أو المجموعة يسجل لمن خُصص الملف داخل المكتبة. مشاركة المحتوى للطلاب عبر بوابة مستقلة ستُضاف في مرحلة لاحقة.</Text>
        <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ في المكتبة"} icon="save" onPress={() => void saveDocument()} disabled={saving} />
      </View>
      <SectionHeader title={`ملفات المكتبة (${documents.length})`} />
      {documents.map(item => <View key={item.id} style={styles.transactionRow}><MaterialIcons name="description" size={24} color={COLORS.primaryDeep} /><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.title}</Text><Text style={styles.rowSub}>{item.grade} · {item.subject} · {item.lesson}</Text><Text style={styles.rowSub}>{item.accessType === "all" ? "متاح للجميع" : item.accessType === "student" ? `لطالب: ${students.find(x => x.id === item.accessId)?.name ?? "طالب محذوف"}` : `لمجموعة: ${groups.find(x => x.id === item.accessId)?.name ?? "مجموعة محذوفة"}`}</Text></View><View style={{ gap: 8 }}><Pressable onPress={() => void openDocument(item)}><MaterialIcons name="open-in-new" size={22} color={COLORS.success} /></Pressable><Pressable onPress={() => removeDocument(item)}><MaterialIcons name="delete-outline" size={22} color={COLORS.danger} /></Pressable></View></View>)}
      <Text style={styles.inlineHint}>ملاحظة: ملفات المكتبة تُضمَّن الآن داخل النسخة الاحتياطية الكاملة. احتفظي بالنسخة خارج الهاتف بعد التصدير.</Text>
      {!documents.length ? <EmptyState icon="folder-open" title="المكتبة فارغة" body="اختاري أول ملف شرح أو ملخص لإضافته." /> : null}
    </> : mode === "questions" ? <>
      <View style={styles.card}>
        <SectionHeader title="إضافة سؤال إلى البنك" subtitle="يُحفظ السؤال حسب الصف والمادة والدرس" />
        <InputField label="الصف الدراسي" value={grade} onChangeText={setGrade} placeholder="مثال: الصف الأول الثانوي" />
        <Text style={styles.fieldLabel}>المادة</Text><View style={styles.choiceWrap}>{subjects.map(item => <Choice key={item.id} label={item.nameAr} selected={subject === item.nameAr} onPress={() => setSubject(item.nameAr)} />)}</View>
        <InputField label="الوحدة / الدرس" value={lesson} onChangeText={setLesson} placeholder="اسم الدرس" />
        <Text style={styles.fieldLabel}>نوع السؤال</Text><View style={styles.choiceWrap}>{(["mcq", "true_false", "short_answer", "essay"] as QuestionType[]).map(type => <Choice key={type} label={questionTypeLabel(type)} selected={questionType === type} onPress={() => { setQuestionType(type); setAnswer(""); setOptions(""); }} />)}</View>
        <InputField label="نص السؤال" value={prompt} onChangeText={setPrompt} placeholder="اكتبي السؤال هنا" multiline />
        {questionType === "mcq" ? <InputField label="الاختيارات (كل اختيار في سطر)" value={options} onChangeText={setOptions} placeholder={"الاختيار الأول\nالاختيار الثاني\nالاختيار الثالث\nالاختيار الرابع"} multiline /> : null}
        {questionType === "true_false" ? <View style={styles.choiceWrap}><Choice label="صح" selected={answer === "صح"} onPress={() => setAnswer("صح")} /><Choice label="خطأ" selected={answer === "خطأ"} onPress={() => setAnswer("خطأ")} /></View> : questionType !== "essay" ? <InputField label="الإجابة الصحيحة" value={answer} onChangeText={setAnswer} placeholder="الإجابة النموذجية" /> : null}
        <InputField label="التفسير / ملاحظات التصحيح (اختياري)" value={explanation} onChangeText={setExplanation} placeholder="شرح مختصر للإجابة" multiline />
        <InputField label="الدرجة" value={marks} onChangeText={setMarks} keyboardType="numeric" placeholder="1" />
        <AppButton title={saving ? "جارٍ الحفظ..." : "حفظ السؤال في البنك"} icon="save" onPress={() => void saveQuestion()} disabled={saving} />
      </View>
      <SectionHeader title={`الأسئلة المحفوظة (${questions.length})`} />
      {questions.map(item => <View key={item.id} style={styles.transactionRow}><MaterialIcons name="quiz" size={23} color={COLORS.primaryDeep} /><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{item.prompt}</Text><Text style={styles.rowSub}>{item.grade} · {item.subject} · {item.lesson}</Text><Text style={styles.rowSub}>{questionTypeLabel(item.questionType)} · {item.marks} درجة</Text></View><Pressable onPress={() => Alert.alert("حذف السؤال", "هل تريدين حذف هذا السؤال من البنك؟", [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => void deleteAcademyQuestion(item.id).then(refresh).catch(error => Alert.alert("تعذر الحذف", error instanceof Error ? error.message : "حاولي مرة أخرى.")) }])}><MaterialIcons name="delete-outline" size={22} color={COLORS.danger} /></Pressable></View>)}
      {!questions.length ? <EmptyState icon="quiz" title="بنك الأسئلة فارغ" body="ابدئي بإضافة أسئلة الدروس لتجميع بنكك الخاص." /> : null}
    </> : <>
      <View style={styles.card}>
        <SectionHeader title="إنشاء اختبار جديد" subtitle="اختاري أسئلة محفوظة وخصصي الاختبار لمجموعة أو طالب" />
        <InputField label="اسم الاختبار" value={examTitle} onChangeText={setExamTitle} placeholder="مثال: اختبار الوحدة الأولى" />
        <InputField label="الصف الدراسي" value={examGrade} onChangeText={setExamGrade} placeholder="مثال: الصف الثالث الإعدادي" />
        <Text style={styles.fieldLabel}>المادة</Text><View style={styles.choiceWrap}>{subjects.map(item => <Choice key={item.id} label={item.nameAr} selected={subject === item.nameAr} onPress={() => { setSubject(item.nameAr); setSelectedQuestionIds([]); }} />)}</View>
        <InputField label="الوحدة / الدرس" value={examLesson} onChangeText={setExamLesson} placeholder="اكتبي اسم الدرس أو الوحدة" />
        <View style={styles.inlineFields}><View style={{ flex: 1 }}><InputField label="المدة بالدقائق" value={examDuration} onChangeText={setExamDuration} keyboardType="numeric" placeholder="45" /></View><View style={{ flex: 1 }}><InputField label="تاريخ الاختبار (اختياري)" value={examDate} onChangeText={setExamDate} placeholder="YYYY-MM-DD" /></View></View>
        <Text style={styles.fieldLabel}>الاختبار موجّه إلى</Text><View style={styles.choiceWrap}><Choice label="مجموعة" selected={examTargetType === "group"} onPress={() => { setExamTargetType("group"); setExamTargetId(null); }} /><Choice label="طالب واحد" selected={examTargetType === "student"} onPress={() => { setExamTargetType("student"); setExamTargetId(null); }} /></View>
        <View style={styles.choiceWrap}>{(examTargetType === "group" ? groups.map(item => ({ id: item.id, name: item.name })) : students.map(item => ({ id: item.id, name: item.name }))).map(item => <Choice key={item.id} label={item.name} selected={examTargetId === item.id} onPress={() => setExamTargetId(item.id)} />)}</View>
        <SectionHeader title={`اختاري الأسئلة (${chosenQuestions.length})`} subtitle={`الأسئلة المتاحة المطابقة: ${examQuestions.length}`} />
        {examQuestions.map((item, index) => <Pressable key={item.id} onPress={() => setSelectedQuestionIds(current => current.includes(item.id) ? current.filter(id => id !== item.id) : [...current, item.id])} style={[styles.transactionRow, selectedQuestionIds.includes(item.id) && { borderColor: COLORS.primary, backgroundColor: COLORS.sageSoft }]}><MaterialIcons name={selectedQuestionIds.includes(item.id) ? "check-circle" : "radio-button-unchecked"} size={22} color={COLORS.primaryDeep} /><View style={{ flex: 1 }}><Text style={styles.rowTitle}>{index + 1}. {item.prompt}</Text><Text style={styles.rowSub}>{questionTypeLabel(item.questionType)} · {item.marks} درجة · {item.lesson}</Text></View></Pressable>)}
        {!examQuestions.length ? <Text style={styles.inlineHint}>لا توجد أسئلة مطابقة. أضيفي أسئلة في بنك الأسئلة بنفس الصف والمادة، ويمكن ترك خانة الدرس فارغة لعرض جميع دروس المادة.</Text> : null}
        <View style={styles.groupCapacityCallout}><Text style={styles.groupCapacityTitle}>مجموع الدرجات: {examTotalMarks}</Text><Text style={styles.groupCapacityBody}>عدد الأسئلة المختارة: {chosenQuestions.length}</Text></View>
        <AppButton title={saving ? "جارٍ إنشاء الاختبار..." : "حفظ الاختبار"} icon="save" onPress={() => void saveExam()} disabled={saving} />
      </View>
      <SectionHeader title={`الاختبارات المحفوظة (${exams.length})`} />
      {exams.map(exam => { const targetName = exam.targetType === "group" ? groups.find(item => item.id === exam.targetId)?.name : students.find(item => item.id === exam.targetId)?.name; return <View key={exam.id} style={styles.card}><SectionHeader title={exam.title} subtitle={`${exam.grade} · ${exam.subject} · ${exam.lesson}`} /><Text style={styles.rowSub}>{exam.targetType === "group" ? "مجموعة" : "طالب"}: {targetName ?? "مستهدف غير موجود"} · {exam.durationMinutes} دقيقة · {exam.totalMarks} درجة</Text><View style={styles.choiceWrap}><Choice label="ورقة الاختبار" selected={false} onPress={() => void shareExam(exam, false)} /><Choice label="مفتاح الإجابة" selected={false} onPress={() => void shareExam(exam, true)} /><Choice label="تسجيل درجة" selected={gradingExam?.id === exam.id} onPress={() => { setGradingExam(exam); setGradingStudentId(exam.targetType === "student" ? exam.targetId : null); }} /><Choice label="حذف" selected={false} onPress={() => Alert.alert("حذف الاختبار", "سيتم حذف الاختبار ودرجاته المسجلة فقط، دون حذف أسئلته من البنك.", [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => void deleteAcademyExam(exam.id).then(refresh).catch(error => Alert.alert("تعذر الحذف", error instanceof Error ? error.message : "حاولي مرة أخرى.")) }])} /></View>
        {gradingExam?.id === exam.id ? <View style={{ gap: 8 }}><Text style={styles.fieldLabel}>الطالب</Text>{gradingCandidates.map(item => <Choice key={item.id} label={item.name} selected={gradingStudentId === item.id} onPress={() => setGradingStudentId(item.id)} />)}{!gradingCandidates.length ? <Text style={styles.inlineHint}>لا يوجد طلاب مسجلون حاليًا في هذه المجموعة.</Text> : null}<InputField label={`الدرجة من ${exam.totalMarks}`} value={gradingScore} onChangeText={setGradingScore} keyboardType="decimal-pad" placeholder="مثال: 18" /><AppButton title="حفظ الدرجة" icon="save" onPress={() => void recordExamScore()} />{gradingResults.map(result => <Text key={result.id} style={styles.rowSub}>{students.find(item => item.id === result.studentId)?.name ?? "طالب"}: {result.score} / {exam.totalMarks}</Text>)}</View> : null}
      </View>; })}
      {!exams.length ? <EmptyState icon="assignment" title="لا توجد اختبارات بعد" body="أنشئي اختبارك الأول من بنك الأسئلة." /> : null}
      <Text style={styles.inlineHint}>تنبيه: هذه المرحلة تنشئ ورقة اختبار قابلة للمشاركة ومفتاح إجابة، وتسجل الدرجات يدويًا من جهاز المعلمة. لا يوجد حتى الآن دخول للطلاب أو أداء إلكتروني أو تصحيح تلقائي.</Text>
    </>}
  </ScrollView>;
}

function MainApp() {
  const [snapshot, setSnapshot] = useState<DashboardSnapshot | null>(null);
  const [subjectOptions, setSubjectOptions] = useState<AcademySubject[]>([]);
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [moreOpen, setMoreOpen] = useState(false);
  const [modal, setModal] = useState<ModalKind>(null);
  const [selectedSession, setSelectedSession] = useState<LessonSession | null>(null);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<TutoringGroup | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<TimetableSlot | null>(null);
  const [reportSession, setReportSession] = useState<LessonSession | null>(null);
  const [reportRecipients, setReportRecipients] = useState<ReportRecipient[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  const reload = async () => {
    setRefreshing(true);
    try { await generateSessionsFromWeeklyTimetable(todayDate()); const [nextSnapshot, nextSubjects] = await Promise.all([getSnapshot(), listSubjects()]); setSnapshot(nextSnapshot); setSubjectOptions(nextSubjects); }
    catch (error) { Alert.alert("تعذر تحميل البيانات", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
    finally { setRefreshing(false); }
  };

  useEffect(() => {
    let storeReady = false;
    let lastGeneratedDate = todayDate();
    const subscription = AppState.addEventListener("change", state => {
      if (state === "active" && storeReady) {
        lastGeneratedDate = todayDate();
        void reload();
      }
    });
    const dayRolloverCheck = setInterval(() => {
      if (!storeReady || AppState.currentState !== "active") return;
      const currentDate = todayDate();
      if (currentDate !== lastGeneratedDate) {
        lastGeneratedDate = currentDate;
        void reload();
      }
    }, 60_000);
    void (async () => {
      await initializeStore();
      await reload();
      lastGeneratedDate = todayDate();
      storeReady = true;
    })();
    return () => {
      subscription.remove();
      clearInterval(dayRolloverCheck);
    };
  }, []);

  if (!snapshot) {
    return <SafeAreaView style={styles.loadingScreen}><View style={styles.loadingLogoFrame}><Image source={require("./assets/icon.png")} style={styles.loadingLogo} resizeMode="cover" /></View><ActivityIndicator color={COLORS.primaryDeep} size="large" /><Text style={styles.loadingEyebrow}>NANELSH ACADEMY OS</Text><Text style={styles.loadingText}>يتم فتح بياناتك المحلية...</Text></SafeAreaView>;
  }

  const closeSessionModal = () => { setModal(null); setSelectedSession(null); };
  const deleteWithConfirm = (title: string, body: string, action: () => Promise<void>) => Alert.alert(title, body, [{ text: "إلغاء", style: "cancel" }, { text: "تأكيد", style: "destructive", onPress: () => void action().then(reload).catch(error => Alert.alert("تعذر تنفيذ العملية", error instanceof Error ? error.message : "حاولي مرة أخرى.")) }]);
  const shareReport = async (session: LessonSession) => {
    try {
      if (session.groupId) {
        const members = await listGroupMembers(session.groupId);
        if (!members.length) return Alert.alert("لا يوجد طلاب بالمجموعة", "أضيفي الطلاب إلى المجموعة قبل إرسال التقارير.");
        setReportSession(session);
        setReportRecipients(members.map(member => ({ studentId: member.studentId, name: member.name, phone: member.phone })));
        return;
      }
      const student = snapshot.students.find(item => item.id === session.studentId);
      await shareSessionReport(session, student ? { name: student.name, academy: student.academy, phone: student.phone } : undefined);
    } catch (error) { Alert.alert("تعذر إرسال التقرير", error instanceof Error ? error.message : "حاولي مرة أخرى."); }
  };
  const shareSingleGroupStudentReport = async (session: LessonSession, recipient: ReportRecipient) => {
    try {
      await shareSessionReport(session, { name: recipient.name, academy: session.academy, phone: recipient.phone });
    } catch (error) { Alert.alert("تعذر فتح واتساب", error instanceof Error ? error.message : "تأكدي من رقم الهاتف أو وجود واتساب."); }
  };
  const shareGroupStudentReport = async (recipient: ReportRecipient) => {
    if (!reportSession) return;
    try {
      await shareSessionReport(reportSession, { name: recipient.name, academy: reportSession.academy, phone: recipient.phone });
      setReportRecipients(current => current.filter(item => item.studentId !== recipient.studentId));
      if (reportRecipients.length <= 1) { setReportSession(null); setReportRecipients([]); }
    } catch (error) { Alert.alert("تعذر فتح واتساب", error instanceof Error ? error.message : "تأكدي من رقم الهاتف أو وجود واتساب."); }
  };
  let content: ReactNode;
  if (activeTab === "home") content = <HomeScreen snapshot={snapshot} onOpen={setModal} onQuickComplete={session => { setSelectedSession(session); setModal("complete"); }} />;
  else if (activeTab === "students") content = <StudentsScreen students={snapshot.students} onAdd={() => setModal("student")} onOpen={student => { setSelectedStudent(student); setModal("studentDetail"); }} onDelete={student => deleteWithConfirm(student.active ? "أرشفة الطالبة" : "إعادة تفعيل الطالبة", student.active ? `سيتم إيقاف ${student.name} مع الاحتفاظ بسجلاتها، وإيقاف مواعيدها وإنهاء تسجيلاتها النشطة في المجموعات. يمكن تسجيلها مجددًا لاحقًا.` : `سيتم إعادة تفعيل ${student.name}.`, async () => { await updateStudent(student.id, { active: student.active ? 0 : 1 }); })} />;
  else if (activeTab === "sessions") content = <SessionsScreen sessions={snapshot.sessions} timetable={snapshot.timetable} onOpen={setModal} onStart={async session => { try { await startSession(session.id); await reload(); } catch (error) { Alert.alert("تعذر بدء الحصة", error instanceof Error ? error.message : "حاولي مرة أخرى."); } }} onComplete={session => { setSelectedSession(session); setModal("complete"); }} onEdit={session => { setSelectedSession(session); setModal(session.status === "completed" ? "report" : "sessionEdit"); }} onReport={shareReport} onDelete={session => deleteWithConfirm("حذف الحصة", "سيتم حذف الحصة من السجل المحلي.", () => deleteSession(session.id))} onEditSlot={slot => { setSelectedSlot(slot); setModal("timetableEdit"); }} onToggleSlot={slot => void setTimetableSlotActive(slot.id, !slot.active).then(reload).catch(error => Alert.alert("تعذر تعديل الموعد", error instanceof Error ? error.message : "حاولي مرة أخرى."))} onDeleteSlot={slot => deleteWithConfirm("حذف الموعد الأسبوعي", `سيتم حذف موعد ${slot.title} من الجدول.`, () => deleteTimetableSlot(slot.id))} />;
  else if (activeTab === "groups") content = <GroupsScreen groups={snapshot.groups} onAdd={() => setModal("group")} onOpen={group => { setSelectedGroup(group); setModal("groupDetail"); }} onDelete={group => deleteWithConfirm(group.active ? "أرشفة المجموعة" : "إعادة تفعيل المجموعة", group.active ? `سيتم إيقاف ${group.name} مع الاحتفاظ بالحصص والتسجيلات والتقارير.` : `سيتم إعادة تفعيل ${group.name}.`, async () => { await updateGroup(group.id, { active: group.active ? 0 : 1 }); })} />;
  else if (activeTab === "content") content = <LearningContentScreen students={snapshot.students} groups={snapshot.groups} subjects={subjectOptions} />;
  else if (activeTab === "assessment") content = <AssessmentScreen students={snapshot.students} groups={snapshot.groups} subjects={subjectOptions} />;
  else if (activeTab === "finance") content = <FinanceScreen transactions={snapshot.transactions} students={snapshot.students} onOpen={() => setModal("finance")} onOpenStudent={student => { setSelectedStudent(student); setModal("studentDetail"); }} onDelete={transaction => deleteWithConfirm("حذف الحركة", "سيتم حذف الحركة من الحساب المحلي.", () => deleteTransaction(transaction.id))} />;
  else content = <SettingsScreen onReload={reload} />;

  return (
    <SafeAreaView style={styles.safe} edges={["top", "left", "right", "bottom"]}>
      <NativeHeader onReload={reload} />
      <View style={styles.screen}>
        {refreshing && <View style={styles.refreshLine} />}
        {content}
      </View>
      <View style={styles.tabBar}>
        {TABS.filter(tab => ["home", "students", "sessions", "groups", "finance"].includes(tab.key)).map(tab => {
          const selected = activeTab === tab.key && !moreOpen;
          return <Pressable key={tab.key} accessibilityRole="tab" accessibilityState={{ selected }} accessibilityLabel={tab.title} onPress={() => { haptic(); setMoreOpen(false); setActiveTab(tab.key); }} style={({ pressed }) => [styles.tabItem, pressed && { opacity: 0.7 }]}><View style={[styles.tabIcon, selected && styles.tabIconSelected]}><MaterialIcons name={tab.icon} size={21} color={selected ? COLORS.primaryDeep : COLORS.muted} /></View><Text style={[styles.tabText, selected && styles.tabTextSelected]}>{tab.title}</Text></Pressable>;
        })}
        <Pressable accessibilityRole="button" accessibilityLabel="المزيد" onPress={() => { haptic(); setMoreOpen(true); }} style={({ pressed }) => [styles.tabItem, pressed && { opacity: 0.7 }]}><View style={[styles.tabIcon, moreOpen && styles.tabIconSelected]}><MaterialIcons name="more-horiz" size={22} color={moreOpen ? COLORS.primaryDeep : COLORS.muted} /></View><Text style={[styles.tabText, moreOpen && styles.tabTextSelected]}>المزيد</Text></Pressable>
      </View>
      <Modal visible={moreOpen} transparent animationType="fade" onRequestClose={() => setMoreOpen(false)}>
        <Pressable style={styles.moreBackdrop} onPress={() => setMoreOpen(false)}>
          <Pressable style={styles.moreSheet} onPress={event => event.stopPropagation()}>
            <View style={styles.moreHandle} />
            <Text style={styles.moreTitle}>مساحات الأكاديمية</Text>
            <Text style={styles.moreSubtitle}>كل أدوات NANELSH في مكان واحد</Text>
            <View style={styles.moreGrid}>
              {[{ key: "content" as Tab, title: "المحتوى", icon: "menu-book" as IconName }, { key: "assessment" as Tab, title: "التقييم", icon: "assessment" as IconName }, { key: "settings" as Tab, title: "الإعدادات", icon: "tune" as IconName }].map(item => <Pressable key={item.key} style={({ pressed }) => [styles.moreItem, pressed && { opacity: 0.72, transform: [{ scale: 0.98 }] }]} onPress={() => { haptic(); setMoreOpen(false); setActiveTab(item.key); }}><View style={styles.moreItemIcon}><MaterialIcons name={item.icon} size={22} color={COLORS.primaryDeep} /></View><Text style={styles.moreItemText}>{item.title}</Text></Pressable>)}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
      <StudentSheet visible={modal === "student"} onClose={() => setModal(null)} onSaved={reload} subjectOptions={subjectOptions} />
      <StudentDetailSheet student={modal === "studentDetail" ? selectedStudent : null} sessions={snapshot.sessions} transactions={snapshot.transactions} subjectOptions={subjectOptions} groups={snapshot.groups} onClose={() => { setModal(null); setSelectedStudent(null); }} onSaved={reload} />
      <GroupSheet visible={modal === "group"} onClose={() => setModal(null)} onSaved={reload} subjectOptions={subjectOptions} />
      <GroupDetailSheet group={modal === "groupDetail" ? selectedGroup : null} students={snapshot.students} subjectOptions={subjectOptions} onClose={() => { setModal(null); setSelectedGroup(null); }} onSaved={reload} onShareReport={shareReport} onShareStudentReport={shareSingleGroupStudentReport} />
      <SessionSheet visible={modal === "session"} onClose={() => setModal(null)} onSaved={reload} students={snapshot.students} groups={snapshot.groups} />
      <SessionEditSheet session={modal === "sessionEdit" ? selectedSession : null} onClose={closeSessionModal} onSaved={reload} />
      <CompletionSheet session={modal === "complete" ? selectedSession : null} onClose={closeSessionModal} onSaved={reload} />
      <CompletedSessionEditSheet session={modal === "report" ? selectedSession : null} onClose={closeSessionModal} onSaved={reload} onShare={shareReport} />
      <ReportRecipientSheet visible={Boolean(reportSession)} recipients={reportRecipients} onClose={() => { setReportSession(null); setReportRecipients([]); }} onSelect={recipient => void shareGroupStudentReport(recipient)} />
      <FinanceSheet visible={modal === "finance"} onClose={() => setModal(null)} onSaved={reload} students={snapshot.students} />
      <TimetableSheet visible={modal === "timetable"} onClose={() => setModal(null)} onSaved={reload} students={snapshot.students} groups={snapshot.groups} />
      <TimetableEditSheet slot={modal === "timetableEdit" ? selectedSlot : null} onClose={() => { setModal(null); setSelectedSlot(null); }} onSaved={reload} />
    </SafeAreaView>
  );
}

export default function App() {
  return <SafeAreaProvider><StatusBar style="dark" /><MainApp /></SafeAreaProvider>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.background },
  screen: { flex: 1 },
  loadingScreen: { flex: 1, alignItems: "center", justifyContent: "center", gap: 10, backgroundColor: COLORS.background },
  loadingLogoFrame: { width: 116, height: 116, borderRadius: 34, overflow: "hidden", backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.champagneSoft, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.14, shadowOffset: { width: 0, height: 10 }, shadowRadius: 24, elevation: 6 },
  loadingLogo: { width: "100%", height: "100%" },
  loadingEyebrow: { color: COLORS.champagne, fontSize: 10, fontWeight: "900", letterSpacing: 2.2, marginTop: 7 },
  loadingText: { color: COLORS.muted, fontSize: 13 },
  appHeader: { height: 92, paddingHorizontal: 16, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", backgroundColor: "#FBF8F1", borderBottomWidth: 1, borderBottomColor: COLORS.border, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.035, shadowOffset: { width: 0, height: 3 }, shadowRadius: 10, elevation: 2 },
  headerHairline: { position: "absolute", top: 0, left: 18, right: 18, height: 2, borderRadius: 2, backgroundColor: COLORS.champagne },
  brandRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, flex: 1 },
  brandMarkFrame: { width: 52, height: 52, borderRadius: 17, overflow: "hidden", backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.champagneSoft, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.10, shadowOffset: { width: 0, height: 5 }, shadowRadius: 10, elevation: 3 },
  brandMarkImage: { width: "100%", height: "100%" },
  brandCopy: { flex: 1, alignItems: "flex-end" },
  brandEyebrow: { color: COLORS.champagne, fontSize: 8, fontWeight: "900", letterSpacing: 1.1, textAlign: "right" },
  brandName: { color: COLORS.ink, fontSize: 17, fontWeight: "900", marginTop: 1, textAlign: "right" },
  brandCaption: { color: COLORS.muted, fontSize: 10, marginTop: 2, textAlign: "right" },
  headerActions: { flexDirection: "row-reverse", alignItems: "center", gap: 7, marginLeft: 8 },
  livePill: { height: 30, paddingHorizontal: 9, borderRadius: 15, backgroundColor: COLORS.sageSoft, borderWidth: 1, borderColor: COLORS.border, flexDirection: "row-reverse", alignItems: "center", gap: 5 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.success },
  livePillText: { color: COLORS.primaryDeep, fontSize: 9, fontWeight: "900" },
  iconButton: { width: 40, height: 40, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.surface, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border },
  refreshLine: { height: 2, backgroundColor: COLORS.primary, position: "absolute", left: 0, right: 0, top: 0, zIndex: 10 },
  listContent: { paddingHorizontal: 16, paddingTop: 14, paddingBottom: 34, gap: 12, flexGrow: 1 },
  commandCenter: { overflow: "hidden", borderRadius: 28, padding: 20, backgroundColor: COLORS.primaryDeep, minHeight: 205, borderWidth: 1, borderColor: "rgba(197,164,109,0.52)", shadowColor: COLORS.primaryDeep, shadowOpacity: 0.18, shadowOffset: { width: 0, height: 12 }, shadowRadius: 24, elevation: 6 },
  commandOrbOne: { position: "absolute", width: 190, height: 190, borderRadius: 95, backgroundColor: "rgba(197,164,109,0.17)", top: -122, left: -52 },
  commandOrbTwo: { position: "absolute", width: 145, height: 145, borderRadius: 73, backgroundColor: "rgba(220,233,228,0.12)", right: -60, bottom: -72 },
  commandTopRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  commandEyebrow: { color: COLORS.champagne, fontSize: 9, fontWeight: "900", letterSpacing: 1.35, textAlign: "right" },
  commandLive: { flexDirection: "row-reverse", alignItems: "center", gap: 6, paddingHorizontal: 9, minHeight: 27, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.10)", borderWidth: 1, borderColor: "rgba(255,255,255,0.12)" },
  commandLiveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#A8D1BF" },
  commandLiveText: { color: "#E7F0EA", fontSize: 9, fontWeight: "800" },
  commandGreeting: { color: "#FFFFFF", fontSize: 27, lineHeight: 35, fontWeight: "900", marginTop: 22, textAlign: "right", writingDirection: "rtl", letterSpacing: -0.3 },
  commandDate: { color: "#DCE9E4", fontSize: 12, marginTop: 4, textAlign: "right", writingDirection: "rtl" },
  commandSummaryRow: { flexDirection: "row-reverse", alignItems: "center", marginTop: 19, paddingTop: 14, borderTopWidth: 1, borderTopColor: "rgba(255,255,255,0.12)" },
  commandSummary: { flex: 1, alignItems: "flex-end" },
  commandSummaryValue: { color: "#FFFFFF", fontSize: 19, fontWeight: "900", textAlign: "right" },
  commandSummaryLabel: { color: "#BFD0C9", fontSize: 9, marginTop: 2, fontWeight: "700", textAlign: "right", writingDirection: "rtl" },
  commandSummaryDivider: { width: 1, height: 30, backgroundColor: "rgba(255,255,255,0.12)" },
  nextSessionCard: { minHeight: 94, flexDirection: "row-reverse", alignItems: "center", gap: 11, overflow: "hidden", backgroundColor: COLORS.surface, borderRadius: 22, borderWidth: 1, borderColor: "rgba(197,164,109,0.36)", padding: 13, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.06, shadowOffset: { width: 0, height: 5 }, shadowRadius: 14, elevation: 2 },
  nextSessionAccent: { position: "absolute", right: 0, top: 0, bottom: 0, width: 4, backgroundColor: COLORS.champagne },
  nextSessionIcon: { width: 45, height: 45, borderRadius: 15, backgroundColor: COLORS.sage, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#D5E4DC" },
  nextSessionCopy: { flex: 1, alignItems: "flex-end" },
  nextSessionEyebrow: { color: COLORS.champagne, fontSize: 8, fontWeight: "900", letterSpacing: 1.3, textAlign: "right" },
  nextSessionTitle: { color: COLORS.ink, fontSize: 15, fontWeight: "900", marginTop: 3, textAlign: "right", writingDirection: "rtl" },
  nextSessionMeta: { color: COLORS.muted, fontSize: 10, marginTop: 3, textAlign: "right", writingDirection: "rtl" },
  quickActionsCard: { backgroundColor: "rgba(255,254,251,0.88)", borderRadius: 22, borderWidth: 1, borderColor: COLORS.border, padding: 13, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.035, shadowOffset: { width: 0, height: 4 }, shadowRadius: 10, elevation: 1 },
  quickActionsTitle: { color: COLORS.ink, fontSize: 13, fontWeight: "900", textAlign: "right", writingDirection: "rtl", marginBottom: 10 },
  quickActionsGrid: { flexDirection: "row-reverse", gap: 8 },
  quickAction: { flex: 1, minHeight: 68, alignItems: "center", justifyContent: "center", borderRadius: 16, backgroundColor: COLORS.sageSoft, borderWidth: 1, borderColor: "#E1EAE4", gap: 5 },
  quickActionIcon: { width: 31, height: 31, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border },
  quickActionText: { color: COLORS.primaryDeep, fontSize: 9, fontWeight: "800", textAlign: "center", writingDirection: "rtl" },
  heroCard: { overflow: "hidden", borderRadius: 30, padding: 24, backgroundColor: COLORS.primaryDeep, minHeight: 208, justifyContent: "center", marginBottom: 1, borderWidth: 1, borderColor: "rgba(197,164,109,0.45)", shadowColor: COLORS.primaryDeep, shadowOpacity: 0.16, shadowOffset: { width: 0, height: 10 }, shadowRadius: 24, elevation: 5 },
  heroGlowOne: { position: "absolute", width: 200, height: 200, borderRadius: 100, backgroundColor: "rgba(197,164,109,0.22)", top: -110, left: -40 },
  heroGlowTwo: { position: "absolute", width: 160, height: 160, borderRadius: 80, backgroundColor: "rgba(220,233,228,0.18)", right: -55, bottom: -75 },
  heroEyebrow: { color: COLORS.champagne, fontSize: 10, fontWeight: "900", letterSpacing: 1.1, textAlign: "right", writingDirection: "rtl" },
  heroTitle: { color: "#FFFFFF", fontSize: 27, lineHeight: 36, fontWeight: "900", marginTop: 7, textAlign: "right", writingDirection: "rtl" },
  heroBody: { color: "#DCE9E4", fontSize: 12, marginTop: 6, textAlign: "right", writingDirection: "rtl" },
  heroActions: { flexDirection: "row-reverse", gap: 8, marginTop: 18 },
  metricsGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 10, marginVertical: 10 },
  metricCard: { width: "48.5%", minHeight: 112, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 24, padding: 15, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.055, shadowOffset: { width: 0, height: 6 }, shadowRadius: 15, elevation: 2 },
  metricIcon: { width: 38, height: 38, borderRadius: 14, alignItems: "center", justifyContent: "center", marginBottom: 10, alignSelf: "flex-end", borderWidth: 1, borderColor: "rgba(21,60,58,0.05)" },
  metricValue: { color: COLORS.ink, fontSize: 22, fontWeight: "900", textAlign: "right" },
  metricLabel: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right" },
  todayAtGlance: { backgroundColor: COLORS.primaryDeep, borderRadius: 23, padding: 16, marginBottom: 9, borderWidth: 1, borderColor: "rgba(197,164,109,0.32)", shadowColor: COLORS.primaryDeep, shadowOpacity: 0.10, shadowOffset: { width: 0, height: 7 }, shadowRadius: 16, elevation: 3 }, todayAtGlanceTop: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 13 }, todayAtGlanceEyebrow: { color: COLORS.champagne, fontSize: 9, fontWeight: "900", letterSpacing: 1.5, textAlign: "right" }, todayAtGlanceTitle: { color: "#FFFFFF", fontSize: 16, fontWeight: "900", marginTop: 3, textAlign: "right", writingDirection: "rtl" }, todayAtGlanceBadge: { flexDirection: "row-reverse", alignItems: "center", gap: 5, backgroundColor: "rgba(255,255,255,0.08)", borderWidth: 1, borderColor: "rgba(255,255,255,0.14)", borderRadius: 14, paddingHorizontal: 9, paddingVertical: 6 }, todayAtGlanceBadgeText: { color: "#E9F0EC", fontSize: 10, fontWeight: "800" }, todayAtGlanceRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-around", borderTopWidth: 1, borderTopColor: "rgba(255,255,255,0.12)", paddingTop: 13 }, todayAtGlanceItem: { flex: 1, alignItems: "center" }, todayAtGlanceValue: { color: "#FFFFFF", fontSize: 24, fontWeight: "900" }, todayAtGlanceLabel: { color: "#C9D8D2", fontSize: 10, fontWeight: "700", marginTop: 2 }, todayAtGlanceDivider: { width: 1, height: 28, backgroundColor: "rgba(255,255,255,0.12)" }, insightStrip: { flexDirection: "row-reverse", alignItems: "center", backgroundColor: COLORS.surface, borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, paddingVertical: 12, marginBottom: 4 }, insightStripItem: { flex: 1, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6 }, insightStripValue: { color: COLORS.ink, fontSize: 12, fontWeight: "900", textAlign: "right" }, insightStripLabel: { color: COLORS.muted, fontSize: 8, fontWeight: "700", marginTop: 2, textAlign: "right", writingDirection: "rtl" }, insightStripDivider: { width: 1, height: 30, backgroundColor: COLORS.border },
  insightCard: { flexDirection: "row-reverse", backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 22, padding: 14, gap: 10, marginBottom: 6, shadowColor: "#153C3A", shadowOpacity: 0.035, shadowOffset: { width: 0, height: 3 }, shadowRadius: 10, elevation: 1 },
  insightItem: { flex: 1, flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  insightIcon: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  insightValue: { color: COLORS.ink, fontSize: 15, fontWeight: "800", textAlign: "right" },
  insightLabel: { color: COLORS.muted, fontSize: 10, marginTop: 2, textAlign: "right", writingDirection: "rtl" },
  insightDivider: { width: 1, backgroundColor: COLORS.border },
  sectionHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 12, marginBottom: 2 },
  sectionHeaderText: { flex: 1 }, sectionTitle: { color: COLORS.ink, fontSize: 20, fontWeight: "900", textAlign: "right", writingDirection: "rtl", letterSpacing: -0.25 }, sectionSubtitle: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right", writingDirection: "rtl" },
  button: { minHeight: 47, borderRadius: 16, paddingHorizontal: 17, paddingVertical: 10, borderWidth: 1, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 7, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.06, shadowOffset: { width: 0, height: 4 }, shadowRadius: 9, elevation: 1 },
  buttonCompact: { minHeight: 36, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 12 }, buttonText: { fontWeight: "800", fontSize: 14, writingDirection: "rtl" }, buttonTextCompact: { fontSize: 12 },
  emptyState: { borderWidth: 1, borderStyle: "dashed", borderColor: "#D8E5DE", borderRadius: 22, backgroundColor: COLORS.sageSoft, padding: 28, alignItems: "center", marginTop: 2 },
  emptyIcon: { width: 58, height: 58, borderRadius: 20, backgroundColor: COLORS.sage, alignItems: "center", justifyContent: "center", marginBottom: 12 }, emptyTitle: { color: COLORS.ink, fontSize: 16, fontWeight: "800", textAlign: "center" }, emptyBody: { color: COLORS.muted, lineHeight: 21, fontSize: 13, marginTop: 6, textAlign: "center", writingDirection: "rtl" },
  sessionCard: { backgroundColor: COLORS.surface, borderRadius: 21, padding: 15, borderWidth: 1, borderColor: COLORS.border, overflow: "hidden" }, sessionAccent: { position: "absolute", right: 0, top: 0, bottom: 0, width: 4, backgroundColor: COLORS.primary }, sessionTop: { flexDirection: "row-reverse", gap: 12 }, sessionTime: { color: COLORS.primaryDeep, fontSize: 13, fontWeight: "800", textAlign: "right" }, sessionName: { color: COLORS.ink, fontSize: 17, fontWeight: "800", textAlign: "right", marginTop: 3 }, sessionMeta: { color: COLORS.muted, fontSize: 12, textAlign: "right", marginTop: 4, writingDirection: "rtl" }, statusBadge: { borderRadius: 10, alignSelf: "flex-start", paddingHorizontal: 9, paddingVertical: 5 }, statusText: { fontWeight: "800", fontSize: 11 }, sessionActions: { flexDirection: "row-reverse", justifyContent: "flex-start", alignItems: "center", gap: 8, borderTopWidth: 1, borderTopColor: "#F2F6F2", marginTop: 13, paddingTop: 12 }, completedInfo: { flexDirection: "row-reverse", gap: 9, alignItems: "center", borderTopWidth: 1, borderTopColor: "#F2F6F2", marginTop: 13, paddingTop: 12 }, attendanceBadge: { borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5 }, attendanceText: { fontSize: 11, fontWeight: "800" }, completedNotes: { color: COLORS.muted, fontSize: 12, flex: 1, textAlign: "right" },
  followUpRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 16, padding: 12, marginBottom: 8 }, avatar: { width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.sage }, avatarText: { color: COLORS.primaryDeep, fontSize: 17, fontWeight: "800" }, rowTitle: { color: COLORS.ink, fontSize: 15, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, rowSub: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right", lineHeight: 17, writingDirection: "rtl" }, lowBadge: { backgroundColor: COLORS.warningSoft, borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5 }, lowBadgeText: { color: COLORS.warning, fontSize: 10, fontWeight: "800" }, softNotice: { backgroundColor: COLORS.successSoft, flexDirection: "row-reverse", gap: 8, alignItems: "center", justifyContent: "center", borderRadius: 14, padding: 13 }, softNoticeText: { color: COLORS.success, fontWeight: "700", fontSize: 12, writingDirection: "rtl" },
  searchBox: { flexDirection: "row-reverse", alignItems: "center", gap: 9, paddingHorizontal: 12, minHeight: 46, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 15, marginVertical: 8 },
  searchInput: { flex: 1, color: COLORS.ink, fontSize: 13, writingDirection: "rtl" },
  studentCard: { flexDirection: "row-reverse", gap: 10, alignItems: "center", backgroundColor: COLORS.surface, borderRadius: 20, padding: 13, borderWidth: 1, borderColor: COLORS.border }, studentPressTarget: { flex: 1, flexDirection: "row-reverse", gap: 10, alignItems: "center" }, progressRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, marginTop: 8 }, progressTrack: { height: 6, flex: 1, backgroundColor: "#E8EDE7", borderRadius: 6, overflow: "hidden" }, progressFill: { height: 6, backgroundColor: COLORS.primary, borderRadius: 6 }, progressText: { color: COLORS.primaryDeep, fontSize: 11, fontWeight: "800" }, remainingText: { color: COLORS.primaryDeep, fontSize: 11, fontWeight: "700", marginTop: 4, textAlign: "right", writingDirection: "rtl" },
  profileSummary: { flexDirection: "row-reverse", alignItems: "center", gap: 10, backgroundColor: COLORS.sage, borderRadius: 18, padding: 14 }, profileAvatar: { width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.primaryDeep }, profileAvatarText: { color: "#FFFFFF", fontSize: 21, fontWeight: "800" }, profileBalance: { color: COLORS.primaryDeep, fontWeight: "800", fontSize: 15, textAlign: "right" }, profileCaption: { color: "#52645D", fontSize: 11, marginTop: 3, textAlign: "right", writingDirection: "rtl" }, inlineFields: { flexDirection: "row-reverse", gap: 9 }, profileSessionRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, borderRadius: 13, padding: 10 }, profileSessionNotes: { color: COLORS.ink, fontSize: 12, marginTop: 3, textAlign: "right", writingDirection: "rtl" },
  segmented: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, backgroundColor: COLORS.sageSoft, borderRadius: 15, padding: 7, marginVertical: 8 }, choiceRow: { flexDirection: "row-reverse", gap: 8 }, choiceWrap: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }, choice: { minHeight: 36, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 12, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, justifyContent: "center" }, choiceText: { color: COLORS.muted, fontWeight: "700", fontSize: 12, writingDirection: "rtl" }, inlineHint: { color: COLORS.warning, backgroundColor: COLORS.warningSoft, padding: 10, borderRadius: 10, marginTop: 8, textAlign: "right", writingDirection: "rtl" },
  daysGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }, dayPicker: { width: "31%", minHeight: 42, borderRadius: 13, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, paddingHorizontal: 7 }, dayPickerSelected: { backgroundColor: COLORS.sage, borderColor: COLORS.primaryDeep }, dayPickerText: { color: COLORS.muted, fontSize: 12, fontWeight: "800", writingDirection: "rtl" }, dayPickerTextSelected: { color: COLORS.primaryDeep },
  timeSelectionCard: { backgroundColor: COLORS.sageSoft, borderRadius: 16, borderWidth: 1, borderColor: "#DCE8E0", padding: 12, gap: 8 }, timeSelectionHeader: { marginBottom: 2 }, timeSelectionTitle: { color: COLORS.ink, fontSize: 13, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, timeSelectionHint: { color: COLORS.muted, fontSize: 10, marginTop: 3, textAlign: "right", writingDirection: "rtl" }, dayTimeRow: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 10, backgroundColor: COLORS.surface, borderRadius: 12, padding: 9 }, dayTimeLabel: { flex: 1, color: COLORS.ink, fontSize: 13, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, timePickerButton: { flexDirection: "row-reverse", alignItems: "center", gap: 5, minHeight: 34, borderRadius: 10, backgroundColor: COLORS.sage, paddingHorizontal: 9 }, timePickerButtonText: { color: COLORS.primaryDeep, fontSize: 13, fontWeight: "800" },
  editTimePickerButton: { minHeight: 47, borderRadius: 13, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, paddingHorizontal: 13, flexDirection: "row-reverse", alignItems: "center", gap: 9 }, editTimePickerText: { flex: 1, color: COLORS.ink, fontSize: 15, fontWeight: "800", textAlign: "right" }, editTimePickerHint: { color: COLORS.primaryDeep, fontSize: 12, fontWeight: "800", writingDirection: "rtl" },
  timetableHint: { flexDirection: "row-reverse", alignItems: "center", gap: 8, padding: 12, borderRadius: 14, backgroundColor: COLORS.sage, marginBottom: 8 }, timetableHintText: { flex: 1, color: COLORS.primaryDeep, fontSize: 11, fontWeight: "700", textAlign: "right", writingDirection: "rtl" }, todaySectionLabel: { color: COLORS.primaryDeep, fontSize: 13, fontWeight: "800", textAlign: "right", marginVertical: 5, writingDirection: "rtl" }, timetableDayCard: { backgroundColor: COLORS.sageSoft, borderRadius: 20, padding: 12, gap: 9, borderWidth: 1, borderColor: COLORS.border }, timetableDayCardToday: { borderColor: COLORS.primaryDeep, borderWidth: 1.5, backgroundColor: "#F2F6F2" }, timetableDayHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 7, paddingBottom: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border }, timetableDayDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: COLORS.muted }, timetableDayDotToday: { backgroundColor: COLORS.primaryDeep }, timetableDayTitle: { color: COLORS.ink, fontSize: 15, fontWeight: "900", textAlign: "right" }, timetableTodayBadge: { color: COLORS.primaryDeep, backgroundColor: COLORS.sage, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, fontSize: 10, fontWeight: "800" }, timetableDayCount: { flex: 1, color: COLORS.muted, fontSize: 10, fontWeight: "700", textAlign: "left" }, timetableDayEmpty: { color: COLORS.muted, fontSize: 11, textAlign: "right", paddingVertical: 8, writingDirection: "rtl" }, slotCard: { flexDirection: "row-reverse", alignItems: "center", gap: 11, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 18, padding: 13 }, slotCardPaused: { backgroundColor: "#F4F2EA", borderColor: "#E7E1D6" }, slotIcon: { width: 42, height: 42, borderRadius: 14, backgroundColor: COLORS.sage, alignItems: "center", justifyContent: "center" }, slotActions: { flexDirection: "row-reverse", gap: 5, flexWrap: "wrap", justifyContent: "flex-end" }, pausedText: { color: COLORS.warning, fontSize: 10, fontWeight: "700", textAlign: "right", marginTop: 4, writingDirection: "rtl" },
  groupCard: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 23, padding: 15, gap: 12, shadowColor: "#153C3A", shadowOpacity: 0.04, shadowOffset: { width: 0, height: 4 }, shadowRadius: 12, elevation: 1 }, groupTop: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, groupPressTarget: { flexDirection: "row-reverse", alignItems: "center", gap: 10, flex: 1 }, groupIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: COLORS.champagneSoft, alignItems: "center", justifyContent: "center" }, groupStats: { flexDirection: "row-reverse", justifyContent: "space-around", backgroundColor: COLORS.sageSoft, paddingVertical: 11, borderRadius: 14 }, groupStatValue: { color: COLORS.primaryDeep, fontSize: 16, fontWeight: "800", textAlign: "center" }, groupStatLabel: { color: COLORS.muted, fontSize: 10, marginTop: 2, textAlign: "center" }, memberStrip: { flexDirection: "row-reverse", alignItems: "center", gap: 6 }, memberText: { flex: 1, color: COLORS.muted, fontSize: 12, textAlign: "right", writingDirection: "rtl" }, groupCapacityCallout: { backgroundColor: COLORS.sage, borderRadius: 15, padding: 12, flexDirection: "row-reverse", gap: 8, alignItems: "center" }, groupCapacityTitle: { color: COLORS.primaryDeep, fontWeight: "800", fontSize: 14, textAlign: "right" }, groupCapacityBody: { color: "#52645D", fontSize: 11, marginTop: 3, textAlign: "right", writingDirection: "rtl" },
  monthPickerRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginVertical: 8 }, monthArrow: { width: 36, height: 36, borderRadius: 12, backgroundColor: COLORS.sage, alignItems: "center", justifyContent: "center" }, monthPickerLabel: { color: COLORS.ink, fontSize: 14, fontWeight: "800", minWidth: 112, textAlign: "center" }, monthToday: { paddingHorizontal: 10, paddingVertical: 8, borderRadius: 10, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border }, monthTodayText: { color: COLORS.primaryDeep, fontSize: 11, fontWeight: "800" },
  card: { backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, borderRadius: 24, padding: 16, gap: 10, shadowColor: COLORS.primaryDeep, shadowOpacity: 0.045, shadowOffset: { width: 0, height: 5 }, shadowRadius: 14, elevation: 2 },
  financeNetCard: { backgroundColor: COLORS.primaryDeep, padding: 22, borderRadius: 25, borderWidth: 1, borderColor: "rgba(197,164,109,0.42)", marginVertical: 10 }, financeNetLabel: { color: "#E5EDE7", fontSize: 13, fontWeight: "700", textAlign: "right" }, financeNetValue: { color: "#FFFFFF", fontSize: 30, fontWeight: "800", marginTop: 5, textAlign: "right" }, financeNetFoot: { color: "#DCE9E4", fontSize: 11, marginTop: 5, textAlign: "right", writingDirection: "rtl" }, financeMetrics: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }, miniFinance: { width: "48.5%", padding: 12, borderRadius: 15 }, miniFinanceValue: { fontWeight: "800", fontSize: 14, textAlign: "right" }, miniFinanceLabel: { fontWeight: "700", fontSize: 11, marginTop: 4, textAlign: "right" }, transactionRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, borderRadius: 17, padding: 12 }, transactionIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center" }, transactionAmount: { fontSize: 13, fontWeight: "800" }, deleteText: { color: COLORS.danger, fontSize: 11, fontWeight: "800" },
  localPrivacyCard: { backgroundColor: COLORS.sage, borderRadius: 20, padding: 15, flexDirection: "row-reverse", alignItems: "flex-start", gap: 10, marginVertical: 8 }, localPrivacyTitle: { color: COLORS.primaryDeep, fontSize: 15, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, localPrivacyBody: { color: "#52645D", fontSize: 12, lineHeight: 18, marginTop: 4, textAlign: "right", writingDirection: "rtl" }, settingsRow: { flexDirection: "row-reverse", alignItems: "center", gap: 12, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.surface, borderRadius: 18, padding: 14, marginBottom: 9 }, settingsIcon: { width: 43, height: 43, borderRadius: 14, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.sageSoft }, aboutCard: { borderRadius: 18, backgroundColor: COLORS.sandSoft, padding: 15, marginTop: 10 }, aboutTitle: { color: COLORS.ink, fontSize: 14, fontWeight: "800", textAlign: "right" }, aboutText: { color: COLORS.muted, fontSize: 12, lineHeight: 18, marginTop: 5, textAlign: "right", writingDirection: "rtl" },
  modalBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(21,60,58,0.38)" }, sheet: { maxHeight: "93%", backgroundColor: COLORS.background, borderTopLeftRadius: 30, borderTopRightRadius: 30, padding: 19, gap: 10 }, sheetScroll: { gap: 10, paddingBottom: 12 }, sheetHandle: { width: 45, height: 5, backgroundColor: "#D7E3DC", borderRadius: 6, alignSelf: "center", marginBottom: 3 }, sheetTop: { flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 2 }, sheetTitle: { color: COLORS.ink, fontSize: 20, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, sheetSubtitle: { color: COLORS.muted, fontSize: 12, marginTop: 3, textAlign: "right", writingDirection: "rtl" }, fieldWrap: { gap: 6 }, fieldLabel: { color: COLORS.ink, fontSize: 12, fontWeight: "800", textAlign: "right", writingDirection: "rtl" }, input: { minHeight: 44, borderWidth: 1, borderColor: COLORS.border, borderRadius: 13, color: COLORS.ink, backgroundColor: COLORS.surface, paddingHorizontal: 12, fontSize: 14, writingDirection: "rtl" }, inputMultiline: { minHeight: 72, paddingTop: 10, textAlignVertical: "top" },
  moreBackdrop: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(21,60,58,0.22)" }, moreSheet: { backgroundColor: COLORS.background, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 18, paddingBottom: 24, borderTopWidth: 1, borderTopColor: COLORS.border }, moreHandle: { width: 42, height: 5, borderRadius: 5, backgroundColor: "#D6DED8", alignSelf: "center", marginBottom: 12 }, moreTitle: { color: COLORS.ink, fontSize: 20, fontWeight: "900", textAlign: "right", writingDirection: "rtl" }, moreSubtitle: { color: COLORS.muted, fontSize: 11, marginTop: 3, marginBottom: 14, textAlign: "right", writingDirection: "rtl" }, moreGrid: { flexDirection: "row-reverse", gap: 9 }, moreItem: { flex: 1, minHeight: 82, borderRadius: 18, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: COLORS.border, alignItems: "center", justifyContent: "center", gap: 7 }, moreItemIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: COLORS.sage, alignItems: "center", justifyContent: "center" }, moreItemText: { color: COLORS.primaryDeep, fontSize: 10, fontWeight: "900" },
  tabBar: { flexDirection: "row-reverse", minHeight: 82, paddingHorizontal: 7, paddingTop: 8, paddingBottom: 6, backgroundColor: "#FFFDF8", borderTopWidth: 1, borderTopColor: COLORS.border, justifyContent: "space-around", shadowColor: COLORS.primaryDeep, shadowOpacity: 0.08, shadowOffset: { width: 0, height: -5 }, shadowRadius: 16, elevation: 12 }, tabItem: { flex: 1, minWidth: 0, alignItems: "center", justifyContent: "center", gap: 4 }, tabIcon: { width: 43, height: 35, borderRadius: 13, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "transparent" }, tabIconSelected: { backgroundColor: COLORS.sage, borderColor: "rgba(197,164,109,0.42)" }, tabText: { color: COLORS.muted, fontSize: 9, fontWeight: "800" }, tabTextSelected: { color: COLORS.primaryDeep, fontWeight: "900" },
});
